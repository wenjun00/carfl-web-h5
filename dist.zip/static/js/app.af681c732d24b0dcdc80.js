webpackJsonp([5],{

/***/ "+Ryy":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("WDiC");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("2d86ccff", content, true, {});

/***/ }),

/***/ "+Z++":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("wAJw");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("391dd7e8", content, true, {});

/***/ }),

/***/ "+bZQ":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("Qo2O");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("5b89ec64", content, true, {});

/***/ }),

/***/ "+mpJ":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".address[data-v-c07d463a]{height:50px}.van-cell--required[data-v-c07d463a]:before{left:-.3rem;bottom:.3rem;font-size:36px;color:#ffe44d}.van-picker[data-v-c07d463a]{position:fixed;width:100%;bottom:0;z-index:100}.base-info-title[data-v-c07d463a]{color:gray;padding:12px;font-size:.8rem;border-bottom:1px solid #e8e8e8}.van-cell[data-v-c07d463a]{margin:0 auto 0 3%;border-bottom:1px solid #e8e8e8;width:97%}.van-button--bottom-action.van-button--primary[data-v-c07d463a]{background-color:#ffe44d}.van-cell--required[data-v-21fd4166][data-v-c07d463a]:before{top:.9rem}", ""]);

// exports


/***/ }),

/***/ "+unC":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".page.subscribe .cityLive .van-cell__title{max-width:90px}.page.subscribe .phoneText .van-field__control{text-align:right}.page.subscribe .shop .van-field__control{text-align:right;padding-right:19px}", ""]);

// exports


/***/ }),

/***/ "/kJb":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".buy-car-list .carStyle[data-v-7ef8c8af]{line-height:30px}.buy-car-list-item[data-v-7ef8c8af]{padding:10px;border-bottom:1px solid #f2f2f2}.buy-car-list-nav-bar[data-v-7ef8c8af]{padding-left:10px;padding-right:10px}.buy-car-list .to-top[data-v-7ef8c8af]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;background-color:gray;border-radius:25px;opacity:.5;font-size:2rem;height:30px;width:30px;position:fixed;bottom:30px;right:30px;z-index:2001}.buy-car-list .no-cars[data-v-7ef8c8af]{font-size:2rem;padding-top:10%;text-align:center}.car[data-v-7ef8c8af]{text-align:left}.car-info[data-v-7ef8c8af]{font-size:.9rem}.car-price[data-v-7ef8c8af]{font-size:.8rem;color:gray}.car-first[data-v-7ef8c8af]{font-size:.9rem;color:#daa520}.car-month[data-v-7ef8c8af]{font-size:.8rem;color:gray;text-align:right}", ""]);

// exports


/***/ }),

/***/ "/owb":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".page.uploadIdPhotoThree .lookiconHead[data-v-5d8853cd]{position:relative;top:-105px;left:-65px;color:#6495ed;font-size:25px}.page.uploadIdPhotoThree .deleteiconHead[data-v-5d8853cd]{position:relative;top:-105px;left:65px;color:#6495ed;font-size:20px}.page.uploadIdPhotoThree .headPortrait[data-v-5d8853cd]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;padding:5px;-webkit-box-sizing:border-box;box-sizing:border-box}.page.uploadIdPhotoThree .vanIcon[data-v-5d8853cd]{font-size:40px;line-height:150px;color:#bebebe}.page.uploadIdPhotoThree .imgList[data-v-5d8853cd]{text-align:center;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;height:120px}.page.uploadIdPhotoThree .imgList .imgSize[data-v-5d8853cd]{height:110px;border:1px solid #6666;width:90%;margin-top:10px}.page.uploadIdPhotoThree .fade-enter-active[data-v-5d8853cd],.page.uploadIdPhotoThree .fade-leave-active[data-v-5d8853cd]{-webkit-transition:bottom .5s;transition:bottom .5s}.page.uploadIdPhotoThree .fade-enter[data-v-5d8853cd],.page.uploadIdPhotoThree .fade-leave-to[data-v-5d8853cd]{bottom:-388px}.page.uploadIdPhotoThree .base-info-title[data-v-5d8853cd]{color:gray;padding:12px;font-size:.8rem;border-bottom:1px solid #e8e8e8}.page.uploadIdPhotoThree .photo_container[data-v-5d8853cd]{display:-webkit-box;display:-ms-flexbox;display:flex}.page.uploadIdPhotoThree .photo_content[data-v-5d8853cd]{-webkit-box-flex:1;-ms-flex:1;flex:1;display:-webkit-box;display:-ms-flexbox;display:flex;-ms-flex-pack:distribute;justify-content:space-around}.page.uploadIdPhotoThree .photo_content img[data-v-5d8853cd]{width:100%;height:124px}.page.uploadIdPhotoThree p[data-v-5d8853cd]{margin:0}", ""]);

// exports


/***/ }),

/***/ "0NAA":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".page.details-scheme .active[data-v-46f55bf7]{color:#fcdf2b;border-color:#fcdf2b!important}.page.details-scheme .carGoHome .purchaseNotes[data-v-46f55bf7]{padding:0 25px;font-size:13px;font-weight:600;margin:10px 0;height:45px}.page.details-scheme .carGoHome .purchaseNotes .noticeHeand[data-v-46f55bf7]{color:#333}.page.details-scheme .carGoHome .purchaseNotes .noticeEnd[data-v-46f55bf7]{color:#666}.page.details-scheme .carGoHome .basicParameter[data-v-46f55bf7]{line-height:30px!important;font-weight:600!important}.page.details-scheme .carGoHome .someIcon[data-v-46f55bf7]{position:relative;top:3px}.page.details-scheme .carGoHome .magin10[data-v-46f55bf7]{margin-bottom:10px}.page.details-scheme .carGoHome .appointmentImmediately[data-v-46f55bf7]{display:-webkit-box;display:-ms-flexbox;display:flex;-ms-flex-pack:distribute;justify-content:space-around;height:80px}.page.details-scheme .carGoHome .appointmentImmediately .appointmentDescribe[data-v-46f55bf7]{width:60%}.page.details-scheme .carGoHome .appointmentImmediately .appointmentDescribe .appointmentHend[data-v-46f55bf7]{font-size:14px;font-weight:600;height:22px}.page.details-scheme .carGoHome .appointmentImmediately .appointmentDescribe .appointmentSpan[data-v-46f55bf7]{font-size:12px}.page.details-scheme .colred[data-v-46f55bf7]{color:red}.page.details-scheme .downPayment[data-v-46f55bf7]{border:1px solid gray;padding:5px;-webkit-box-sizing:border-box;box-sizing:border-box}.page.details-scheme .mar10[data-v-46f55bf7]{margin-top:10px;margin-bottom:10px;font-size:14px;font-weight:600}.page.details-scheme .imgCenter[data-v-46f55bf7]{text-align:center}.page.details-scheme .magin10[data-v-46f55bf7]{margin-bottom:10px}.page.details-scheme .advantage[data-v-46f55bf7]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between}.page.details-scheme .advantage .carLeft[data-v-46f55bf7],.page.details-scheme .advantage .carRight[data-v-46f55bf7]{width:48%;font-size:13px;text-align:center;color:gray;margin-bottom:10px}.page.details-scheme .payment[data-v-46f55bf7],.page.details-scheme .paymentTwo[data-v-46f55bf7]{font-weight:600;font-size:13px;margin:10px 0}.page.details-scheme .periods[data-v-46f55bf7]{display:inline-block;width:69px;height:28px;border:1px solid grey;text-align:center;line-height:28px;font-size:13px}.page.details-scheme .monthly[data-v-46f55bf7]{font-size:13px}.page.details-scheme .area[data-v-46f55bf7]{background-color:#fafbfa;width:90%;margin:0 auto;padding-left:20px;color:gray;margin-top:15px;margin-bottom:15px}.page.details-scheme .basicParameter[data-v-46f55bf7]{line-height:30px!important;font-weight:600!important}.page.details-scheme .someIcon[data-v-46f55bf7]{position:relative;top:3px}.page.details-scheme .carLightspot[data-v-46f55bf7]{width:85%;margin:0 auto}.page.details-scheme .carLightspot .absut[data-v-46f55bf7]{position:relative}.page.details-scheme .carLightspot .van-hairline--surround.van-tag[data-v-46f55bf7]{position:absolute;bottom:10px;left:5px;background:#2d2e30;font-size:12px}", ""]);

// exports


/***/ }),

/***/ "1EYD":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".page.uploadIdPhotoTwo .lookiconHead[data-v-21ab6ac2]{position:relative;top:-105px;left:-65px;color:#6495ed;font-size:25px}.page.uploadIdPhotoTwo .deleteiconHead[data-v-21ab6ac2]{position:relative;top:-105px;left:65px;color:#6495ed;font-size:20px}.page.uploadIdPhotoTwo .headPortrait[data-v-21ab6ac2]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;padding:5px;-webkit-box-sizing:border-box;box-sizing:border-box}.page.uploadIdPhotoTwo .vanIcon[data-v-21ab6ac2]{font-size:40px;line-height:150px;color:#bebebe}.page.uploadIdPhotoTwo .imgList[data-v-21ab6ac2]{text-align:center;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;height:120px}.page.uploadIdPhotoTwo .imgList .imgSize[data-v-21ab6ac2]{height:110px;border:1px solid #6666;width:90%;margin-top:10px}.page.uploadIdPhotoTwo .fade-enter-active[data-v-21ab6ac2],.page.uploadIdPhotoTwo .fade-leave-active[data-v-21ab6ac2]{-webkit-transition:bottom .5s;transition:bottom .5s}.page.uploadIdPhotoTwo .fade-enter[data-v-21ab6ac2],.page.uploadIdPhotoTwo .fade-leave-to[data-v-21ab6ac2]{bottom:-388px}.page.uploadIdPhotoTwo .base-info-title[data-v-21ab6ac2]{color:gray;padding:12px;font-size:.8rem;border-bottom:1px solid #e8e8e8}.page.uploadIdPhotoTwo .photo_container[data-v-21ab6ac2]{display:-webkit-box;display:-ms-flexbox;display:flex}.page.uploadIdPhotoTwo .photo_content[data-v-21ab6ac2]{-webkit-box-flex:1;-ms-flex:1;flex:1;display:-webkit-box;display:-ms-flexbox;display:flex;-ms-flex-pack:distribute;justify-content:space-around}.page.uploadIdPhotoTwo .photo_content img[data-v-21ab6ac2]{width:100%;height:124px}.page.uploadIdPhotoTwo p[data-v-21ab6ac2]{margin:0}", ""]);

// exports


/***/ }),

/***/ "1pVc":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/promise.js
var promise = __webpack_require__("//Fk");
var promise_default = /*#__PURE__*/__webpack_require__.n(promise);

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/object/assign.js
var object_assign = __webpack_require__("woOf");
var assign_default = /*#__PURE__*/__webpack_require__.n(object_assign);

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/object/entries.js
var entries = __webpack_require__("W3Iv");
var entries_default = /*#__PURE__*/__webpack_require__.n(entries);

// EXTERNAL MODULE: ./node_modules/rxjs/Rx.js
var Rx = __webpack_require__("Gvdl");
var Rx_default = /*#__PURE__*/__webpack_require__.n(Rx);

// EXTERNAL MODULE: ./node_modules/axios/index.js
var axios = __webpack_require__("mtWM");
var axios_default = /*#__PURE__*/__webpack_require__.n(axios);

// EXTERNAL MODULE: ./node_modules/qs/lib/index.js
var lib = __webpack_require__("mw3O");
var lib_default = /*#__PURE__*/__webpack_require__.n(lib);

// CONCATENATED MODULE: ./src/config/app.config.ts
/* harmony default export */ var app_config = ({
    name: '汽车金融-H5',
    version: '1.0.0',
    url: {
        server: "http://172.24.3.107:8360"
    },
    mock: Object({"NODE_ENV":"production","BUILD_ENV":"demo","BUILD_TIME":"2018-6-14 16:32:05","URL_SERVER":"http://172.24.3.107:8360"}).MOCK,
    timeout: 60000,
    debug: Object({"NODE_ENV":"production","BUILD_ENV":"demo","BUILD_TIME":"2018-6-14 16:32:05","URL_SERVER":"http://172.24.3.107:8360"}).ENV === 'dev',
    registerPageList: ["add-information.vue","all-vehicles.vue","buy-car-list.vue","contact-information.vue","custom-information.vue","details.vue","faq.vue","home.vue","index.vue","know-onion-car.vue","login.vue","my-order.vue","not-found.vue","payment-record.vue","subscribe.vue","upload-id-photo-first.vue","upload-id-photo-three.vue","upload-id-photo-two.vue","verify-code.vue"]
});
// EXTERNAL MODULE: ./src/utils/storage.service.ts
var storage_service = __webpack_require__("3mjx");

// EXTERNAL MODULE: ./node_modules/vue/dist/vue.esm.js
var vue_esm = __webpack_require__("7+uW");

// EXTERNAL MODULE: ./node_modules/vue-class-component/dist/vue-class-component.common.js
var vue_class_component_common = __webpack_require__("c+8m");
var vue_class_component_common_default = /*#__PURE__*/__webpack_require__.n(vue_class_component_common);

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/common/loading.vue
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


var loading_Loading = /** @class */ (function (_super) {
    __extends(Loading, _super);
    function Loading() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Loading = __decorate([
        vue_class_component_common_default()({
            components: {}
        })
    ], Loading);
    return Loading;
}(vue_esm["default"]));
/* harmony default export */ var common_loading = (loading_Loading);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-48967eba","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/common/loading.vue
var loading_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component loading"},[_c('van-popup',[_c('div',{staticClass:"content row middle-span center-span"},[_c('div',{staticClass:"sk-cube-grid"},[_c('div',{staticClass:"sk-cube sk-cube1"}),_vm._v(" "),_c('div',{staticClass:"sk-cube sk-cube2"}),_vm._v(" "),_c('div',{staticClass:"sk-cube sk-cube3"}),_vm._v(" "),_c('div',{staticClass:"sk-cube sk-cube4"}),_vm._v(" "),_c('div',{staticClass:"sk-cube sk-cube5"}),_vm._v(" "),_c('div',{staticClass:"sk-cube sk-cube6"}),_vm._v(" "),_c('div',{staticClass:"sk-cube sk-cube7"}),_vm._v(" "),_c('div',{staticClass:"sk-cube sk-cube8"}),_vm._v(" "),_c('div',{staticClass:"sk-cube sk-cube9"})])])])],1)}
var staticRenderFns = []

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/component-normalizer.js
var component_normalizer = __webpack_require__("XyMi");

// CONCATENATED MODULE: ./src/components/common/loading.vue
function injectStyle (context) {
  __webpack_require__("+Ryy")
  __webpack_require__("N5a5")
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-48967eba"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(component_normalizer["a" /* default */])(
  common_loading,
  loading_render,
  staticRenderFns,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var components_common_loading = (Component.exports);

// CONCATENATED MODULE: ./src/utils/loading.service.ts


var loading_service_LoadingService = /** @class */function () {
    function LoadingService() {}
    /**
     * 显示弹出框
     * @param type
     * @param option
     */
    LoadingService.show = function () {
        var Instance = new vue_esm["default"]({
            render: function render(h) {
                var vnode = h(components_common_loading, {
                    props: {}
                });
                return vnode;
            },
            methods: {
                remove: function remove() {
                    var _this = this;
                    setTimeout(function () {
                        _this.destroy();
                    }, 300);
                },
                destroy: function destroy() {
                    this.$destroy();
                    document.body.removeChild(this.$el);
                }
            }
        });
        var component = Instance.$mount();
        document.body.appendChild(component.$el);
        var modal = Instance.$children[0];
        modal.remove = function () {
            modal.$parent.remove();
        };
        return modal;
    };
    LoadingService.prototype.remove = function (modal) {
        modal.visible = false;
        modal.$parent.remove();
    };
    return LoadingService;
}();

// EXTERNAL MODULE: ./src/config/enum.config.ts
var enum_config = __webpack_require__("mfkW");

// CONCATENATED MODULE: ./src/config/server/file-service/file-upload.controller.ts

var SERVICE = 'service-file';
var CONTROLLER = 'fileUploadController';
/* harmony default export */ var file_upload_controller = ({
    /**
     * 下载文件
     */
    file: {
        service: SERVICE,
        controller: CONTROLLER,
        action: 'file',
        type: enum_config["requestType"].Get
    },
    /**
    * 查询文件信息
    */
    getAllUploadFileByIdList: {
        service: SERVICE,
        controller: CONTROLLER,
        action: 'getAllUploadFileByIdList',
        type: enum_config["requestType"].Get
    },
    /**
    * 上传压缩文件，后台进行解压缩
    */
    unZipCaseFile: {
        service: SERVICE,
        controller: CONTROLLER,
        action: 'unZipCaseFile',
        type: enum_config["requestType"].Post
    },
    /**
    * Grid方式上传文件
    */
    uploadFileGrid: {
        service: SERVICE,
        controller: CONTROLLER,
        action: 'uploadFileGrid',
        type: enum_config["requestType"].Post
    },
    /**
     * 根据条件查询审批原因
     */
    view: {
        service: SERVICE,
        controller: CONTROLLER,
        action: 'view',
        type: enum_config["requestType"].Get
    },
    /**
     * 删除文件
     */
    delect: {
        service: SERVICE,
        controller: CONTROLLER,
        action: 'delect',
        type: enum_config["requestType"].Delete
    }
});
// CONCATENATED MODULE: ./src/config/server/file-service/index.ts

var fileService = {
    fileUploadController: file_upload_controller
};
// CONCATENATED MODULE: ./src/utils/net.service.ts
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NetService", function() { return net_service_NetService; });










var getType = ['GET', 'DELETE']; // 使用GET请求类型
var net_service_NetService = /** @class */function () {
    function NetService() {
        this.axiosInstance = axios_default.a.create({
            baseURL: app_config.url.server,
            timeout: app_config.timeout,
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });
    }
    NetService.generateRequestUrl = function (_a, append, sort) {
        var service = _a.service,
            controller = _a.controller,
            action = _a.action,
            url = _a.url;
        if (append === void 0) {
            append = [];
        }
        // 自定义url优先级最高
        if (url) return url;
        // 进行url拼接
        if (controller) {
            var targetUrl = [service, controller, action].concat(append).filter(function (x) {
                return x;
            }).join('/');
            if (sort) {
                console.log(sort);
                targetUrl += '?';
                targetUrl += entries_default()(sort.sort).map(function (_a) {
                    var k = _a[0],
                        v = _a[1];
                    return "sort=" + k + "," + v;
                }).join('&');
            }
            return targetUrl;
        } else {
            throw new Error('server配置异常,请检查对应server配置');
        }
    };
    /**
     * 生成头部信息
     */
    NetService.prototype.generateRequestHeader = function (headers) {
        var token = storage_service["a" /* StorageService */].getItem('userToken') || '';
        if (token) {
            return assign_default()({
                'authorization': token
            }, headers);
        } else {
            return headers || {};
        }
    };
    /**
     * 过滤空数据
     * @param data
     */
    NetService.prototype.filterEmptyData = function (data) {
        entries_default()(data).filter(function (_a) {
            var key = _a[0],
                value = _a[1];
            // 过滤空字符串
            if (value === undefined || value === "") {
                return true;
            }
            // 过滤空数组
            // if (value instanceof Array && (value.length === 0 || value.every(x => x === ''))) {
            //   return true
            // }
        }).forEach(function (_a) {
            var key = _a[0],
                value = _a[1];
            delete data[key];
        });
        return data;
    };
    /**
     * 发送网络请求信息
     * @param param0
     */
    NetService.prototype.send = function (options) {
        var _this = this;
        var data = assign_default()({}, options.data);
        var postData;
        var getData;
        var url = NetService.generateRequestUrl(options.server, options.append, options.sort);
        var method = options.server.type || 'GET';
        var headers = this.generateRequestHeader(options.headers);
        if (options.page) {
            data = assign_default()(data, options.page.getConfig());
        }
        // 判断参数类型
        getType.indexOf(method) > -1 ? getData = this.filterEmptyData(data) : postData = this.filterEmptyData(data);
        var loadingPromise = new promise_default.a(function (resolve, reject) {
            if (options.loading) {
                var loading = loading_service_LoadingService.show();
                resolve(loading);
            } else {
                resolve();
            }
        });
        // 发送通讯结果
        var emitResult = function emitResult(fn) {
            return function (loading) {
                if (loading) {
                    loading.remove();
                }
                if (fn && typeof fn === 'function') {
                    fn.call(this);
                }
            };
        };
        // 创建待观察对象
        var observable = Rx["Observable"].create(function (observer) {
            _this.axiosInstance.request({
                method: method,
                url: url,
                headers: headers,
                data: postData,
                params: getData,
                paramsSerializer: function paramsSerializer(params) {
                    return lib_default.a.stringify(params, {
                        arrayFormat: 'repeat',
                        skipNulls: true,
                        allowDots: true
                    });
                }
            }).then(function (_a) {
                var data = _a.data;
                if (data.status === "SUCCESS") {
                    var object_1 = data.object;
                    if (options.page && object_1.list) {
                        options.page.update(object_1);
                        object_1 = object_1.list;
                    }
                    loadingPromise.then(emitResult(function () {
                        observer.next(object_1);
                    }));
                } else {
                    loadingPromise.then(emitResult(function () {
                        observer.error({
                            msg: data.msg
                        });
                    }));
                }
            }).catch(function (ex) {
                // 错误信息
                var error = {
                    msg: "",
                    params: ""
                };
                // 逻辑异常检测
                if (!ex.response && !ex.request) {
                    error.msg = ex.message;
                    error.params = ex.stack;
                    console.error(ex.stack);
                    loadingPromise.then(emitResult(function () {}));
                    return Rx["Observable"].empty();
                }
                // 通讯状态检测
                if (!ex.response) {
                    var error_1 = {
                        msg: "服务端连接异常，请检查服务端状态."
                    };
                    console.error(error_1.msg);
                    return loadingPromise.then(emitResult(function () {
                        observer.error(error_1);
                    }));
                }
                // 错误类型检测
                switch (ex.response.status) {
                    case 403:
                        {
                            //
                        }
                        break;
                }
            });
        });
        return observable;
    };
    NetService.upload = function (file) {
        var headers = {
            'Content-Type': 'multipart/form-data'
        };
        var token = storage_service["a" /* StorageService */].getItem('userToken') || '';
        if (token) {
            headers = assign_default()(headers, {
                'authorization': token
            });
        }
        var formData = new FormData();
        formData.append('file', file);
        return axios_default()({
            baseURL: app_config.url.server,
            url: NetService.generateRequestUrl(fileService.fileUploadController.uploadFileGrid),
            method: 'post',
            data: formData,
            headers: headers
        }).then(function (res) {
            return res.data;
        });
    };
    return NetService;
}();


/***/ }),

/***/ "2JjU":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("ZYEF");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("013506db", content, true, {});

/***/ }),

/***/ "2OOm":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return carShowManagementService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_object_define_property__ = __webpack_require__("C4MV");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_object_define_property___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_object_define_property__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof__ = __webpack_require__("pFYg");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_get_own_property_descriptor__ = __webpack_require__("K6ED");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_get_own_property_descriptor___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_get_own_property_descriptor__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__utils_net_service__ = __webpack_require__("1pVc");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__core_decorator__ = __webpack_require__("f3r7");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__config_server_manage_service__ = __webpack_require__("afVn");



var __decorate = this && this.__decorate || function (decorators, target, key, desc) {
    var c = arguments.length,
        r = c < 3 ? target : desc === null ? desc = __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_get_own_property_descriptor___default()(target, key) : desc,
        d;
    if ((typeof Reflect === "undefined" ? "undefined" : __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof___default()(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
        if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    }return c > 3 && r && __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_object_define_property___default()(target, key, r), r;
};



var carShowManagementService = /** @class */function () {
    function carShowManagementService() {}
    carShowManagementService.prototype.getTopTenCarBrandList = function () {
        return this.netService.send({
            server: __WEBPACK_IMPORTED_MODULE_5__config_server_manage_service__["a" /* manageService */].carShowManagementController.getTopTenCarBrandList
        });
    };
    carShowManagementService.prototype.getAllCarBrandList = function () {
        return this.netService.send({
            server: __WEBPACK_IMPORTED_MODULE_5__config_server_manage_service__["a" /* manageService */].carShowManagementController.getAllCarBrandList
        });
    };
    carShowManagementService.prototype.getGoodCarShowModelList = function () {
        return this.netService.send({
            server: __WEBPACK_IMPORTED_MODULE_5__config_server_manage_service__["a" /* manageService */].carShowManagementController.getGoodCarShowModelList
        });
    };
    /**
     * 根据条件搜索汽车列表
     * @param param0 brandId：8非必填项， 品牌id
     * @param param1 name 非必填 品牌名称 ，车系名称，车辆名称
     */
    carShowManagementService.prototype.searchCarList = function (_a) {
        var brandId = _a.brandId,
            name = _a.name;
        return this.netService.send({
            server: __WEBPACK_IMPORTED_MODULE_5__config_server_manage_service__["a" /* manageService */].carShowManagementController.getCarShowModelListByBrandIdAndName,
            data: {
                brandId: brandId || '',
                name: name || ''
            }
        });
    };
    __decorate([Object(__WEBPACK_IMPORTED_MODULE_4__core_decorator__["c" /* Inject */])(__WEBPACK_IMPORTED_MODULE_3__utils_net_service__["NetService"])], carShowManagementService.prototype, "netService", void 0);
    __decorate([Object(__WEBPACK_IMPORTED_MODULE_4__core_decorator__["a" /* Debounce */])()], carShowManagementService.prototype, "getTopTenCarBrandList", null);
    __decorate([Object(__WEBPACK_IMPORTED_MODULE_4__core_decorator__["a" /* Debounce */])()], carShowManagementService.prototype, "getAllCarBrandList", null);
    __decorate([Object(__WEBPACK_IMPORTED_MODULE_4__core_decorator__["a" /* Debounce */])()], carShowManagementService.prototype, "getGoodCarShowModelList", null);
    __decorate([Object(__WEBPACK_IMPORTED_MODULE_4__core_decorator__["a" /* Debounce */])()], carShowManagementService.prototype, "searchCarList", null);
    return carShowManagementService;
}();


/***/ }),

/***/ "2g+w":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("GDWw");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("11fa55e5", content, true, {});

/***/ }),

/***/ "30eR":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".page.all-vehicles .logo[data-v-2e872e26]{width:20%;float:left}.page.all-vehicles .logo .logoDetails[data-v-2e872e26]{font-size:12px}", ""]);

// exports


/***/ }),

/***/ "3mjx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return StorageService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_typeof__ = __webpack_require__("pFYg");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_typeof___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_typeof__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_json_stringify__ = __webpack_require__("mvHQ");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_json_stringify___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_json_stringify__);


var defaultStorage = 'local';
var storageTypes = ['local', 'session'];
var StorageService = /** @class */function () {
    function StorageService(type) {
        // 设置storage类型
        this.storageType = type || defaultStorage;
        // storage类型检测
        if (!storageTypes.includes(this.storageType)) {
            console.warn('storage类型错误');
            this.storageType = defaultStorage;
        }
        // 设置storage
        this.storage = {
            'local': localStorage,
            'session': sessionStorage
        }[this.storageType];
    }
    /**
     * 获取当前存储类型对象
     * @param {*} type
     */
    StorageService.getStorage = function (type) {
        var storage;
        switch (type) {
            case 'local':
                {
                    storage = StorageService.instance['local'];
                    if (!storage) {
                        storage = new StorageService('local');
                        StorageService.instance['local'] = storage;
                    }
                    return storage;
                }
            case 'session':
                {
                    storage = StorageService.instance['session'];
                    if (!storage) {
                        storage = new StorageService('session');
                        StorageService.instance['session'] = storage;
                    }
                    return storage;
                }
            default:
                {
                    console.warn('请输入storage类型');
                    storage = StorageService.instance[defaultStorage];
                    if (!storage) {
                        storage = new StorageService('defaultStorage');
                        StorageService.instance['defaultStorage'] = storage;
                    }
                    return storage;
                }
        }
    };
    /* 数据存储
    * @param { String } key
    * @param { Object } value
    * @param { Object } extend 数据扩展标识
    */
    StorageService.prototype.setItem = function (key, value) {
        // key必须为字符串
        if (!key || typeof key !== 'string') {
            console.log('key参数错误.');
            return;
        }
        var data;
        // 取消对扩展的支持
        // 统一将数据转换为json格式进行存储
        if (value === undefined) {
            // 返回空数据
            data = __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_json_stringify___default()("");
        } else if ((typeof value === 'undefined' ? 'undefined' : __WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_typeof___default()(value)) === 'object') {
            data = __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_json_stringify___default()(value);
        } else {
            data = value;
        }
        this.storage.setItem(key, data);
    };
    /**
     * 获取存储数据
     * @param {Object} key
     */
    StorageService.prototype.getItem = function (key) {
        if (!key || typeof key !== 'string') {
            console.error('key参数错误.');
            return;
        }
        var data = this.storage.getItem(key);
        // 统一讲数据转换为json格式进行存储
        try {
            if (data !== '' && data !== undefined) {
                return JSON.parse(data);
            } else {
                return '';
            }
        } catch (ex) {
            return data;
        }
    };
    /**
     * 删除数据对象
     * @param {Object} key
     */
    StorageService.prototype.removeItem = function (key) {
        this.storage.removeItem(key);
    };
    StorageService.getItem = function (key) {
        return this.getStorage(defaultStorage).getItem(key);
    };
    StorageService.setItem = function (key, value) {
        return this.getStorage(defaultStorage).setItem(key, value);
    };
    StorageService.removeItem = function (key) {
        this.getStorage(defaultStorage).removeItem(key);
    };
    StorageService.instance = {};
    return StorageService;
}();


/***/ }),

/***/ "6P+K":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("evdC");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("88948408", content, true, {});

/***/ }),

/***/ "6fZv":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("+unC");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("1a2951d6", content, true, {});

/***/ }),

/***/ "6z/E":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = ({
    'province_list': {
        '110000': '北京市',
        '120000': '天津市',
        '130000': '河北省',
        '140000': '山西省',
        '150000': '内蒙古自治区',
        '210000': '辽宁省',
        '220000': '吉林省',
        '230000': '黑龙江省',
        '310000': '上海市',
        '320000': '江苏省',
        '330000': '浙江省',
        '340000': '安徽省',
        '350000': '福建省',
        '360000': '江西省',
        '370000': '山东省',
        '410000': '河南省',
        '420000': '湖北省',
        '430000': '湖南省',
        '440000': '广东省',
        '450000': '广西壮族自治区',
        '460000': '海南省',
        '500000': '重庆市',
        '510000': '四川省',
        '520000': '贵州省',
        '530000': '云南省',
        '540000': '西藏自治区',
        '610000': '陕西省',
        '620000': '甘肃省',
        '630000': '青海省',
        '640000': '宁夏回族自治区',
        '650000': '新疆维吾尔自治区',
        '710000': '台湾省',
        '810000': '香港特别行政区',
        '820000': '澳门特别行政区'
    },
    'city_list': {
        '110100': '北京市',
        '110200': '县',
        '120100': '天津市',
        '120200': '县',
        '130100': '石家庄市',
        '130200': '唐山市',
        '130300': '秦皇岛市',
        '130400': '邯郸市',
        '130500': '邢台市',
        '130600': '保定市',
        '130700': '张家口市',
        '130800': '承德市',
        '130900': '沧州市',
        '131000': '廊坊市',
        '131100': '衡水市',
        '139000': '省直辖县',
        '140100': '太原市',
        '140200': '大同市',
        '140300': '阳泉市',
        '140400': '长治市',
        '140500': '晋城市',
        '140600': '朔州市',
        '140700': '晋中市',
        '140800': '运城市',
        '140900': '忻州市',
        '141000': '临汾市',
        '141100': '吕梁市',
        '150100': '呼和浩特市',
        '150200': '包头市',
        '150300': '乌海市',
        '150400': '赤峰市',
        '150500': '通辽市',
        '150600': '鄂尔多斯市',
        '150700': '呼伦贝尔市',
        '150800': '巴彦淖尔市',
        '150900': '乌兰察布市',
        '152200': '兴安盟',
        '152500': '锡林郭勒盟',
        '152900': '阿拉善盟',
        '210100': '沈阳市',
        '210200': '大连市',
        '210300': '鞍山市',
        '210400': '抚顺市',
        '210500': '本溪市',
        '210600': '丹东市',
        '210700': '锦州市',
        '210800': '营口市',
        '210900': '阜新市',
        '211000': '辽阳市',
        '211100': '盘锦市',
        '211200': '铁岭市',
        '211300': '朝阳市',
        '211400': '葫芦岛市',
        '220100': '长春市',
        '220200': '吉林市',
        '220300': '四平市',
        '220400': '辽源市',
        '220500': '通化市',
        '220600': '白山市',
        '220700': '松原市',
        '220800': '白城市',
        '222400': '延边朝鲜族自治州',
        '230100': '哈尔滨市',
        '230200': '齐齐哈尔市',
        '230300': '鸡西市',
        '230400': '鹤岗市',
        '230500': '双鸭山市',
        '230600': '大庆市',
        '230700': '伊春市',
        '230800': '佳木斯市',
        '230900': '七台河市',
        '231000': '牡丹江市',
        '231100': '黑河市',
        '231200': '绥化市',
        '232700': '大兴安岭地区',
        '310100': '上海市',
        '310200': '县',
        '320100': '南京市',
        '320200': '无锡市',
        '320300': '徐州市',
        '320400': '常州市',
        '320500': '苏州市',
        '320600': '南通市',
        '320700': '连云港市',
        '320800': '淮安市',
        '320900': '盐城市',
        '321000': '扬州市',
        '321100': '镇江市',
        '321200': '泰州市',
        '321300': '宿迁市',
        '330100': '杭州市',
        '330200': '宁波市',
        '330300': '温州市',
        '330400': '嘉兴市',
        '330500': '湖州市',
        '330600': '绍兴市',
        '330700': '金华市',
        '330800': '衢州市',
        '330900': '舟山市',
        '331000': '台州市',
        '331100': '丽水市',
        '340100': '合肥市',
        '340200': '芜湖市',
        '340300': '蚌埠市',
        '340400': '淮南市',
        '340500': '马鞍山市',
        '340600': '淮北市',
        '340700': '铜陵市',
        '340800': '安庆市',
        '341000': '黄山市',
        '341100': '滁州市',
        '341200': '阜阳市',
        '341300': '宿州市',
        '341500': '六安市',
        '341600': '亳州市',
        '341700': '池州市',
        '341800': '宣城市',
        '350100': '福州市',
        '350200': '厦门市',
        '350300': '莆田市',
        '350400': '三明市',
        '350500': '泉州市',
        '350600': '漳州市',
        '350700': '南平市',
        '350800': '龙岩市',
        '350900': '宁德市',
        '360100': '南昌市',
        '360200': '景德镇市',
        '360300': '萍乡市',
        '360400': '九江市',
        '360500': '新余市',
        '360600': '鹰潭市',
        '360700': '赣州市',
        '360800': '吉安市',
        '360900': '宜春市',
        '361000': '抚州市',
        '361100': '上饶市',
        '370100': '济南市',
        '370200': '青岛市',
        '370300': '淄博市',
        '370400': '枣庄市',
        '370500': '东营市',
        '370600': '烟台市',
        '370700': '潍坊市',
        '370800': '济宁市',
        '370900': '泰安市',
        '371000': '威海市',
        '371100': '日照市',
        '371200': '莱芜市',
        '371300': '临沂市',
        '371400': '德州市',
        '371500': '聊城市',
        '371600': '滨州市',
        '371700': '菏泽市',
        '410100': '郑州市',
        '410200': '开封市',
        '410300': '洛阳市',
        '410400': '平顶山市',
        '410500': '安阳市',
        '410600': '鹤壁市',
        '410700': '新乡市',
        '410800': '焦作市',
        '410900': '濮阳市',
        '411000': '许昌市',
        '411100': '漯河市',
        '411200': '三门峡市',
        '411300': '南阳市',
        '411400': '商丘市',
        '411500': '信阳市',
        '411600': '周口市',
        '411700': '驻马店市',
        '419000': '省直辖县',
        '420100': '武汉市',
        '420200': '黄石市',
        '420300': '十堰市',
        '420500': '宜昌市',
        '420600': '襄阳市',
        '420700': '鄂州市',
        '420800': '荆门市',
        '420900': '孝感市',
        '421000': '荆州市',
        '421100': '黄冈市',
        '421200': '咸宁市',
        '421300': '随州市',
        '422800': '恩施土家族苗族自治州',
        '429000': '省直辖县',
        '430100': '长沙市',
        '430200': '株洲市',
        '430300': '湘潭市',
        '430400': '衡阳市',
        '430500': '邵阳市',
        '430600': '岳阳市',
        '430700': '常德市',
        '430800': '张家界市',
        '430900': '益阳市',
        '431000': '郴州市',
        '431100': '永州市',
        '431200': '怀化市',
        '431300': '娄底市',
        '433100': '湘西土家族苗族自治州',
        '440100': '广州市',
        '440200': '韶关市',
        '440300': '深圳市',
        '440400': '珠海市',
        '440500': '汕头市',
        '440600': '佛山市',
        '440700': '江门市',
        '440800': '湛江市',
        '440900': '茂名市',
        '441200': '肇庆市',
        '441300': '惠州市',
        '441400': '梅州市',
        '441500': '汕尾市',
        '441600': '河源市',
        '441700': '阳江市',
        '441800': '清远市',
        '441900': '东莞市',
        '442000': '中山市',
        '445100': '潮州市',
        '445200': '揭阳市',
        '445300': '云浮市',
        '450100': '南宁市',
        '450200': '柳州市',
        '450300': '桂林市',
        '450400': '梧州市',
        '450500': '北海市',
        '450600': '防城港市',
        '450700': '钦州市',
        '450800': '贵港市',
        '450900': '玉林市',
        '451000': '百色市',
        '451100': '贺州市',
        '451200': '河池市',
        '451300': '来宾市',
        '451400': '崇左市',
        '460100': '海口市',
        '460200': '三亚市',
        '460300': '三沙市',
        '469000': '省直辖县',
        '500100': '重庆市',
        '500200': '县',
        '510100': '成都市',
        '510300': '自贡市',
        '510400': '攀枝花市',
        '510500': '泸州市',
        '510600': '德阳市',
        '510700': '绵阳市',
        '510800': '广元市',
        '510900': '遂宁市',
        '511000': '内江市',
        '511100': '乐山市',
        '511300': '南充市',
        '511400': '眉山市',
        '511500': '宜宾市',
        '511600': '广安市',
        '511700': '达州市',
        '511800': '雅安市',
        '511900': '巴中市',
        '512000': '资阳市',
        '513200': '阿坝藏族羌族自治州',
        '513300': '甘孜藏族自治州',
        '513400': '凉山彝族自治州',
        '520100': '贵阳市',
        '520200': '六盘水市',
        '520300': '遵义市',
        '520400': '安顺市',
        '520500': '毕节市',
        '520600': '铜仁市',
        '522300': '黔西南布依族苗族自治州',
        '522600': '黔东南苗族侗族自治州',
        '522700': '黔南布依族苗族自治州',
        '530100': '昆明市',
        '530300': '曲靖市',
        '530400': '玉溪市',
        '530500': '保山市',
        '530600': '昭通市',
        '530700': '丽江市',
        '530800': '普洱市',
        '530900': '临沧市',
        '532300': '楚雄彝族自治州',
        '532500': '红河哈尼族彝族自治州',
        '532600': '文山壮族苗族自治州',
        '532800': '西双版纳傣族自治州',
        '532900': '大理白族自治州',
        '533100': '德宏傣族景颇族自治州',
        '533300': '怒江傈僳族自治州',
        '533400': '迪庆藏族自治州',
        '540100': '拉萨市',
        '540200': '日喀则市',
        '540300': '昌都市',
        '540400': '林芝市',
        '542200': '山南地区',
        '542400': '那曲地区',
        '542500': '阿里地区',
        '610100': '西安市',
        '610200': '铜川市',
        '610300': '宝鸡市',
        '610400': '咸阳市',
        '610500': '渭南市',
        '610600': '延安市',
        '610700': '汉中市',
        '610800': '榆林市',
        '610900': '安康市',
        '611000': '商洛市',
        '620100': '兰州市',
        '620200': '嘉峪关市',
        '620300': '金昌市',
        '620400': '白银市',
        '620500': '天水市',
        '620600': '武威市',
        '620700': '张掖市',
        '620800': '平凉市',
        '620900': '酒泉市',
        '621000': '庆阳市',
        '621100': '定西市',
        '621200': '陇南市',
        '622900': '临夏回族自治州',
        '623000': '甘南藏族自治州',
        '630100': '西宁市',
        '630200': '海东市',
        '632200': '海北藏族自治州',
        '632300': '黄南藏族自治州',
        '632500': '海南藏族自治州',
        '632600': '果洛藏族自治州',
        '632700': '玉树藏族自治州',
        '632800': '海西蒙古族藏族自治州',
        '640100': '银川市',
        '640200': '石嘴山市',
        '640300': '吴忠市',
        '640400': '固原市',
        '640500': '中卫市',
        '650100': '乌鲁木齐市',
        '650200': '克拉玛依市',
        '650400': '吐鲁番市',
        '652200': '哈密地区',
        '652300': '昌吉回族自治州',
        '652700': '博尔塔拉蒙古自治州',
        '652800': '巴音郭楞蒙古自治州',
        '652900': '阿克苏地区',
        '653000': '克孜勒苏柯尔克孜自治州',
        '653100': '喀什地区',
        '653200': '和田地区',
        '654000': '伊犁哈萨克自治州',
        '654200': '塔城地区',
        '654300': '阿勒泰地区',
        '659000': '自治区直辖县级行政区划',
        '710100': '台北市',
        '710200': '高雄市',
        '710300': '台南市',
        '710400': '台中市',
        '710500': '金门县',
        '710600': '南投县',
        '710700': '基隆市',
        '710800': '新竹市',
        '710900': '嘉义市',
        '711100': '新北市',
        '711200': '宜兰县',
        '711300': '新竹县',
        '711400': '桃园县',
        '711500': '苗栗县',
        '711700': '彰化县',
        '711900': '嘉义县',
        '712100': '云林县',
        '712400': '屏东县',
        '712500': '台东县',
        '712600': '花莲县',
        '712700': '澎湖县',
        '712800': '连江县',
        '810100': '香港岛',
        '810200': '九龙',
        '810300': '新界',
        '820100': '澳门半岛',
        '820200': '离岛'
    },
    'county_list': {
        '110101': '东城区',
        '110102': '西城区',
        '110105': '朝阳区',
        '110106': '丰台区',
        '110107': '石景山区',
        '110108': '海淀区',
        '110109': '门头沟区',
        '110111': '房山区',
        '110112': '通州区',
        '110113': '顺义区',
        '110114': '昌平区',
        '110115': '大兴区',
        '110116': '怀柔区',
        '110117': '平谷区',
        '110228': '密云县',
        '110229': '延庆县',
        '120101': '和平区',
        '120102': '河东区',
        '120103': '河西区',
        '120104': '南开区',
        '120105': '河北区',
        '120106': '红桥区',
        '120110': '东丽区',
        '120111': '西青区',
        '120112': '津南区',
        '120113': '北辰区',
        '120114': '武清区',
        '120115': '宝坻区',
        '120116': '滨海新区',
        '120117': '宁河区',
        '120118': '静海区',
        '120225': '蓟县',
        '130102': '长安区',
        '130104': '桥西区',
        '130105': '新华区',
        '130107': '井陉矿区',
        '130108': '裕华区',
        '130109': '藁城区',
        '130110': '鹿泉区',
        '130111': '栾城区',
        '130121': '井陉县',
        '130123': '正定县',
        '130125': '行唐县',
        '130126': '灵寿县',
        '130127': '高邑县',
        '130128': '深泽县',
        '130129': '赞皇县',
        '130130': '无极县',
        '130131': '平山县',
        '130132': '元氏县',
        '130133': '赵县',
        '130183': '晋州市',
        '130184': '新乐市',
        '130202': '路南区',
        '130203': '路北区',
        '130204': '古冶区',
        '130205': '开平区',
        '130207': '丰南区',
        '130208': '丰润区',
        '130209': '曹妃甸区',
        '130223': '滦县',
        '130224': '滦南县',
        '130225': '乐亭县',
        '130227': '迁西县',
        '130229': '玉田县',
        '130281': '遵化市',
        '130283': '迁安市',
        '130302': '海港区',
        '130303': '山海关区',
        '130304': '北戴河区',
        '130306': '抚宁区',
        '130321': '青龙满族自治县',
        '130322': '昌黎县',
        '130324': '卢龙县',
        '130390': '经济技术开发区',
        '130402': '邯山区',
        '130403': '丛台区',
        '130404': '复兴区',
        '130406': '峰峰矿区',
        '130421': '邯郸县',
        '130423': '临漳县',
        '130424': '成安县',
        '130425': '大名县',
        '130426': '涉县',
        '130427': '磁县',
        '130428': '肥乡县',
        '130429': '永年县',
        '130430': '邱县',
        '130431': '鸡泽县',
        '130432': '广平县',
        '130433': '馆陶县',
        '130434': '魏县',
        '130435': '曲周县',
        '130481': '武安市',
        '130502': '桥东区',
        '130503': '桥西区',
        '130521': '邢台县',
        '130522': '临城县',
        '130523': '内丘县',
        '130524': '柏乡县',
        '130525': '隆尧县',
        '130526': '任县',
        '130527': '南和县',
        '130528': '宁晋县',
        '130529': '巨鹿县',
        '130530': '新河县',
        '130531': '广宗县',
        '130532': '平乡县',
        '130533': '威县',
        '130534': '清河县',
        '130535': '临西县',
        '130581': '南宫市',
        '130582': '沙河市',
        '130602': '竞秀区',
        '130606': '莲池区',
        '130607': '满城区',
        '130608': '清苑区',
        '130609': '徐水区',
        '130623': '涞水县',
        '130624': '阜平县',
        '130626': '定兴县',
        '130627': '唐县',
        '130628': '高阳县',
        '130629': '容城县',
        '130630': '涞源县',
        '130631': '望都县',
        '130632': '安新县',
        '130633': '易县',
        '130634': '曲阳县',
        '130635': '蠡县',
        '130636': '顺平县',
        '130637': '博野县',
        '130638': '雄县',
        '130681': '涿州市',
        '130683': '安国市',
        '130684': '高碑店市',
        '130702': '桥东区',
        '130703': '桥西区',
        '130705': '宣化区',
        '130706': '下花园区',
        '130721': '宣化县',
        '130722': '张北县',
        '130723': '康保县',
        '130724': '沽源县',
        '130725': '尚义县',
        '130726': '蔚县',
        '130727': '阳原县',
        '130728': '怀安县',
        '130729': '万全县',
        '130730': '怀来县',
        '130731': '涿鹿县',
        '130732': '赤城县',
        '130733': '崇礼县',
        '130802': '双桥区',
        '130803': '双滦区',
        '130804': '鹰手营子矿区',
        '130821': '承德县',
        '130822': '兴隆县',
        '130823': '平泉县',
        '130824': '滦平县',
        '130825': '隆化县',
        '130826': '丰宁满族自治县',
        '130827': '宽城满族自治县',
        '130828': '围场满族蒙古族自治县',
        '130902': '新华区',
        '130903': '运河区',
        '130921': '沧县',
        '130922': '青县',
        '130923': '东光县',
        '130924': '海兴县',
        '130925': '盐山县',
        '130926': '肃宁县',
        '130927': '南皮县',
        '130928': '吴桥县',
        '130929': '献县',
        '130930': '孟村回族自治县',
        '130981': '泊头市',
        '130982': '任丘市',
        '130983': '黄骅市',
        '130984': '河间市',
        '131002': '安次区',
        '131003': '广阳区',
        '131022': '固安县',
        '131023': '永清县',
        '131024': '香河县',
        '131025': '大城县',
        '131026': '文安县',
        '131028': '大厂回族自治县',
        '131081': '霸州市',
        '131082': '三河市',
        '131090': '开发区',
        '131091': '燕郊经济技术开发区',
        '131102': '桃城区',
        '131121': '枣强县',
        '131122': '武邑县',
        '131123': '武强县',
        '131124': '饶阳县',
        '131125': '安平县',
        '131126': '故城县',
        '131127': '景县',
        '131128': '阜城县',
        '131181': '冀州市',
        '131182': '深州市',
        '139001': '定州市',
        '139002': '辛集市',
        '140105': '小店区',
        '140106': '迎泽区',
        '140107': '杏花岭区',
        '140108': '尖草坪区',
        '140109': '万柏林区',
        '140110': '晋源区',
        '140121': '清徐县',
        '140122': '阳曲县',
        '140123': '娄烦县',
        '140181': '古交市',
        '140202': '城区',
        '140203': '矿区',
        '140211': '南郊区',
        '140212': '新荣区',
        '140221': '阳高县',
        '140222': '天镇县',
        '140223': '广灵县',
        '140224': '灵丘县',
        '140225': '浑源县',
        '140226': '左云县',
        '140227': '大同县',
        '140302': '城区',
        '140303': '矿区',
        '140311': '郊区',
        '140321': '平定县',
        '140322': '盂县',
        '140402': '城区',
        '140411': '郊区',
        '140421': '长治县',
        '140423': '襄垣县',
        '140424': '屯留县',
        '140425': '平顺县',
        '140426': '黎城县',
        '140427': '壶关县',
        '140428': '长子县',
        '140429': '武乡县',
        '140430': '沁县',
        '140431': '沁源县',
        '140481': '潞城市',
        '140502': '城区',
        '140521': '沁水县',
        '140522': '阳城县',
        '140524': '陵川县',
        '140525': '泽州县',
        '140581': '高平市',
        '140602': '朔城区',
        '140603': '平鲁区',
        '140621': '山阴县',
        '140622': '应县',
        '140623': '右玉县',
        '140624': '怀仁县',
        '140702': '榆次区',
        '140721': '榆社县',
        '140722': '左权县',
        '140723': '和顺县',
        '140724': '昔阳县',
        '140725': '寿阳县',
        '140726': '太谷县',
        '140727': '祁县',
        '140728': '平遥县',
        '140729': '灵石县',
        '140781': '介休市',
        '140802': '盐湖区',
        '140821': '临猗县',
        '140822': '万荣县',
        '140823': '闻喜县',
        '140824': '稷山县',
        '140825': '新绛县',
        '140826': '绛县',
        '140827': '垣曲县',
        '140828': '夏县',
        '140829': '平陆县',
        '140830': '芮城县',
        '140881': '永济市',
        '140882': '河津市',
        '140902': '忻府区',
        '140921': '定襄县',
        '140922': '五台县',
        '140923': '代县',
        '140924': '繁峙县',
        '140925': '宁武县',
        '140926': '静乐县',
        '140927': '神池县',
        '140928': '五寨县',
        '140929': '岢岚县',
        '140930': '河曲县',
        '140931': '保德县',
        '140932': '偏关县',
        '140981': '原平市',
        '141002': '尧都区',
        '141021': '曲沃县',
        '141022': '翼城县',
        '141023': '襄汾县',
        '141024': '洪洞县',
        '141025': '古县',
        '141026': '安泽县',
        '141027': '浮山县',
        '141028': '吉县',
        '141029': '乡宁县',
        '141030': '大宁县',
        '141031': '隰县',
        '141032': '永和县',
        '141033': '蒲县',
        '141034': '汾西县',
        '141081': '侯马市',
        '141082': '霍州市',
        '141102': '离石区',
        '141121': '文水县',
        '141122': '交城县',
        '141123': '兴县',
        '141124': '临县',
        '141125': '柳林县',
        '141126': '石楼县',
        '141127': '岚县',
        '141128': '方山县',
        '141129': '中阳县',
        '141130': '交口县',
        '141181': '孝义市',
        '141182': '汾阳市',
        '150102': '新城区',
        '150103': '回民区',
        '150104': '玉泉区',
        '150105': '赛罕区',
        '150121': '土默特左旗',
        '150122': '托克托县',
        '150123': '和林格尔县',
        '150124': '清水河县',
        '150125': '武川县',
        '150202': '东河区',
        '150203': '昆都仑区',
        '150204': '青山区',
        '150205': '石拐区',
        '150206': '白云鄂博矿区',
        '150207': '九原区',
        '150221': '土默特右旗',
        '150222': '固阳县',
        '150223': '达尔罕茂明安联合旗',
        '150302': '海勃湾区',
        '150303': '海南区',
        '150304': '乌达区',
        '150402': '红山区',
        '150403': '元宝山区',
        '150404': '松山区',
        '150421': '阿鲁科尔沁旗',
        '150422': '巴林左旗',
        '150423': '巴林右旗',
        '150424': '林西县',
        '150425': '克什克腾旗',
        '150426': '翁牛特旗',
        '150428': '喀喇沁旗',
        '150429': '宁城县',
        '150430': '敖汉旗',
        '150502': '科尔沁区',
        '150521': '科尔沁左翼中旗',
        '150522': '科尔沁左翼后旗',
        '150523': '开鲁县',
        '150524': '库伦旗',
        '150525': '奈曼旗',
        '150526': '扎鲁特旗',
        '150581': '霍林郭勒市',
        '150602': '东胜区',
        '150621': '达拉特旗',
        '150622': '准格尔旗',
        '150623': '鄂托克前旗',
        '150624': '鄂托克旗',
        '150625': '杭锦旗',
        '150626': '乌审旗',
        '150627': '伊金霍洛旗',
        '150702': '海拉尔区',
        '150703': '扎赉诺尔区',
        '150721': '阿荣旗',
        '150722': '莫力达瓦达斡尔族自治旗',
        '150723': '鄂伦春自治旗',
        '150724': '鄂温克族自治旗',
        '150725': '陈巴尔虎旗',
        '150726': '新巴尔虎左旗',
        '150727': '新巴尔虎右旗',
        '150781': '满洲里市',
        '150782': '牙克石市',
        '150783': '扎兰屯市',
        '150784': '额尔古纳市',
        '150785': '根河市',
        '150802': '临河区',
        '150821': '五原县',
        '150822': '磴口县',
        '150823': '乌拉特前旗',
        '150824': '乌拉特中旗',
        '150825': '乌拉特后旗',
        '150826': '杭锦后旗',
        '150902': '集宁区',
        '150921': '卓资县',
        '150922': '化德县',
        '150923': '商都县',
        '150924': '兴和县',
        '150925': '凉城县',
        '150926': '察哈尔右翼前旗',
        '150927': '察哈尔右翼中旗',
        '150928': '察哈尔右翼后旗',
        '150929': '四子王旗',
        '150981': '丰镇市',
        '152201': '乌兰浩特市',
        '152202': '阿尔山市',
        '152221': '科尔沁右翼前旗',
        '152222': '科尔沁右翼中旗',
        '152223': '扎赉特旗',
        '152224': '突泉县',
        '152501': '二连浩特市',
        '152502': '锡林浩特市',
        '152522': '阿巴嘎旗',
        '152523': '苏尼特左旗',
        '152524': '苏尼特右旗',
        '152525': '东乌珠穆沁旗',
        '152526': '西乌珠穆沁旗',
        '152527': '太仆寺旗',
        '152528': '镶黄旗',
        '152529': '正镶白旗',
        '152530': '正蓝旗',
        '152531': '多伦县',
        '152921': '阿拉善左旗',
        '152922': '阿拉善右旗',
        '152923': '额济纳旗',
        '210102': '和平区',
        '210103': '沈河区',
        '210104': '大东区',
        '210105': '皇姑区',
        '210106': '铁西区',
        '210111': '苏家屯区',
        '210112': '浑南区',
        '210113': '沈北新区',
        '210114': '于洪区',
        '210122': '辽中县',
        '210123': '康平县',
        '210124': '法库县',
        '210181': '新民市',
        '210190': '经济技术开发区',
        '210202': '中山区',
        '210203': '西岗区',
        '210204': '沙河口区',
        '210211': '甘井子区',
        '210212': '旅顺口区',
        '210213': '金州区',
        '210224': '长海县',
        '210281': '瓦房店市',
        '210282': '普兰店市',
        '210283': '庄河市',
        '210291': '大连经济技术开发区',
        '210292': '大连高新区',
        '210302': '铁东区',
        '210303': '铁西区',
        '210304': '立山区',
        '210311': '千山区',
        '210321': '台安县',
        '210323': '岫岩满族自治县',
        '210381': '海城市',
        '210390': '高新区',
        '210402': '新抚区',
        '210403': '东洲区',
        '210404': '望花区',
        '210411': '顺城区',
        '210421': '抚顺县',
        '210422': '新宾满族自治县',
        '210423': '清原满族自治县',
        '210502': '平山区',
        '210503': '溪湖区',
        '210504': '明山区',
        '210505': '南芬区',
        '210521': '本溪满族自治县',
        '210522': '桓仁满族自治县',
        '210602': '元宝区',
        '210603': '振兴区',
        '210604': '振安区',
        '210624': '宽甸满族自治县',
        '210681': '东港市',
        '210682': '凤城市',
        '210702': '古塔区',
        '210703': '凌河区',
        '210711': '太和区',
        '210726': '黑山县',
        '210727': '义县',
        '210781': '凌海市',
        '210782': '北镇市',
        '210793': '经济技术开发区',
        '210802': '站前区',
        '210803': '西市区',
        '210804': '鲅鱼圈区',
        '210811': '老边区',
        '210881': '盖州市',
        '210882': '大石桥市',
        '210902': '海州区',
        '210903': '新邱区',
        '210904': '太平区',
        '210905': '清河门区',
        '210911': '细河区',
        '210921': '阜新蒙古族自治县',
        '210922': '彰武县',
        '211002': '白塔区',
        '211003': '文圣区',
        '211004': '宏伟区',
        '211005': '弓长岭区',
        '211011': '太子河区',
        '211021': '辽阳县',
        '211081': '灯塔市',
        '211102': '双台子区',
        '211103': '兴隆台区',
        '211121': '大洼县',
        '211122': '盘山县',
        '211202': '银州区',
        '211204': '清河区',
        '211221': '铁岭县',
        '211223': '西丰县',
        '211224': '昌图县',
        '211281': '调兵山市',
        '211282': '开原市',
        '211302': '双塔区',
        '211303': '龙城区',
        '211321': '朝阳县',
        '211322': '建平县',
        '211324': '喀喇沁左翼蒙古族自治县',
        '211381': '北票市',
        '211382': '凌源市',
        '211402': '连山区',
        '211403': '龙港区',
        '211404': '南票区',
        '211421': '绥中县',
        '211422': '建昌县',
        '211481': '兴城市',
        '220102': '南关区',
        '220103': '宽城区',
        '220104': '朝阳区',
        '220105': '二道区',
        '220106': '绿园区',
        '220112': '双阳区',
        '220113': '九台区',
        '220122': '农安县',
        '220182': '榆树市',
        '220183': '德惠市',
        '220190': '高新技术产业开发区',
        '220191': '汽车产业开发区',
        '220192': '经济技术开发区',
        '220202': '昌邑区',
        '220203': '龙潭区',
        '220204': '船营区',
        '220211': '丰满区',
        '220221': '永吉县',
        '220281': '蛟河市',
        '220282': '桦甸市',
        '220283': '舒兰市',
        '220284': '磐石市',
        '220302': '铁西区',
        '220303': '铁东区',
        '220322': '梨树县',
        '220323': '伊通满族自治县',
        '220381': '公主岭市',
        '220382': '双辽市',
        '220402': '龙山区',
        '220403': '西安区',
        '220421': '东丰县',
        '220422': '东辽县',
        '220502': '东昌区',
        '220503': '二道江区',
        '220521': '通化县',
        '220523': '辉南县',
        '220524': '柳河县',
        '220581': '梅河口市',
        '220582': '集安市',
        '220602': '浑江区',
        '220605': '江源区',
        '220621': '抚松县',
        '220622': '靖宇县',
        '220623': '长白朝鲜族自治县',
        '220681': '临江市',
        '220702': '宁江区',
        '220721': '前郭尔罗斯蒙古族自治县',
        '220722': '长岭县',
        '220723': '乾安县',
        '220781': '扶余市',
        '220802': '洮北区',
        '220821': '镇赉县',
        '220822': '通榆县',
        '220881': '洮南市',
        '220882': '大安市',
        '221090': '工业园区',
        '222401': '延吉市',
        '222402': '图们市',
        '222403': '敦化市',
        '222404': '珲春市',
        '222405': '龙井市',
        '222406': '和龙市',
        '222424': '汪清县',
        '222426': '安图县',
        '230102': '道里区',
        '230103': '南岗区',
        '230104': '道外区',
        '230108': '平房区',
        '230109': '松北区',
        '230110': '香坊区',
        '230111': '呼兰区',
        '230112': '阿城区',
        '230113': '双城区',
        '230123': '依兰县',
        '230124': '方正县',
        '230125': '宾县',
        '230126': '巴彦县',
        '230127': '木兰县',
        '230128': '通河县',
        '230129': '延寿县',
        '230183': '尚志市',
        '230184': '五常市',
        '230202': '龙沙区',
        '230203': '建华区',
        '230204': '铁锋区',
        '230205': '昂昂溪区',
        '230206': '富拉尔基区',
        '230207': '碾子山区',
        '230208': '梅里斯达斡尔族区',
        '230221': '龙江县',
        '230223': '依安县',
        '230224': '泰来县',
        '230225': '甘南县',
        '230227': '富裕县',
        '230229': '克山县',
        '230230': '克东县',
        '230231': '拜泉县',
        '230281': '讷河市',
        '230302': '鸡冠区',
        '230303': '恒山区',
        '230304': '滴道区',
        '230305': '梨树区',
        '230306': '城子河区',
        '230307': '麻山区',
        '230321': '鸡东县',
        '230381': '虎林市',
        '230382': '密山市',
        '230402': '向阳区',
        '230403': '工农区',
        '230404': '南山区',
        '230405': '兴安区',
        '230406': '东山区',
        '230407': '兴山区',
        '230421': '萝北县',
        '230422': '绥滨县',
        '230502': '尖山区',
        '230503': '岭东区',
        '230505': '四方台区',
        '230506': '宝山区',
        '230521': '集贤县',
        '230522': '友谊县',
        '230523': '宝清县',
        '230524': '饶河县',
        '230602': '萨尔图区',
        '230603': '龙凤区',
        '230604': '让胡路区',
        '230605': '红岗区',
        '230606': '大同区',
        '230621': '肇州县',
        '230622': '肇源县',
        '230623': '林甸县',
        '230624': '杜尔伯特蒙古族自治县',
        '230702': '伊春区',
        '230703': '南岔区',
        '230704': '友好区',
        '230705': '西林区',
        '230706': '翠峦区',
        '230707': '新青区',
        '230708': '美溪区',
        '230709': '金山屯区',
        '230710': '五营区',
        '230711': '乌马河区',
        '230712': '汤旺河区',
        '230713': '带岭区',
        '230714': '乌伊岭区',
        '230715': '红星区',
        '230716': '上甘岭区',
        '230722': '嘉荫县',
        '230781': '铁力市',
        '230803': '向阳区',
        '230804': '前进区',
        '230805': '东风区',
        '230811': '郊区',
        '230822': '桦南县',
        '230826': '桦川县',
        '230828': '汤原县',
        '230833': '抚远县',
        '230881': '同江市',
        '230882': '富锦市',
        '230902': '新兴区',
        '230903': '桃山区',
        '230904': '茄子河区',
        '230921': '勃利县',
        '231002': '东安区',
        '231003': '阳明区',
        '231004': '爱民区',
        '231005': '西安区',
        '231024': '东宁县',
        '231025': '林口县',
        '231081': '绥芬河市',
        '231083': '海林市',
        '231084': '宁安市',
        '231085': '穆棱市',
        '231102': '爱辉区',
        '231121': '嫩江县',
        '231123': '逊克县',
        '231124': '孙吴县',
        '231181': '北安市',
        '231182': '五大连池市',
        '231202': '北林区',
        '231221': '望奎县',
        '231222': '兰西县',
        '231223': '青冈县',
        '231224': '庆安县',
        '231225': '明水县',
        '231226': '绥棱县',
        '231281': '安达市',
        '231282': '肇东市',
        '231283': '海伦市',
        '232721': '呼玛县',
        '232722': '塔河县',
        '232723': '漠河县',
        '232790': '松岭区',
        '232791': '呼中区',
        '232792': '加格达奇区',
        '232793': '新林区',
        '264290': '威海临港经济技术开发区',
        '310101': '黄浦区',
        '310104': '徐汇区',
        '310105': '长宁区',
        '310106': '静安区',
        '310107': '普陀区',
        '310108': '闸北区',
        '310109': '虹口区',
        '310110': '杨浦区',
        '310112': '闵行区',
        '310113': '宝山区',
        '310114': '嘉定区',
        '310115': '浦东新区',
        '310116': '金山区',
        '310117': '松江区',
        '310118': '青浦区',
        '310120': '奉贤区',
        '310230': '崇明县',
        '320102': '玄武区',
        '320104': '秦淮区',
        '320105': '建邺区',
        '320106': '鼓楼区',
        '320111': '浦口区',
        '320113': '栖霞区',
        '320114': '雨花台区',
        '320115': '江宁区',
        '320116': '六合区',
        '320117': '溧水区',
        '320118': '高淳区',
        '320202': '崇安区',
        '320203': '南长区',
        '320204': '北塘区',
        '320205': '锡山区',
        '320206': '惠山区',
        '320211': '滨湖区',
        '320281': '江阴市',
        '320282': '宜兴市',
        '320290': '新区',
        '320302': '鼓楼区',
        '320303': '云龙区',
        '320305': '贾汪区',
        '320311': '泉山区',
        '320312': '铜山区',
        '320321': '丰县',
        '320322': '沛县',
        '320324': '睢宁县',
        '320381': '新沂市',
        '320382': '邳州市',
        '320390': '金山桥开发区',
        '320391': '工业园区',
        '320402': '天宁区',
        '320404': '钟楼区',
        '320411': '新北区',
        '320412': '武进区',
        '320413': '金坛区',
        '320481': '溧阳市',
        '320505': '虎丘区',
        '320506': '吴中区',
        '320507': '相城区',
        '320508': '姑苏区',
        '320509': '吴江区',
        '320581': '常熟市',
        '320582': '张家港市',
        '320583': '昆山市',
        '320585': '太仓市',
        '320590': '工业园区',
        '320591': '高新区',
        '320602': '崇川区',
        '320611': '港闸区',
        '320612': '通州区',
        '320621': '海安县',
        '320623': '如东县',
        '320681': '启东市',
        '320682': '如皋市',
        '320684': '海门市',
        '320690': '南通经济技术开发区',
        '320691': '高新区',
        '320703': '连云区',
        '320706': '海州区',
        '320707': '赣榆区',
        '320722': '东海县',
        '320723': '灌云县',
        '320724': '灌南县',
        '320802': '清河区',
        '320803': '淮安区',
        '320804': '淮阴区',
        '320811': '清浦区',
        '320826': '涟水县',
        '320829': '洪泽县',
        '320830': '盱眙县',
        '320831': '金湖县',
        '320890': '经济开发区',
        '320902': '亭湖区',
        '320903': '盐都区',
        '320904': '大丰区',
        '320921': '响水县',
        '320922': '滨海县',
        '320923': '阜宁县',
        '320924': '射阳县',
        '320925': '建湖县',
        '320981': '东台市',
        '321002': '广陵区',
        '321003': '邗江区',
        '321012': '江都区',
        '321023': '宝应县',
        '321081': '仪征市',
        '321084': '高邮市',
        '321090': '经济开发区',
        '321102': '京口区',
        '321111': '润州区',
        '321112': '丹徒区',
        '321181': '丹阳市',
        '321182': '扬中市',
        '321183': '句容市',
        '321202': '海陵区',
        '321203': '高港区',
        '321204': '姜堰区',
        '321281': '兴化市',
        '321282': '靖江市',
        '321283': '泰兴市',
        '321302': '宿城区',
        '321311': '宿豫区',
        '321322': '沭阳县',
        '321323': '泗阳县',
        '321324': '泗洪县',
        '321390': '宿迁经济开发区',
        '330102': '上城区',
        '330103': '下城区',
        '330104': '江干区',
        '330105': '拱墅区',
        '330106': '西湖区',
        '330108': '滨江区',
        '330109': '萧山区',
        '330110': '余杭区',
        '330111': '富阳区',
        '330122': '桐庐县',
        '330127': '淳安县',
        '330182': '建德市',
        '330185': '临安市',
        '330203': '海曙区',
        '330204': '江东区',
        '330205': '江北区',
        '330206': '北仑区',
        '330211': '镇海区',
        '330212': '鄞州区',
        '330225': '象山县',
        '330226': '宁海县',
        '330281': '余姚市',
        '330282': '慈溪市',
        '330283': '奉化市',
        '330290': '高新科技开发区',
        '330302': '鹿城区',
        '330303': '龙湾区',
        '330304': '瓯海区',
        '330305': '洞头区',
        '330324': '永嘉县',
        '330326': '平阳县',
        '330327': '苍南县',
        '330328': '文成县',
        '330329': '泰顺县',
        '330381': '瑞安市',
        '330382': '乐清市',
        '330402': '南湖区',
        '330411': '秀洲区',
        '330421': '嘉善县',
        '330424': '海盐县',
        '330481': '海宁市',
        '330482': '平湖市',
        '330483': '桐乡市',
        '330502': '吴兴区',
        '330503': '南浔区',
        '330521': '德清县',
        '330522': '长兴县',
        '330523': '安吉县',
        '330602': '越城区',
        '330603': '柯桥区',
        '330604': '上虞区',
        '330624': '新昌县',
        '330681': '诸暨市',
        '330683': '嵊州市',
        '330702': '婺城区',
        '330703': '金东区',
        '330723': '武义县',
        '330726': '浦江县',
        '330727': '磐安县',
        '330781': '兰溪市',
        '330782': '义乌市',
        '330783': '东阳市',
        '330784': '永康市',
        '330802': '柯城区',
        '330803': '衢江区',
        '330822': '常山县',
        '330824': '开化县',
        '330825': '龙游县',
        '330881': '江山市',
        '330902': '定海区',
        '330903': '普陀区',
        '330921': '岱山县',
        '330922': '嵊泗县',
        '331002': '椒江区',
        '331003': '黄岩区',
        '331004': '路桥区',
        '331021': '玉环县',
        '331022': '三门县',
        '331023': '天台县',
        '331024': '仙居县',
        '331081': '温岭市',
        '331082': '临海市',
        '331102': '莲都区',
        '331121': '青田县',
        '331122': '缙云县',
        '331123': '遂昌县',
        '331124': '松阳县',
        '331125': '云和县',
        '331126': '庆元县',
        '331127': '景宁畲族自治县',
        '331181': '龙泉市',
        '340102': '瑶海区',
        '340103': '庐阳区',
        '340104': '蜀山区',
        '340111': '包河区',
        '340121': '长丰县',
        '340122': '肥东县',
        '340123': '肥西县',
        '340124': '庐江县',
        '340181': '巢湖市',
        '340190': '高新技术开发区',
        '340191': '经济技术开发区',
        '340192': '北城新区',
        '340193': '政务文化新区',
        '340194': '滨湖新区',
        '340195': '新站高新区',
        '340202': '镜湖区',
        '340203': '弋江区',
        '340207': '鸠江区',
        '340208': '三山区',
        '340221': '芜湖县',
        '340222': '繁昌县',
        '340223': '南陵县',
        '340225': '无为县',
        '340302': '龙子湖区',
        '340303': '蚌山区',
        '340304': '禹会区',
        '340311': '淮上区',
        '340321': '怀远县',
        '340322': '五河县',
        '340323': '固镇县',
        '340402': '大通区',
        '340403': '田家庵区',
        '340404': '谢家集区',
        '340405': '八公山区',
        '340406': '潘集区',
        '340421': '凤台县',
        '340490': '淮南高新技术产业开发区',
        '340503': '花山区',
        '340504': '雨山区',
        '340506': '博望区',
        '340521': '当涂县',
        '340522': '含山县',
        '340523': '和县',
        '340602': '杜集区',
        '340603': '相山区',
        '340604': '烈山区',
        '340621': '濉溪县',
        '340702': '铜官山区',
        '340703': '狮子山区',
        '340711': '郊区',
        '340721': '铜陵县',
        '340802': '迎江区',
        '340803': '大观区',
        '340811': '宜秀区',
        '340822': '怀宁县',
        '340823': '枞阳县',
        '340824': '潜山县',
        '340825': '太湖县',
        '340826': '宿松县',
        '340827': '望江县',
        '340828': '岳西县',
        '340881': '桐城市',
        '340890': '安庆经济技术开发区',
        '341002': '屯溪区',
        '341003': '黄山区',
        '341004': '徽州区',
        '341021': '歙县',
        '341022': '休宁县',
        '341023': '黟县',
        '341024': '祁门县',
        '341102': '琅琊区',
        '341103': '南谯区',
        '341122': '来安县',
        '341124': '全椒县',
        '341125': '定远县',
        '341126': '凤阳县',
        '341181': '天长市',
        '341182': '明光市',
        '341202': '颍州区',
        '341203': '颍东区',
        '341204': '颍泉区',
        '341221': '临泉县',
        '341222': '太和县',
        '341225': '阜南县',
        '341226': '颍上县',
        '341282': '界首市',
        '341290': '阜阳经济技术开发区',
        '341302': '埇桥区',
        '341321': '砀山县',
        '341322': '萧县',
        '341323': '灵璧县',
        '341324': '泗县',
        '341390': '经济开发区',
        '341502': '金安区',
        '341503': '裕安区',
        '341521': '寿县',
        '341522': '霍邱县',
        '341523': '舒城县',
        '341524': '金寨县',
        '341525': '霍山县',
        '341602': '谯城区',
        '341621': '涡阳县',
        '341622': '蒙城县',
        '341623': '利辛县',
        '341702': '贵池区',
        '341721': '东至县',
        '341722': '石台县',
        '341723': '青阳县',
        '341802': '宣州区',
        '341821': '郎溪县',
        '341822': '广德县',
        '341823': '泾县',
        '341824': '绩溪县',
        '341825': '旌德县',
        '341881': '宁国市',
        '350102': '鼓楼区',
        '350103': '台江区',
        '350104': '仓山区',
        '350105': '马尾区',
        '350111': '晋安区',
        '350121': '闽侯县',
        '350122': '连江县',
        '350123': '罗源县',
        '350124': '闽清县',
        '350125': '永泰县',
        '350128': '平潭县',
        '350181': '福清市',
        '350182': '长乐市',
        '350203': '思明区',
        '350205': '海沧区',
        '350206': '湖里区',
        '350211': '集美区',
        '350212': '同安区',
        '350213': '翔安区',
        '350302': '城厢区',
        '350303': '涵江区',
        '350304': '荔城区',
        '350305': '秀屿区',
        '350322': '仙游县',
        '350402': '梅列区',
        '350403': '三元区',
        '350421': '明溪县',
        '350423': '清流县',
        '350424': '宁化县',
        '350425': '大田县',
        '350426': '尤溪县',
        '350427': '沙县',
        '350428': '将乐县',
        '350429': '泰宁县',
        '350430': '建宁县',
        '350481': '永安市',
        '350502': '鲤城区',
        '350503': '丰泽区',
        '350504': '洛江区',
        '350505': '泉港区',
        '350521': '惠安县',
        '350524': '安溪县',
        '350525': '永春县',
        '350526': '德化县',
        '350527': '金门县',
        '350581': '石狮市',
        '350582': '晋江市',
        '350583': '南安市',
        '350602': '芗城区',
        '350603': '龙文区',
        '350622': '云霄县',
        '350623': '漳浦县',
        '350624': '诏安县',
        '350625': '长泰县',
        '350626': '东山县',
        '350627': '南靖县',
        '350628': '平和县',
        '350629': '华安县',
        '350681': '龙海市',
        '350702': '延平区',
        '350703': '建阳区',
        '350721': '顺昌县',
        '350722': '浦城县',
        '350723': '光泽县',
        '350724': '松溪县',
        '350725': '政和县',
        '350781': '邵武市',
        '350782': '武夷山市',
        '350783': '建瓯市',
        '350802': '新罗区',
        '350803': '永定区',
        '350821': '长汀县',
        '350823': '上杭县',
        '350824': '武平县',
        '350825': '连城县',
        '350881': '漳平市',
        '350902': '蕉城区',
        '350921': '霞浦县',
        '350922': '古田县',
        '350923': '屏南县',
        '350924': '寿宁县',
        '350925': '周宁县',
        '350926': '柘荣县',
        '350981': '福安市',
        '350982': '福鼎市',
        '350990': '东侨开发区',
        '360102': '东湖区',
        '360103': '西湖区',
        '360104': '青云谱区',
        '360105': '湾里区',
        '360111': '青山湖区',
        '360112': '新建区',
        '360121': '南昌县',
        '360123': '安义县',
        '360124': '进贤县',
        '360190': '经济技术开发区',
        '360191': '红谷滩新区',
        '360192': '高新区',
        '360202': '昌江区',
        '360203': '珠山区',
        '360222': '浮梁县',
        '360281': '乐平市',
        '360302': '安源区',
        '360313': '湘东区',
        '360321': '莲花县',
        '360322': '上栗县',
        '360323': '芦溪县',
        '360402': '庐山区',
        '360403': '浔阳区',
        '360421': '九江县',
        '360423': '武宁县',
        '360424': '修水县',
        '360425': '永修县',
        '360426': '德安县',
        '360427': '星子县',
        '360428': '都昌县',
        '360429': '湖口县',
        '360430': '彭泽县',
        '360481': '瑞昌市',
        '360482': '共青城市',
        '360490': '经济技术开发区',
        '360491': '八里湖新区',
        '360502': '渝水区',
        '360521': '分宜县',
        '360602': '月湖区',
        '360622': '余江县',
        '360681': '贵溪市',
        '360702': '章贡区',
        '360703': '南康区',
        '360721': '赣县',
        '360722': '信丰县',
        '360723': '大余县',
        '360724': '上犹县',
        '360725': '崇义县',
        '360726': '安远县',
        '360727': '龙南县',
        '360728': '定南县',
        '360729': '全南县',
        '360730': '宁都县',
        '360731': '于都县',
        '360732': '兴国县',
        '360733': '会昌县',
        '360734': '寻乌县',
        '360735': '石城县',
        '360781': '瑞金市',
        '360802': '吉州区',
        '360803': '青原区',
        '360821': '吉安县',
        '360822': '吉水县',
        '360823': '峡江县',
        '360824': '新干县',
        '360825': '永丰县',
        '360826': '泰和县',
        '360827': '遂川县',
        '360828': '万安县',
        '360829': '安福县',
        '360830': '永新县',
        '360881': '井冈山市',
        '360902': '袁州区',
        '360921': '奉新县',
        '360922': '万载县',
        '360923': '上高县',
        '360924': '宜丰县',
        '360925': '靖安县',
        '360926': '铜鼓县',
        '360981': '丰城市',
        '360982': '樟树市',
        '360983': '高安市',
        '361002': '临川区',
        '361021': '南城县',
        '361022': '黎川县',
        '361023': '南丰县',
        '361024': '崇仁县',
        '361025': '乐安县',
        '361026': '宜黄县',
        '361027': '金溪县',
        '361028': '资溪县',
        '361029': '东乡县',
        '361030': '广昌县',
        '361102': '信州区',
        '361103': '广丰区',
        '361121': '上饶县',
        '361123': '玉山县',
        '361124': '铅山县',
        '361125': '横峰县',
        '361126': '弋阳县',
        '361127': '余干县',
        '361128': '鄱阳县',
        '361129': '万年县',
        '361130': '婺源县',
        '361181': '德兴市',
        '370102': '历下区',
        '370103': '市中区',
        '370104': '槐荫区',
        '370105': '天桥区',
        '370112': '历城区',
        '370113': '长清区',
        '370124': '平阴县',
        '370125': '济阳县',
        '370126': '商河县',
        '370181': '章丘市',
        '370190': '高新区',
        '370202': '市南区',
        '370203': '市北区',
        '370211': '黄岛区',
        '370212': '崂山区',
        '370213': '李沧区',
        '370214': '城阳区',
        '370281': '胶州市',
        '370282': '即墨市',
        '370283': '平度市',
        '370285': '莱西市',
        '370290': '开发区',
        '370302': '淄川区',
        '370303': '张店区',
        '370304': '博山区',
        '370305': '临淄区',
        '370306': '周村区',
        '370321': '桓台县',
        '370322': '高青县',
        '370323': '沂源县',
        '370402': '市中区',
        '370403': '薛城区',
        '370404': '峄城区',
        '370405': '台儿庄区',
        '370406': '山亭区',
        '370481': '滕州市',
        '370502': '东营区',
        '370503': '河口区',
        '370521': '垦利县',
        '370522': '利津县',
        '370523': '广饶县',
        '370602': '芝罘区',
        '370611': '福山区',
        '370612': '牟平区',
        '370613': '莱山区',
        '370634': '长岛县',
        '370681': '龙口市',
        '370682': '莱阳市',
        '370683': '莱州市',
        '370684': '蓬莱市',
        '370685': '招远市',
        '370686': '栖霞市',
        '370687': '海阳市',
        '370690': '开发区',
        '370702': '潍城区',
        '370703': '寒亭区',
        '370704': '坊子区',
        '370705': '奎文区',
        '370724': '临朐县',
        '370725': '昌乐县',
        '370781': '青州市',
        '370782': '诸城市',
        '370783': '寿光市',
        '370784': '安丘市',
        '370785': '高密市',
        '370786': '昌邑市',
        '370790': '开发区',
        '370791': '高新区',
        '370811': '任城区',
        '370812': '兖州区',
        '370826': '微山县',
        '370827': '鱼台县',
        '370828': '金乡县',
        '370829': '嘉祥县',
        '370830': '汶上县',
        '370831': '泗水县',
        '370832': '梁山县',
        '370881': '曲阜市',
        '370883': '邹城市',
        '370890': '高新区',
        '370902': '泰山区',
        '370911': '岱岳区',
        '370921': '宁阳县',
        '370923': '东平县',
        '370982': '新泰市',
        '370983': '肥城市',
        '371002': '环翠区',
        '371003': '文登区',
        '371082': '荣成市',
        '371083': '乳山市',
        '371090': '工业新区',
        '371091': '经济技术开发区',
        '371102': '东港区',
        '371103': '岚山区',
        '371121': '五莲县',
        '371122': '莒县',
        '371202': '莱城区',
        '371203': '钢城区',
        '371302': '兰山区',
        '371311': '罗庄区',
        '371312': '河东区',
        '371321': '沂南县',
        '371322': '郯城县',
        '371323': '沂水县',
        '371324': '兰陵县',
        '371325': '费县',
        '371326': '平邑县',
        '371327': '莒南县',
        '371328': '蒙阴县',
        '371329': '临沭县',
        '371402': '德城区',
        '371403': '陵城区',
        '371422': '宁津县',
        '371423': '庆云县',
        '371424': '临邑县',
        '371425': '齐河县',
        '371426': '平原县',
        '371427': '夏津县',
        '371428': '武城县',
        '371481': '乐陵市',
        '371482': '禹城市',
        '371490': '德州经济技术开发区',
        '371502': '东昌府区',
        '371521': '阳谷县',
        '371522': '莘县',
        '371523': '茌平县',
        '371524': '东阿县',
        '371525': '冠县',
        '371526': '高唐县',
        '371581': '临清市',
        '371602': '滨城区',
        '371603': '沾化区',
        '371621': '惠民县',
        '371622': '阳信县',
        '371623': '无棣县',
        '371625': '博兴县',
        '371626': '邹平县',
        '371690': '北海新区',
        '371702': '牡丹区',
        '371721': '曹县',
        '371722': '单县',
        '371723': '成武县',
        '371724': '巨野县',
        '371725': '郓城县',
        '371726': '鄄城县',
        '371727': '定陶县',
        '371728': '东明县',
        '410102': '中原区',
        '410103': '二七区',
        '410104': '管城回族区',
        '410105': '金水区',
        '410106': '上街区',
        '410108': '惠济区',
        '410122': '中牟县',
        '410181': '巩义市',
        '410182': '荥阳市',
        '410183': '新密市',
        '410184': '新郑市',
        '410185': '登封市',
        '410190': '高新技术开发区',
        '410191': '经济技术开发区',
        '410192': '郑东新区',
        '410202': '龙亭区',
        '410203': '顺河回族区',
        '410204': '鼓楼区',
        '410205': '禹王台区',
        '410211': '金明区',
        '410212': '祥符区',
        '410221': '杞县',
        '410222': '通许县',
        '410223': '尉氏县',
        '410225': '兰考县',
        '410302': '老城区',
        '410303': '西工区',
        '410304': '瀍河回族区',
        '410305': '涧西区',
        '410306': '吉利区',
        '410311': '洛龙区',
        '410322': '孟津县',
        '410323': '新安县',
        '410324': '栾川县',
        '410325': '嵩县',
        '410326': '汝阳县',
        '410327': '宜阳县',
        '410328': '洛宁县',
        '410329': '伊川县',
        '410381': '偃师市',
        '410390': '伊滨区',
        '410402': '新华区',
        '410403': '卫东区',
        '410404': '石龙区',
        '410411': '湛河区',
        '410421': '宝丰县',
        '410422': '叶县',
        '410423': '鲁山县',
        '410425': '郏县',
        '410481': '舞钢市',
        '410482': '汝州市',
        '410502': '文峰区',
        '410503': '北关区',
        '410505': '殷都区',
        '410506': '龙安区',
        '410522': '安阳县',
        '410523': '汤阴县',
        '410526': '滑县',
        '410527': '内黄县',
        '410581': '林州市',
        '410590': '开发区',
        '410602': '鹤山区',
        '410603': '山城区',
        '410611': '淇滨区',
        '410621': '浚县',
        '410622': '淇县',
        '410702': '红旗区',
        '410703': '卫滨区',
        '410704': '凤泉区',
        '410711': '牧野区',
        '410721': '新乡县',
        '410724': '获嘉县',
        '410725': '原阳县',
        '410726': '延津县',
        '410727': '封丘县',
        '410728': '长垣县',
        '410781': '卫辉市',
        '410782': '辉县市',
        '410802': '解放区',
        '410803': '中站区',
        '410804': '马村区',
        '410811': '山阳区',
        '410821': '修武县',
        '410822': '博爱县',
        '410823': '武陟县',
        '410825': '温县',
        '410882': '沁阳市',
        '410883': '孟州市',
        '410902': '华龙区',
        '410922': '清丰县',
        '410923': '南乐县',
        '410926': '范县',
        '410927': '台前县',
        '410928': '濮阳县',
        '411002': '魏都区',
        '411023': '许昌县',
        '411024': '鄢陵县',
        '411025': '襄城县',
        '411081': '禹州市',
        '411082': '长葛市',
        '411102': '源汇区',
        '411103': '郾城区',
        '411104': '召陵区',
        '411121': '舞阳县',
        '411122': '临颍县',
        '411202': '湖滨区',
        '411221': '渑池县',
        '411222': '陕县',
        '411224': '卢氏县',
        '411281': '义马市',
        '411282': '灵宝市',
        '411302': '宛城区',
        '411303': '卧龙区',
        '411321': '南召县',
        '411322': '方城县',
        '411323': '西峡县',
        '411324': '镇平县',
        '411325': '内乡县',
        '411326': '淅川县',
        '411327': '社旗县',
        '411328': '唐河县',
        '411329': '新野县',
        '411330': '桐柏县',
        '411381': '邓州市',
        '411402': '梁园区',
        '411403': '睢阳区',
        '411421': '民权县',
        '411422': '睢县',
        '411423': '宁陵县',
        '411424': '柘城县',
        '411425': '虞城县',
        '411426': '夏邑县',
        '411481': '永城市',
        '411502': '浉河区',
        '411503': '平桥区',
        '411521': '罗山县',
        '411522': '光山县',
        '411523': '新县',
        '411524': '商城县',
        '411525': '固始县',
        '411526': '潢川县',
        '411527': '淮滨县',
        '411528': '息县',
        '411602': '川汇区',
        '411621': '扶沟县',
        '411622': '西华县',
        '411623': '商水县',
        '411624': '沈丘县',
        '411625': '郸城县',
        '411626': '淮阳县',
        '411627': '太康县',
        '411628': '鹿邑县',
        '411681': '项城市',
        '411690': '经济开发区',
        '411691': '东新区',
        '411702': '驿城区',
        '411721': '西平县',
        '411722': '上蔡县',
        '411723': '平舆县',
        '411724': '正阳县',
        '411725': '确山县',
        '411726': '泌阳县',
        '411727': '汝南县',
        '411728': '遂平县',
        '411729': '新蔡县',
        '419001': '济源市',
        '420102': '江岸区',
        '420103': '江汉区',
        '420104': '硚口区',
        '420105': '汉阳区',
        '420106': '武昌区',
        '420107': '青山区',
        '420111': '洪山区',
        '420112': '东西湖区',
        '420113': '汉南区',
        '420114': '蔡甸区',
        '420115': '江夏区',
        '420116': '黄陂区',
        '420117': '新洲区',
        '420190': '武汉经济技术开发区',
        '420202': '黄石港区',
        '420203': '西塞山区',
        '420204': '下陆区',
        '420205': '铁山区',
        '420222': '阳新县',
        '420281': '大冶市',
        '420290': '黄石经济技术开发区',
        '420302': '茅箭区',
        '420303': '张湾区',
        '420304': '郧阳区',
        '420322': '郧西县',
        '420323': '竹山县',
        '420324': '竹溪县',
        '420325': '房县',
        '420381': '丹江口市',
        '420502': '西陵区',
        '420503': '伍家岗区',
        '420504': '点军区',
        '420505': '猇亭区',
        '420506': '夷陵区',
        '420525': '远安县',
        '420526': '兴山县',
        '420527': '秭归县',
        '420528': '长阳土家族自治县',
        '420529': '五峰土家族自治县',
        '420581': '宜都市',
        '420582': '当阳市',
        '420583': '枝江市',
        '420590': '经济开发区',
        '420602': '襄城区',
        '420606': '樊城区',
        '420607': '襄州区',
        '420624': '南漳县',
        '420625': '谷城县',
        '420626': '保康县',
        '420682': '老河口市',
        '420683': '枣阳市',
        '420684': '宜城市',
        '420702': '梁子湖区',
        '420703': '华容区',
        '420704': '鄂城区',
        '420802': '东宝区',
        '420804': '掇刀区',
        '420821': '京山县',
        '420822': '沙洋县',
        '420881': '钟祥市',
        '420902': '孝南区',
        '420921': '孝昌县',
        '420922': '大悟县',
        '420923': '云梦县',
        '420981': '应城市',
        '420982': '安陆市',
        '420984': '汉川市',
        '421002': '沙市区',
        '421003': '荆州区',
        '421022': '公安县',
        '421023': '监利县',
        '421024': '江陵县',
        '421081': '石首市',
        '421083': '洪湖市',
        '421087': '松滋市',
        '421102': '黄州区',
        '421121': '团风县',
        '421122': '红安县',
        '421123': '罗田县',
        '421124': '英山县',
        '421125': '浠水县',
        '421126': '蕲春县',
        '421127': '黄梅县',
        '421181': '麻城市',
        '421182': '武穴市',
        '421202': '咸安区',
        '421221': '嘉鱼县',
        '421222': '通城县',
        '421223': '崇阳县',
        '421224': '通山县',
        '421281': '赤壁市',
        '421303': '曾都区',
        '421321': '随县',
        '421381': '广水市',
        '422801': '恩施市',
        '422802': '利川市',
        '422822': '建始县',
        '422823': '巴东县',
        '422825': '宣恩县',
        '422826': '咸丰县',
        '422827': '来凤县',
        '422828': '鹤峰县',
        '429004': '仙桃市',
        '429005': '潜江市',
        '429006': '天门市',
        '429021': '神农架林区',
        '430102': '芙蓉区',
        '430103': '天心区',
        '430104': '岳麓区',
        '430105': '开福区',
        '430111': '雨花区',
        '430112': '望城区',
        '430121': '长沙县',
        '430124': '宁乡县',
        '430181': '浏阳市',
        '430202': '荷塘区',
        '430203': '芦淞区',
        '430204': '石峰区',
        '430211': '天元区',
        '430221': '株洲县',
        '430223': '攸县',
        '430224': '茶陵县',
        '430225': '炎陵县',
        '430281': '醴陵市',
        '430302': '雨湖区',
        '430304': '岳塘区',
        '430321': '湘潭县',
        '430381': '湘乡市',
        '430382': '韶山市',
        '430405': '珠晖区',
        '430406': '雁峰区',
        '430407': '石鼓区',
        '430408': '蒸湘区',
        '430412': '南岳区',
        '430421': '衡阳县',
        '430422': '衡南县',
        '430423': '衡山县',
        '430424': '衡东县',
        '430426': '祁东县',
        '430481': '耒阳市',
        '430482': '常宁市',
        '430502': '双清区',
        '430503': '大祥区',
        '430511': '北塔区',
        '430521': '邵东县',
        '430522': '新邵县',
        '430523': '邵阳县',
        '430524': '隆回县',
        '430525': '洞口县',
        '430527': '绥宁县',
        '430528': '新宁县',
        '430529': '城步苗族自治县',
        '430581': '武冈市',
        '430602': '岳阳楼区',
        '430603': '云溪区',
        '430611': '君山区',
        '430621': '岳阳县',
        '430623': '华容县',
        '430624': '湘阴县',
        '430626': '平江县',
        '430681': '汨罗市',
        '430682': '临湘市',
        '430702': '武陵区',
        '430703': '鼎城区',
        '430721': '安乡县',
        '430722': '汉寿县',
        '430723': '澧县',
        '430724': '临澧县',
        '430725': '桃源县',
        '430726': '石门县',
        '430781': '津市市',
        '430802': '永定区',
        '430811': '武陵源区',
        '430821': '慈利县',
        '430822': '桑植县',
        '430902': '资阳区',
        '430903': '赫山区',
        '430921': '南县',
        '430922': '桃江县',
        '430923': '安化县',
        '430981': '沅江市',
        '431002': '北湖区',
        '431003': '苏仙区',
        '431021': '桂阳县',
        '431022': '宜章县',
        '431023': '永兴县',
        '431024': '嘉禾县',
        '431025': '临武县',
        '431026': '汝城县',
        '431027': '桂东县',
        '431028': '安仁县',
        '431081': '资兴市',
        '431102': '零陵区',
        '431103': '冷水滩区',
        '431121': '祁阳县',
        '431122': '东安县',
        '431123': '双牌县',
        '431124': '道县',
        '431125': '江永县',
        '431126': '宁远县',
        '431127': '蓝山县',
        '431128': '新田县',
        '431129': '江华瑶族自治县',
        '431202': '鹤城区',
        '431221': '中方县',
        '431222': '沅陵县',
        '431223': '辰溪县',
        '431224': '溆浦县',
        '431225': '会同县',
        '431226': '麻阳苗族自治县',
        '431227': '新晃侗族自治县',
        '431228': '芷江侗族自治县',
        '431229': '靖州苗族侗族自治县',
        '431230': '通道侗族自治县',
        '431281': '洪江市',
        '431302': '娄星区',
        '431321': '双峰县',
        '431322': '新化县',
        '431381': '冷水江市',
        '431382': '涟源市',
        '433101': '吉首市',
        '433122': '泸溪县',
        '433123': '凤凰县',
        '433124': '花垣县',
        '433125': '保靖县',
        '433126': '古丈县',
        '433127': '永顺县',
        '433130': '龙山县',
        '440103': '荔湾区',
        '440104': '越秀区',
        '440105': '海珠区',
        '440106': '天河区',
        '440111': '白云区',
        '440112': '黄埔区',
        '440113': '番禺区',
        '440114': '花都区',
        '440115': '南沙区',
        '440117': '从化区',
        '440118': '增城区',
        '440203': '武江区',
        '440204': '浈江区',
        '440205': '曲江区',
        '440222': '始兴县',
        '440224': '仁化县',
        '440229': '翁源县',
        '440232': '乳源瑶族自治县',
        '440233': '新丰县',
        '440281': '乐昌市',
        '440282': '南雄市',
        '440303': '罗湖区',
        '440304': '福田区',
        '440305': '南山区',
        '440306': '宝安区',
        '440307': '龙岗区',
        '440308': '盐田区',
        '440390': '坪山新区',
        '440391': '光明新区',
        '440392': '大鹏新区',
        '440393': '龙华新区',
        '440402': '香洲区',
        '440403': '斗门区',
        '440404': '金湾区',
        '440507': '龙湖区',
        '440511': '金平区',
        '440512': '濠江区',
        '440513': '潮阳区',
        '440514': '潮南区',
        '440515': '澄海区',
        '440523': '南澳县',
        '440604': '禅城区',
        '440605': '南海区',
        '440606': '顺德区',
        '440607': '三水区',
        '440608': '高明区',
        '440703': '蓬江区',
        '440704': '江海区',
        '440705': '新会区',
        '440781': '台山市',
        '440783': '开平市',
        '440784': '鹤山市',
        '440785': '恩平市',
        '440802': '赤坎区',
        '440803': '霞山区',
        '440804': '坡头区',
        '440811': '麻章区',
        '440823': '遂溪县',
        '440825': '徐闻县',
        '440881': '廉江市',
        '440882': '雷州市',
        '440883': '吴川市',
        '440890': '经济技术开发区',
        '440902': '茂南区',
        '440904': '电白区',
        '440981': '高州市',
        '440982': '化州市',
        '440983': '信宜市',
        '441202': '端州区',
        '441203': '鼎湖区',
        '441204': '高要区',
        '441223': '广宁县',
        '441224': '怀集县',
        '441225': '封开县',
        '441226': '德庆县',
        '441284': '四会市',
        '441302': '惠城区',
        '441303': '惠阳区',
        '441322': '博罗县',
        '441323': '惠东县',
        '441324': '龙门县',
        '441402': '梅江区',
        '441403': '梅县区',
        '441422': '大埔县',
        '441423': '丰顺县',
        '441424': '五华县',
        '441426': '平远县',
        '441427': '蕉岭县',
        '441481': '兴宁市',
        '441502': '城区',
        '441521': '海丰县',
        '441523': '陆河县',
        '441581': '陆丰市',
        '441602': '源城区',
        '441621': '紫金县',
        '441622': '龙川县',
        '441623': '连平县',
        '441624': '和平县',
        '441625': '东源县',
        '441702': '江城区',
        '441704': '阳东区',
        '441721': '阳西县',
        '441781': '阳春市',
        '441802': '清城区',
        '441803': '清新区',
        '441821': '佛冈县',
        '441823': '阳山县',
        '441825': '连山壮族瑶族自治县',
        '441826': '连南瑶族自治县',
        '441881': '英德市',
        '441882': '连州市',
        '441901': '中堂镇',
        '441903': '南城区',
        '441904': '长安镇',
        '441905': '东坑镇',
        '441906': '樟木头镇',
        '441907': '莞城区',
        '441908': '石龙镇',
        '441909': '桥头镇',
        '441910': '万江区',
        '441911': '麻涌镇',
        '441912': '虎门镇',
        '441913': '谢岗镇',
        '441914': '石碣镇',
        '441915': '茶山镇',
        '441916': '东城区',
        '441917': '洪梅镇',
        '441918': '道滘镇',
        '441919': '高埗镇',
        '441920': '企石镇',
        '441921': '凤岗镇',
        '441922': '大岭山镇',
        '441923': '松山湖',
        '441924': '清溪镇',
        '441925': '望牛墩镇',
        '441926': '厚街镇',
        '441927': '常平镇',
        '441928': '寮步镇',
        '441929': '石排镇',
        '441930': '横沥镇',
        '441931': '塘厦镇',
        '441932': '黄江镇',
        '441933': '大朗镇',
        '441990': '沙田镇',
        '442001': '南头镇',
        '442002': '神湾镇',
        '442003': '东凤镇',
        '442004': '五桂山镇',
        '442005': '黄圃镇',
        '442006': '小榄镇',
        '442007': '石岐区街道',
        '442008': '横栏镇',
        '442009': '三角镇',
        '442010': '三乡镇',
        '442011': '港口镇',
        '442012': '沙溪镇',
        '442013': '板芙镇',
        '442014': '沙朗镇',
        '442015': '东升镇',
        '442016': '阜沙镇',
        '442017': '民众镇',
        '442018': '东区街道',
        '442019': '火炬开发区',
        '442020': '西区街道',
        '442021': '南区街道',
        '442022': '古镇',
        '442023': '坦洲镇',
        '442024': '大涌镇',
        '442025': '南朗镇',
        '445102': '湘桥区',
        '445103': '潮安区',
        '445122': '饶平县',
        '445190': '枫溪区',
        '445202': '榕城区',
        '445203': '揭东区',
        '445222': '揭西县',
        '445224': '惠来县',
        '445281': '普宁市',
        '445302': '云城区',
        '445303': '云安区',
        '445321': '新兴县',
        '445322': '郁南县',
        '445381': '罗定市',
        '450102': '兴宁区',
        '450103': '青秀区',
        '450105': '江南区',
        '450107': '西乡塘区',
        '450108': '良庆区',
        '450109': '邕宁区',
        '450110': '武鸣区',
        '450123': '隆安县',
        '450124': '马山县',
        '450125': '上林县',
        '450126': '宾阳县',
        '450127': '横县',
        '450202': '城中区',
        '450203': '鱼峰区',
        '450204': '柳南区',
        '450205': '柳北区',
        '450221': '柳江县',
        '450222': '柳城县',
        '450223': '鹿寨县',
        '450224': '融安县',
        '450225': '融水苗族自治县',
        '450226': '三江侗族自治县',
        '450302': '秀峰区',
        '450303': '叠彩区',
        '450304': '象山区',
        '450305': '七星区',
        '450311': '雁山区',
        '450312': '临桂区',
        '450321': '阳朔县',
        '450323': '灵川县',
        '450324': '全州县',
        '450325': '兴安县',
        '450326': '永福县',
        '450327': '灌阳县',
        '450328': '龙胜各族自治县',
        '450329': '资源县',
        '450330': '平乐县',
        '450331': '荔浦县',
        '450332': '恭城瑶族自治县',
        '450403': '万秀区',
        '450405': '长洲区',
        '450406': '龙圩区',
        '450421': '苍梧县',
        '450422': '藤县',
        '450423': '蒙山县',
        '450481': '岑溪市',
        '450502': '海城区',
        '450503': '银海区',
        '450512': '铁山港区',
        '450521': '合浦县',
        '450602': '港口区',
        '450603': '防城区',
        '450621': '上思县',
        '450681': '东兴市',
        '450702': '钦南区',
        '450703': '钦北区',
        '450721': '灵山县',
        '450722': '浦北县',
        '450802': '港北区',
        '450803': '港南区',
        '450804': '覃塘区',
        '450821': '平南县',
        '450881': '桂平市',
        '450902': '玉州区',
        '450903': '福绵区',
        '450921': '容县',
        '450922': '陆川县',
        '450923': '博白县',
        '450924': '兴业县',
        '450981': '北流市',
        '451002': '右江区',
        '451021': '田阳县',
        '451022': '田东县',
        '451023': '平果县',
        '451024': '德保县',
        '451026': '那坡县',
        '451027': '凌云县',
        '451028': '乐业县',
        '451029': '田林县',
        '451030': '西林县',
        '451031': '隆林各族自治县',
        '451081': '靖西市',
        '451102': '八步区',
        '451121': '昭平县',
        '451122': '钟山县',
        '451123': '富川瑶族自治县',
        '451202': '金城江区',
        '451221': '南丹县',
        '451222': '天峨县',
        '451223': '凤山县',
        '451224': '东兰县',
        '451225': '罗城仫佬族自治县',
        '451226': '环江毛南族自治县',
        '451227': '巴马瑶族自治县',
        '451228': '都安瑶族自治县',
        '451229': '大化瑶族自治县',
        '451281': '宜州市',
        '451302': '兴宾区',
        '451321': '忻城县',
        '451322': '象州县',
        '451323': '武宣县',
        '451324': '金秀瑶族自治县',
        '451381': '合山市',
        '451402': '江州区',
        '451421': '扶绥县',
        '451422': '宁明县',
        '451423': '龙州县',
        '451424': '大新县',
        '451425': '天等县',
        '451481': '凭祥市',
        '460105': '秀英区',
        '460106': '龙华区',
        '460107': '琼山区',
        '460108': '美兰区',
        '460202': '海棠区',
        '460203': '吉阳区',
        '460204': '天涯区',
        '460205': '崖州区',
        '460321': '西沙群岛',
        '460322': '南沙群岛',
        '460323': '中沙群岛的岛礁及其海域',
        '469001': '五指山市',
        '469002': '琼海市',
        '469003': '儋州市',
        '469005': '文昌市',
        '469006': '万宁市',
        '469007': '东方市',
        '469021': '定安县',
        '469022': '屯昌县',
        '469023': '澄迈县',
        '469024': '临高县',
        '469025': '白沙黎族自治县',
        '469026': '昌江黎族自治县',
        '469027': '乐东黎族自治县',
        '469028': '陵水黎族自治县',
        '469029': '保亭黎族苗族自治县',
        '469030': '琼中黎族苗族自治县',
        '500101': '万州区',
        '500102': '涪陵区',
        '500103': '渝中区',
        '500104': '大渡口区',
        '500105': '江北区',
        '500106': '沙坪坝区',
        '500107': '九龙坡区',
        '500108': '南岸区',
        '500109': '北碚区',
        '500110': '綦江区',
        '500111': '大足区',
        '500112': '渝北区',
        '500113': '巴南区',
        '500114': '黔江区',
        '500115': '长寿区',
        '500116': '江津区',
        '500117': '合川区',
        '500118': '永川区',
        '500119': '南川区',
        '500120': '璧山区',
        '500151': '铜梁区',
        '500152': '潼南区',
        '500153': '荣昌区',
        '500228': '梁平县',
        '500229': '城口县',
        '500230': '丰都县',
        '500231': '垫江县',
        '500232': '武隆县',
        '500233': '忠县',
        '500234': '开县',
        '500235': '云阳县',
        '500236': '奉节县',
        '500237': '巫山县',
        '500238': '巫溪县',
        '500240': '石柱土家族自治县',
        '500241': '秀山土家族苗族自治县',
        '500242': '酉阳土家族苗族自治县',
        '500243': '彭水苗族土家族自治县',
        '510104': '锦江区',
        '510105': '青羊区',
        '510106': '金牛区',
        '510107': '武侯区',
        '510108': '成华区',
        '510112': '龙泉驿区',
        '510113': '青白江区',
        '510114': '新都区',
        '510115': '温江区',
        '510121': '金堂县',
        '510122': '双流县',
        '510124': '郫县',
        '510129': '大邑县',
        '510131': '蒲江县',
        '510132': '新津县',
        '510181': '都江堰市',
        '510182': '彭州市',
        '510183': '邛崃市',
        '510184': '崇州市',
        '510190': '高新西区',
        '510191': '高新区',
        '510302': '自流井区',
        '510303': '贡井区',
        '510304': '大安区',
        '510311': '沿滩区',
        '510321': '荣县',
        '510322': '富顺县',
        '510402': '东区',
        '510403': '西区',
        '510411': '仁和区',
        '510421': '米易县',
        '510422': '盐边县',
        '510502': '江阳区',
        '510503': '纳溪区',
        '510504': '龙马潭区',
        '510521': '泸县',
        '510522': '合江县',
        '510524': '叙永县',
        '510525': '古蔺县',
        '510603': '旌阳区',
        '510623': '中江县',
        '510626': '罗江县',
        '510681': '广汉市',
        '510682': '什邡市',
        '510683': '绵竹市',
        '510703': '涪城区',
        '510704': '游仙区',
        '510722': '三台县',
        '510723': '盐亭县',
        '510724': '安县',
        '510725': '梓潼县',
        '510726': '北川羌族自治县',
        '510727': '平武县',
        '510781': '江油市',
        '510790': '经开区',
        '510791': '高新区',
        '510802': '利州区',
        '510811': '昭化区',
        '510812': '朝天区',
        '510821': '旺苍县',
        '510822': '青川县',
        '510823': '剑阁县',
        '510824': '苍溪县',
        '510903': '船山区',
        '510904': '安居区',
        '510921': '蓬溪县',
        '510922': '射洪县',
        '510923': '大英县',
        '511002': '市中区',
        '511011': '东兴区',
        '511024': '威远县',
        '511025': '资中县',
        '511028': '隆昌县',
        '511102': '市中区',
        '511111': '沙湾区',
        '511112': '五通桥区',
        '511113': '金口河区',
        '511123': '犍为县',
        '511124': '井研县',
        '511126': '夹江县',
        '511129': '沐川县',
        '511132': '峨边彝族自治县',
        '511133': '马边彝族自治县',
        '511181': '峨眉山市',
        '511302': '顺庆区',
        '511303': '高坪区',
        '511304': '嘉陵区',
        '511321': '南部县',
        '511322': '营山县',
        '511323': '蓬安县',
        '511324': '仪陇县',
        '511325': '西充县',
        '511381': '阆中市',
        '511402': '东坡区',
        '511403': '彭山区',
        '511421': '仁寿县',
        '511423': '洪雅县',
        '511424': '丹棱县',
        '511425': '青神县',
        '511502': '翠屏区',
        '511503': '南溪区',
        '511521': '宜宾县',
        '511523': '江安县',
        '511524': '长宁县',
        '511525': '高县',
        '511526': '珙县',
        '511527': '筠连县',
        '511528': '兴文县',
        '511529': '屏山县',
        '511602': '广安区',
        '511603': '前锋区',
        '511621': '岳池县',
        '511622': '武胜县',
        '511623': '邻水县',
        '511681': '华蓥市',
        '511702': '通川区',
        '511703': '达川区',
        '511722': '宣汉县',
        '511723': '开江县',
        '511724': '大竹县',
        '511725': '渠县',
        '511781': '万源市',
        '511802': '雨城区',
        '511803': '名山区',
        '511822': '荥经县',
        '511823': '汉源县',
        '511824': '石棉县',
        '511825': '天全县',
        '511826': '芦山县',
        '511827': '宝兴县',
        '511902': '巴州区',
        '511903': '恩阳区',
        '511921': '通江县',
        '511922': '南江县',
        '511923': '平昌县',
        '512002': '雁江区',
        '512021': '安岳县',
        '512022': '乐至县',
        '512081': '简阳市',
        '513221': '汶川县',
        '513222': '理县',
        '513223': '茂县',
        '513224': '松潘县',
        '513225': '九寨沟县',
        '513226': '金川县',
        '513227': '小金县',
        '513228': '黑水县',
        '513229': '马尔康县',
        '513230': '壤塘县',
        '513231': '阿坝县',
        '513232': '若尔盖县',
        '513233': '红原县',
        '513301': '康定市',
        '513322': '泸定县',
        '513323': '丹巴县',
        '513324': '九龙县',
        '513325': '雅江县',
        '513326': '道孚县',
        '513327': '炉霍县',
        '513328': '甘孜县',
        '513329': '新龙县',
        '513330': '德格县',
        '513331': '白玉县',
        '513332': '石渠县',
        '513333': '色达县',
        '513334': '理塘县',
        '513335': '巴塘县',
        '513336': '乡城县',
        '513337': '稻城县',
        '513338': '得荣县',
        '513401': '西昌市',
        '513422': '木里藏族自治县',
        '513423': '盐源县',
        '513424': '德昌县',
        '513425': '会理县',
        '513426': '会东县',
        '513427': '宁南县',
        '513428': '普格县',
        '513429': '布拖县',
        '513430': '金阳县',
        '513431': '昭觉县',
        '513432': '喜德县',
        '513433': '冕宁县',
        '513434': '越西县',
        '513435': '甘洛县',
        '513436': '美姑县',
        '513437': '雷波县',
        '520102': '南明区',
        '520103': '云岩区',
        '520111': '花溪区',
        '520112': '乌当区',
        '520113': '白云区',
        '520115': '观山湖区',
        '520121': '开阳县',
        '520122': '息烽县',
        '520123': '修文县',
        '520181': '清镇市',
        '520201': '钟山区',
        '520203': '六枝特区',
        '520221': '水城县',
        '520222': '盘县',
        '520302': '红花岗区',
        '520303': '汇川区',
        '520321': '遵义县',
        '520322': '桐梓县',
        '520323': '绥阳县',
        '520324': '正安县',
        '520325': '道真仡佬族苗族自治县',
        '520326': '务川仡佬族苗族自治县',
        '520327': '凤冈县',
        '520328': '湄潭县',
        '520329': '余庆县',
        '520330': '习水县',
        '520381': '赤水市',
        '520382': '仁怀市',
        '520402': '西秀区',
        '520403': '平坝区',
        '520422': '普定县',
        '520423': '镇宁布依族苗族自治县',
        '520424': '关岭布依族苗族自治县',
        '520425': '紫云苗族布依族自治县',
        '520502': '七星关区',
        '520521': '大方县',
        '520522': '黔西县',
        '520523': '金沙县',
        '520524': '织金县',
        '520525': '纳雍县',
        '520526': '威宁彝族回族苗族自治县',
        '520527': '赫章县',
        '520602': '碧江区',
        '520603': '万山区',
        '520621': '江口县',
        '520622': '玉屏侗族自治县',
        '520623': '石阡县',
        '520624': '思南县',
        '520625': '印江土家族苗族自治县',
        '520626': '德江县',
        '520627': '沿河土家族自治县',
        '520628': '松桃苗族自治县',
        '522301': '兴义市',
        '522322': '兴仁县',
        '522323': '普安县',
        '522324': '晴隆县',
        '522325': '贞丰县',
        '522326': '望谟县',
        '522327': '册亨县',
        '522328': '安龙县',
        '522601': '凯里市',
        '522622': '黄平县',
        '522623': '施秉县',
        '522624': '三穗县',
        '522625': '镇远县',
        '522626': '岑巩县',
        '522627': '天柱县',
        '522628': '锦屏县',
        '522629': '剑河县',
        '522630': '台江县',
        '522631': '黎平县',
        '522632': '榕江县',
        '522633': '从江县',
        '522634': '雷山县',
        '522635': '麻江县',
        '522636': '丹寨县',
        '522701': '都匀市',
        '522702': '福泉市',
        '522722': '荔波县',
        '522723': '贵定县',
        '522725': '瓮安县',
        '522726': '独山县',
        '522727': '平塘县',
        '522728': '罗甸县',
        '522729': '长顺县',
        '522730': '龙里县',
        '522731': '惠水县',
        '522732': '三都水族自治县',
        '530102': '五华区',
        '530103': '盘龙区',
        '530111': '官渡区',
        '530112': '西山区',
        '530113': '东川区',
        '530114': '呈贡区',
        '530122': '晋宁县',
        '530124': '富民县',
        '530125': '宜良县',
        '530126': '石林彝族自治县',
        '530127': '嵩明县',
        '530128': '禄劝彝族苗族自治县',
        '530129': '寻甸回族彝族自治县',
        '530181': '安宁市',
        '530302': '麒麟区',
        '530321': '马龙县',
        '530322': '陆良县',
        '530323': '师宗县',
        '530324': '罗平县',
        '530325': '富源县',
        '530326': '会泽县',
        '530328': '沾益县',
        '530381': '宣威市',
        '530402': '红塔区',
        '530421': '江川县',
        '530422': '澄江县',
        '530423': '通海县',
        '530424': '华宁县',
        '530425': '易门县',
        '530426': '峨山彝族自治县',
        '530427': '新平彝族傣族自治县',
        '530428': '元江哈尼族彝族傣族自治县',
        '530502': '隆阳区',
        '530521': '施甸县',
        '530523': '龙陵县',
        '530524': '昌宁县',
        '530581': '腾冲市',
        '530602': '昭阳区',
        '530621': '鲁甸县',
        '530622': '巧家县',
        '530623': '盐津县',
        '530624': '大关县',
        '530625': '永善县',
        '530626': '绥江县',
        '530627': '镇雄县',
        '530628': '彝良县',
        '530629': '威信县',
        '530630': '水富县',
        '530702': '古城区',
        '530721': '玉龙纳西族自治县',
        '530722': '永胜县',
        '530723': '华坪县',
        '530724': '宁蒗彝族自治县',
        '530802': '思茅区',
        '530821': '宁洱哈尼族彝族自治县',
        '530822': '墨江哈尼族自治县',
        '530823': '景东彝族自治县',
        '530824': '景谷傣族彝族自治县',
        '530825': '镇沅彝族哈尼族拉祜族自治县',
        '530826': '江城哈尼族彝族自治县',
        '530827': '孟连傣族拉祜族佤族自治县',
        '530828': '澜沧拉祜族自治县',
        '530829': '西盟佤族自治县',
        '530902': '临翔区',
        '530921': '凤庆县',
        '530922': '云县',
        '530923': '永德县',
        '530924': '镇康县',
        '530925': '双江拉祜族佤族布朗族傣族自治县',
        '530926': '耿马傣族佤族自治县',
        '530927': '沧源佤族自治县',
        '532301': '楚雄市',
        '532322': '双柏县',
        '532323': '牟定县',
        '532324': '南华县',
        '532325': '姚安县',
        '532326': '大姚县',
        '532327': '永仁县',
        '532328': '元谋县',
        '532329': '武定县',
        '532331': '禄丰县',
        '532501': '个旧市',
        '532502': '开远市',
        '532503': '蒙自市',
        '532504': '弥勒市',
        '532523': '屏边苗族自治县',
        '532524': '建水县',
        '532525': '石屏县',
        '532527': '泸西县',
        '532528': '元阳县',
        '532529': '红河县',
        '532530': '金平苗族瑶族傣族自治县',
        '532531': '绿春县',
        '532532': '河口瑶族自治县',
        '532601': '文山市',
        '532622': '砚山县',
        '532623': '西畴县',
        '532624': '麻栗坡县',
        '532625': '马关县',
        '532626': '丘北县',
        '532627': '广南县',
        '532628': '富宁县',
        '532801': '景洪市',
        '532822': '勐海县',
        '532823': '勐腊县',
        '532901': '大理市',
        '532922': '漾濞彝族自治县',
        '532923': '祥云县',
        '532924': '宾川县',
        '532925': '弥渡县',
        '532926': '南涧彝族自治县',
        '532927': '巍山彝族回族自治县',
        '532928': '永平县',
        '532929': '云龙县',
        '532930': '洱源县',
        '532931': '剑川县',
        '532932': '鹤庆县',
        '533102': '瑞丽市',
        '533103': '芒市',
        '533122': '梁河县',
        '533123': '盈江县',
        '533124': '陇川县',
        '533321': '泸水县',
        '533323': '福贡县',
        '533324': '贡山独龙族怒族自治县',
        '533325': '兰坪白族普米族自治县',
        '533401': '香格里拉市',
        '533422': '德钦县',
        '533423': '维西傈僳族自治县',
        '540102': '城关区',
        '540121': '林周县',
        '540122': '当雄县',
        '540123': '尼木县',
        '540124': '曲水县',
        '540125': '堆龙德庆县',
        '540126': '达孜县',
        '540127': '墨竹工卡县',
        '540202': '桑珠孜区',
        '540221': '南木林县',
        '540222': '江孜县',
        '540223': '定日县',
        '540224': '萨迦县',
        '540225': '拉孜县',
        '540226': '昂仁县',
        '540227': '谢通门县',
        '540228': '白朗县',
        '540229': '仁布县',
        '540230': '康马县',
        '540231': '定结县',
        '540232': '仲巴县',
        '540233': '亚东县',
        '540234': '吉隆县',
        '540235': '聂拉木县',
        '540236': '萨嘎县',
        '540237': '岗巴县',
        '540302': '卡若区',
        '540321': '江达县',
        '540322': '贡觉县',
        '540323': '类乌齐县',
        '540324': '丁青县',
        '540325': '察雅县',
        '540326': '八宿县',
        '540327': '左贡县',
        '540328': '芒康县',
        '540329': '洛隆县',
        '540330': '边坝县',
        '540402': '巴宜区',
        '540421': '工布江达县',
        '540422': '米林县',
        '540423': '墨脱县',
        '540424': '波密县',
        '540425': '察隅县',
        '540426': '朗县',
        '542221': '乃东县',
        '542222': '扎囊县',
        '542223': '贡嘎县',
        '542224': '桑日县',
        '542225': '琼结县',
        '542226': '曲松县',
        '542227': '措美县',
        '542228': '洛扎县',
        '542229': '加查县',
        '542231': '隆子县',
        '542232': '错那县',
        '542233': '浪卡子县',
        '542421': '那曲县',
        '542422': '嘉黎县',
        '542423': '比如县',
        '542424': '聂荣县',
        '542425': '安多县',
        '542426': '申扎县',
        '542427': '索县',
        '542428': '班戈县',
        '542429': '巴青县',
        '542430': '尼玛县',
        '542431': '双湖县',
        '542521': '普兰县',
        '542522': '札达县',
        '542523': '噶尔县',
        '542524': '日土县',
        '542525': '革吉县',
        '542526': '改则县',
        '542527': '措勤县',
        '610102': '新城区',
        '610103': '碑林区',
        '610104': '莲湖区',
        '610111': '灞桥区',
        '610112': '未央区',
        '610113': '雁塔区',
        '610114': '阎良区',
        '610115': '临潼区',
        '610116': '长安区',
        '610117': '高陵区',
        '610122': '蓝田县',
        '610124': '周至县',
        '610125': '户县',
        '610202': '王益区',
        '610203': '印台区',
        '610204': '耀州区',
        '610222': '宜君县',
        '610302': '渭滨区',
        '610303': '金台区',
        '610304': '陈仓区',
        '610322': '凤翔县',
        '610323': '岐山县',
        '610324': '扶风县',
        '610326': '眉县',
        '610327': '陇县',
        '610328': '千阳县',
        '610329': '麟游县',
        '610330': '凤县',
        '610331': '太白县',
        '610402': '秦都区',
        '610403': '杨陵区',
        '610404': '渭城区',
        '610422': '三原县',
        '610423': '泾阳县',
        '610424': '乾县',
        '610425': '礼泉县',
        '610426': '永寿县',
        '610427': '彬县',
        '610428': '长武县',
        '610429': '旬邑县',
        '610430': '淳化县',
        '610431': '武功县',
        '610481': '兴平市',
        '610502': '临渭区',
        '610521': '华县',
        '610522': '潼关县',
        '610523': '大荔县',
        '610524': '合阳县',
        '610525': '澄城县',
        '610526': '蒲城县',
        '610527': '白水县',
        '610528': '富平县',
        '610581': '韩城市',
        '610582': '华阴市',
        '610602': '宝塔区',
        '610621': '延长县',
        '610622': '延川县',
        '610623': '子长县',
        '610624': '安塞县',
        '610625': '志丹县',
        '610626': '吴起县',
        '610627': '甘泉县',
        '610628': '富县',
        '610629': '洛川县',
        '610630': '宜川县',
        '610631': '黄龙县',
        '610632': '黄陵县',
        '610702': '汉台区',
        '610721': '南郑县',
        '610722': '城固县',
        '610723': '洋县',
        '610724': '西乡县',
        '610725': '勉县',
        '610726': '宁强县',
        '610727': '略阳县',
        '610728': '镇巴县',
        '610729': '留坝县',
        '610730': '佛坪县',
        '610802': '榆阳区',
        '610821': '神木县',
        '610822': '府谷县',
        '610823': '横山县',
        '610824': '靖边县',
        '610825': '定边县',
        '610826': '绥德县',
        '610827': '米脂县',
        '610828': '佳县',
        '610829': '吴堡县',
        '610830': '清涧县',
        '610831': '子洲县',
        '610902': '汉滨区',
        '610921': '汉阴县',
        '610922': '石泉县',
        '610923': '宁陕县',
        '610924': '紫阳县',
        '610925': '岚皋县',
        '610926': '平利县',
        '610927': '镇坪县',
        '610928': '旬阳县',
        '610929': '白河县',
        '611002': '商州区',
        '611021': '洛南县',
        '611022': '丹凤县',
        '611023': '商南县',
        '611024': '山阳县',
        '611025': '镇安县',
        '611026': '柞水县',
        '620102': '城关区',
        '620103': '七里河区',
        '620104': '西固区',
        '620105': '安宁区',
        '620111': '红古区',
        '620121': '永登县',
        '620122': '皋兰县',
        '620123': '榆中县',
        '620201': '市辖区',
        '620290': '雄关区',
        '620291': '长城区',
        '620292': '镜铁区',
        '620293': '新城镇',
        '620294': '峪泉镇',
        '620295': '文殊镇',
        '620302': '金川区',
        '620321': '永昌县',
        '620402': '白银区',
        '620403': '平川区',
        '620421': '靖远县',
        '620422': '会宁县',
        '620423': '景泰县',
        '620502': '秦州区',
        '620503': '麦积区',
        '620521': '清水县',
        '620522': '秦安县',
        '620523': '甘谷县',
        '620524': '武山县',
        '620525': '张家川回族自治县',
        '620602': '凉州区',
        '620621': '民勤县',
        '620622': '古浪县',
        '620623': '天祝藏族自治县',
        '620702': '甘州区',
        '620721': '肃南裕固族自治县',
        '620722': '民乐县',
        '620723': '临泽县',
        '620724': '高台县',
        '620725': '山丹县',
        '620802': '崆峒区',
        '620821': '泾川县',
        '620822': '灵台县',
        '620823': '崇信县',
        '620824': '华亭县',
        '620825': '庄浪县',
        '620826': '静宁县',
        '620902': '肃州区',
        '620921': '金塔县',
        '620922': '瓜州县',
        '620923': '肃北蒙古族自治县',
        '620924': '阿克塞哈萨克族自治县',
        '620981': '玉门市',
        '620982': '敦煌市',
        '621002': '西峰区',
        '621021': '庆城县',
        '621022': '环县',
        '621023': '华池县',
        '621024': '合水县',
        '621025': '正宁县',
        '621026': '宁县',
        '621027': '镇原县',
        '621102': '安定区',
        '621121': '通渭县',
        '621122': '陇西县',
        '621123': '渭源县',
        '621124': '临洮县',
        '621125': '漳县',
        '621126': '岷县',
        '621202': '武都区',
        '621221': '成县',
        '621222': '文县',
        '621223': '宕昌县',
        '621224': '康县',
        '621225': '西和县',
        '621226': '礼县',
        '621227': '徽县',
        '621228': '两当县',
        '622901': '临夏市',
        '622921': '临夏县',
        '622922': '康乐县',
        '622923': '永靖县',
        '622924': '广河县',
        '622925': '和政县',
        '622926': '东乡族自治县',
        '622927': '积石山保安族东乡族撒拉族自治县',
        '623001': '合作市',
        '623021': '临潭县',
        '623022': '卓尼县',
        '623023': '舟曲县',
        '623024': '迭部县',
        '623025': '玛曲县',
        '623026': '碌曲县',
        '623027': '夏河县',
        '630102': '城东区',
        '630103': '城中区',
        '630104': '城西区',
        '630105': '城北区',
        '630121': '大通回族土族自治县',
        '630122': '湟中县',
        '630123': '湟源县',
        '630202': '乐都区',
        '630203': '平安区',
        '630222': '民和回族土族自治县',
        '630223': '互助土族自治县',
        '630224': '化隆回族自治县',
        '630225': '循化撒拉族自治县',
        '632221': '门源回族自治县',
        '632222': '祁连县',
        '632223': '海晏县',
        '632224': '刚察县',
        '632321': '同仁县',
        '632322': '尖扎县',
        '632323': '泽库县',
        '632324': '河南蒙古族自治县',
        '632521': '共和县',
        '632522': '同德县',
        '632523': '贵德县',
        '632524': '兴海县',
        '632525': '贵南县',
        '632621': '玛沁县',
        '632622': '班玛县',
        '632623': '甘德县',
        '632624': '达日县',
        '632625': '久治县',
        '632626': '玛多县',
        '632701': '玉树市',
        '632722': '杂多县',
        '632723': '称多县',
        '632724': '治多县',
        '632725': '囊谦县',
        '632726': '曲麻莱县',
        '632801': '格尔木市',
        '632802': '德令哈市',
        '632821': '乌兰县',
        '632822': '都兰县',
        '632823': '天峻县',
        '640104': '兴庆区',
        '640105': '西夏区',
        '640106': '金凤区',
        '640121': '永宁县',
        '640122': '贺兰县',
        '640181': '灵武市',
        '640202': '大武口区',
        '640205': '惠农区',
        '640221': '平罗县',
        '640302': '利通区',
        '640303': '红寺堡区',
        '640323': '盐池县',
        '640324': '同心县',
        '640381': '青铜峡市',
        '640402': '原州区',
        '640422': '西吉县',
        '640423': '隆德县',
        '640424': '泾源县',
        '640425': '彭阳县',
        '640502': '沙坡头区',
        '640521': '中宁县',
        '640522': '海原县',
        '650102': '天山区',
        '650103': '沙依巴克区',
        '650104': '新市区',
        '650105': '水磨沟区',
        '650106': '头屯河区',
        '650107': '达坂城区',
        '650109': '米东区',
        '650121': '乌鲁木齐县',
        '650202': '独山子区',
        '650203': '克拉玛依区',
        '650204': '白碱滩区',
        '650205': '乌尔禾区',
        '650402': '高昌区',
        '650421': '鄯善县',
        '650422': '托克逊县',
        '652201': '哈密市',
        '652222': '巴里坤哈萨克自治县',
        '652223': '伊吾县',
        '652301': '昌吉市',
        '652302': '阜康市',
        '652323': '呼图壁县',
        '652324': '玛纳斯县',
        '652325': '奇台县',
        '652327': '吉木萨尔县',
        '652328': '木垒哈萨克自治县',
        '652701': '博乐市',
        '652702': '阿拉山口市',
        '652722': '精河县',
        '652723': '温泉县',
        '652801': '库尔勒市',
        '652822': '轮台县',
        '652823': '尉犁县',
        '652824': '若羌县',
        '652825': '且末县',
        '652826': '焉耆回族自治县',
        '652827': '和静县',
        '652828': '和硕县',
        '652829': '博湖县',
        '652901': '阿克苏市',
        '652922': '温宿县',
        '652923': '库车县',
        '652924': '沙雅县',
        '652925': '新和县',
        '652926': '拜城县',
        '652927': '乌什县',
        '652928': '阿瓦提县',
        '652929': '柯坪县',
        '653001': '阿图什市',
        '653022': '阿克陶县',
        '653023': '阿合奇县',
        '653024': '乌恰县',
        '653101': '喀什市',
        '653121': '疏附县',
        '653122': '疏勒县',
        '653123': '英吉沙县',
        '653124': '泽普县',
        '653125': '莎车县',
        '653126': '叶城县',
        '653127': '麦盖提县',
        '653128': '岳普湖县',
        '653129': '伽师县',
        '653130': '巴楚县',
        '653131': '塔什库尔干塔吉克自治县',
        '653201': '和田市',
        '653221': '和田县',
        '653222': '墨玉县',
        '653223': '皮山县',
        '653224': '洛浦县',
        '653225': '策勒县',
        '653226': '于田县',
        '653227': '民丰县',
        '654002': '伊宁市',
        '654003': '奎屯市',
        '654004': '霍尔果斯市',
        '654021': '伊宁县',
        '654022': '察布查尔锡伯自治县',
        '654023': '霍城县',
        '654024': '巩留县',
        '654025': '新源县',
        '654026': '昭苏县',
        '654027': '特克斯县',
        '654028': '尼勒克县',
        '654201': '塔城市',
        '654202': '乌苏市',
        '654221': '额敏县',
        '654223': '沙湾县',
        '654224': '托里县',
        '654225': '裕民县',
        '654226': '和布克赛尔蒙古自治县',
        '654301': '阿勒泰市',
        '654321': '布尔津县',
        '654322': '富蕴县',
        '654323': '福海县',
        '654324': '哈巴河县',
        '654325': '青河县',
        '654326': '吉木乃县',
        '654390': '北屯市',
        '659001': '石河子市',
        '659002': '阿拉尔市',
        '659003': '图木舒克市',
        '659004': '五家渠市',
        '710101': '中正区',
        '710102': '大同区',
        '710103': '中山区',
        '710104': '松山区',
        '710105': '大安区',
        '710106': '万华区',
        '710107': '信义区',
        '710108': '士林区',
        '710109': '北投区',
        '710110': '内湖区',
        '710111': '南港区',
        '710112': '文山区',
        '710199': '其它区',
        '710201': '新兴区',
        '710202': '前金区',
        '710203': '芩雅区',
        '710204': '盐埕区',
        '710205': '鼓山区',
        '710206': '旗津区',
        '710207': '前镇区',
        '710208': '三民区',
        '710209': '左营区',
        '710210': '楠梓区',
        '710211': '小港区',
        '710241': '苓雅区',
        '710242': '仁武区',
        '710243': '大社区',
        '710244': '冈山区',
        '710245': '路竹区',
        '710246': '阿莲区',
        '710247': '田寮区',
        '710248': '燕巢区',
        '710249': '桥头区',
        '710250': '梓官区',
        '710251': '弥陀区',
        '710252': '永安区',
        '710253': '湖内区',
        '710254': '凤山区',
        '710255': '大寮区',
        '710256': '林园区',
        '710257': '鸟松区',
        '710258': '大树区',
        '710259': '旗山区',
        '710260': '美浓区',
        '710261': '六龟区',
        '710262': '内门区',
        '710263': '杉林区',
        '710264': '甲仙区',
        '710265': '桃源区',
        '710266': '那玛夏区',
        '710267': '茂林区',
        '710268': '茄萣区',
        '710299': '其它区',
        '710301': '中西区',
        '710302': '东区',
        '710303': '南区',
        '710304': '北区',
        '710305': '安平区',
        '710306': '安南区',
        '710339': '永康区',
        '710340': '归仁区',
        '710341': '新化区',
        '710342': '左镇区',
        '710343': '玉井区',
        '710344': '楠西区',
        '710345': '南化区',
        '710346': '仁德区',
        '710347': '关庙区',
        '710348': '龙崎区',
        '710349': '官田区',
        '710350': '麻豆区',
        '710351': '佳里区',
        '710352': '西港区',
        '710353': '七股区',
        '710354': '将军区',
        '710355': '学甲区',
        '710356': '北门区',
        '710357': '新营区',
        '710358': '后壁区',
        '710359': '白河区',
        '710360': '东山区',
        '710361': '六甲区',
        '710362': '下营区',
        '710363': '柳营区',
        '710364': '盐水区',
        '710365': '善化区',
        '710366': '大内区',
        '710367': '山上区',
        '710368': '新市区',
        '710369': '安定区',
        '710399': '其它区',
        '710401': '中区',
        '710402': '东区',
        '710403': '南区',
        '710404': '西区',
        '710405': '北区',
        '710406': '北屯区',
        '710407': '西屯区',
        '710408': '南屯区',
        '710431': '太平区',
        '710432': '大里区',
        '710433': '雾峰区',
        '710434': '乌日区',
        '710435': '丰原区',
        '710436': '后里区',
        '710437': '石冈区',
        '710438': '东势区',
        '710439': '和平区',
        '710440': '新社区',
        '710441': '潭子区',
        '710442': '大雅区',
        '710443': '神冈区',
        '710444': '大肚区',
        '710445': '沙鹿区',
        '710446': '龙井区',
        '710447': '梧栖区',
        '710448': '清水区',
        '710449': '大甲区',
        '710450': '外埔区',
        '710451': '大安区',
        '710499': '其它区',
        '710507': '金沙镇',
        '710508': '金湖镇',
        '710509': '金宁乡',
        '710510': '金城镇',
        '710511': '烈屿乡',
        '710512': '乌坵乡',
        '710614': '南投市',
        '710615': '中寮乡',
        '710616': '草屯镇',
        '710617': '国姓乡',
        '710618': '埔里镇',
        '710619': '仁爱乡',
        '710620': '名间乡',
        '710621': '集集镇',
        '710622': '水里乡',
        '710623': '鱼池乡',
        '710624': '信义乡',
        '710625': '竹山镇',
        '710626': '鹿谷乡',
        '710701': '仁爱区',
        '710702': '信义区',
        '710703': '中正区',
        '710704': '中山区',
        '710705': '安乐区',
        '710706': '暖暖区',
        '710707': '七堵区',
        '710799': '其它区',
        '710801': '东区',
        '710802': '北区',
        '710803': '香山区',
        '710899': '其它区',
        '710901': '东区',
        '710902': '西区',
        '710999': '其它区',
        '711130': '万里区',
        '711132': '板桥区',
        '711133': '汐止区',
        '711134': '深坑区',
        '711136': '瑞芳区',
        '711137': '平溪区',
        '711138': '双溪区',
        '711140': '新店区',
        '711141': '坪林区',
        '711142': '乌来区',
        '711143': '永和区',
        '711144': '中和区',
        '711145': '土城区',
        '711146': '三峡区',
        '711147': '树林区',
        '711149': '三重区',
        '711150': '新庄区',
        '711151': '泰山区',
        '711152': '林口区',
        '711154': '五股区',
        '711155': '八里区',
        '711156': '淡水区',
        '711157': '三芝区',
        '810101': '中西区',
        '810102': '湾仔',
        '810103': '东区',
        '810104': '南区',
        '810201': '九龙城区',
        '810202': '油尖旺区',
        '810203': '深水埗区',
        '810204': '黄大仙区',
        '810205': '观塘区',
        '810301': '北区',
        '810302': '大埔区',
        '810303': '沙田区',
        '810304': '西贡区',
        '810305': '元朗区',
        '810306': '屯门区',
        '810307': '荃湾区',
        '810308': '葵青区',
        '810309': '离岛区',
        '820101': '澳门半岛',
        '820201': '离岛'
    }
});

/***/ }),

/***/ "7Ndf":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".page.uploadIdPhotoFirst .lookiconHead[data-v-46b91782]{position:relative;top:-105px;left:-65px;color:#6495ed;font-size:25px}.page.uploadIdPhotoFirst .deleteiconHead[data-v-46b91782]{position:relative;top:-105px;left:65px;color:#6495ed;font-size:20px}.page.uploadIdPhotoFirst .headPortrait[data-v-46b91782]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;padding:5px;-webkit-box-sizing:border-box;box-sizing:border-box}.page.uploadIdPhotoFirst .vanIcon[data-v-46b91782]{font-size:40px;line-height:150px;color:#bebebe}.page.uploadIdPhotoFirst .imgList[data-v-46b91782]{text-align:center;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;height:120px}.page.uploadIdPhotoFirst .imgList .imgSize[data-v-46b91782]{height:110px;border:1px solid #6666;width:90%;margin-top:10px}.page.uploadIdPhotoFirst .van-picker[data-v-46b91782]{position:fixed;width:100%;bottom:0;z-index:100}.page.uploadIdPhotoFirst .fade-enter-active[data-v-46b91782],.page.uploadIdPhotoFirst .fade-leave-active[data-v-46b91782]{-webkit-transition:bottom .5s;transition:bottom .5s}.page.uploadIdPhotoFirst .fade-enter[data-v-46b91782],.page.uploadIdPhotoFirst .fade-leave-to[data-v-46b91782]{bottom:-388px}.page.uploadIdPhotoFirst .base-info-title[data-v-46b91782]{color:gray;padding:12px;font-size:.8rem;border-bottom:1px solid #e8e8e8}.photo_container[data-v-46b91782],.photo_content[data-v-46b91782]{display:-webkit-box;display:-ms-flexbox;display:flex}.photo_content[data-v-46b91782]{-webkit-box-flex:1;-ms-flex:1;flex:1;-ms-flex-pack:distribute;justify-content:space-around}.photo_content img[data-v-46b91782]{width:100%;height:124px}p[data-v-46b91782]{margin:0}", ""]);

// exports


/***/ }),

/***/ "8eB/":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CityService; });
var cityData = __webpack_require__("AAwO");
// import AreaData from "~/assets/area";
var CityService = /** @class */function () {
    function CityService() {}
    /**
     * 获取城市信息
     * @param level
     * @param id
     */
    CityService.getCityData = function (_a) {
        var _b = _a === void 0 ? {} : _a,
            _c = _b.level,
            level = _c === void 0 ? 3 : _c,
            _d = _b.id,
            id = _d === void 0 ? 1 : _d;
        var fun = function fun(id, currentLevel) {
            if (currentLevel === void 0) {
                currentLevel = 1;
            }
            var items = new Array();
            cityData.filter(function (x) {
                return x.pid === id;
            }).forEach(function (x) {
                // 生成城市对象
                var item = {
                    value: x.id,
                    label: x.name
                };
                // 检测获取级别
                if (currentLevel < level) {
                    var children = fun(x.id, currentLevel + 1);
                    if (children && children.length > 0) {
                        item.children = children;
                    }
                }
                items.push(item);
            });
            return items;
        };
        return fun(id);
    };
    /**
     * 获取城市节点父元素
     * @param id
     */
    CityService.getCityParent = function (id) {
        var result = [];
        // 向根节点遍历
        var fun = function fun(itemId) {
            var item = cityData.find(function (x) {
                return x.id === itemId;
            });
            if (item && item.pid !== 1) {
                result.unshift(item.pid);
                fun(item.pid);
            }
        };
        fun(id);
        return result;
    };
    /**
     * 获取城市名称
     * @param id
     */
    CityService.getCityName = function () {
        var ids = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            ids[_i] = arguments[_i];
        }
        var results = [];
        ids.forEach(function (id) {
            var item = cityData.find(function (c) {
                return c.id === id;
            }) || {};
            results.push(item.name);
        });
        return results.length < 2 ? results[0] : results;
    };
    return CityService;
}();


/***/ }),

/***/ "8rjq":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".component.trademark .logo[data-v-c9c367ae]{width:20%;float:left}.component.trademark .logo .logoDetails[data-v-c9c367ae]{font-size:12px}", ""]);

// exports


/***/ }),

/***/ "9+Ux":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/vue/dist/vue.esm.js
var vue_esm = __webpack_require__("7+uW");

// EXTERNAL MODULE: ./node_modules/vue-class-component/dist/vue-class-component.common.js
var vue_class_component_common = __webpack_require__("c+8m");
var vue_class_component_common_default = /*#__PURE__*/__webpack_require__.n(vue_class_component_common);

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("ipus");

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/pages/contact-information.vue
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var contact_information_Login = /** @class */ (function (_super) {
    __extends(Login, _super);
    function Login() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // 联系人1
        _this.relationBot = false;
        _this.relations = [];
        // 联系人2
        _this.relationBotTwo = false;
        _this.relationsTwo = [];
        _this.contactModel = {
            phone: "",
            username: "",
            relation: '',
            falseRelation: '',
            phoneTwo: "",
            usernameTwo: "",
            relationTwo: '',
            falseRelationTwo: '',
        };
        _this.value = null;
        // 验证规则
        _this.rules = {
            falseRelation: { required: true, message: '请选择与承租人关系' },
            username: { required: true, message: '请输入联系人姓名' },
            phone: [{ required: true, message: "请输入正确的联系人手机号" }, { validator: _this.$validator.phoneNumber }],
            falseRelationTwo: { required: true, message: '请选择与承租人关系' },
            usernameTwo: { required: true, message: '请输入联系人姓名' },
            phoneTwo: [{ required: true, message: "请输入正确的联系人手机号" }, { validator: _this.$validator.phoneNumber }],
        };
        return _this;
    }
    /**
     * 联系人1 下拉点击确定
     */
    Login.prototype.relationfirm = function (val) {
        this.contactModel.relation = val.value;
        this.contactModel.falseRelation = this.$dict.getDictName(Number(this.contactModel.relation));
        this.relationBot = false;
    };
    Login.prototype.relationfirmTwo = function (val) {
        this.contactModel.relationTwo = val.value;
        this.contactModel.falseRelationTwo = this.$dict.getDictName(Number(this.contactModel.relationTwo));
        this.relationBotTwo = false;
    };
    /**
     * 联系人点击下一步
     */
    Login.prototype.relationAffirm = function () {
        var _this = this;
        this.$validator.validate(this.contactModel, this.rules).then(function (error) {
            if (!error) {
                _this.$router.push('/add-information');
                _this.linkman(_this.contactModel);
            }
            else {
                _this.$toast(error);
            }
        });
    };
    Login.prototype.mounted = function () {
        // 承租人关系 直系亲属
        this.relations = this.$dict.getDictData('0015').map(function (v) {
            return Object.assign({ text: v.label }, v);
        });
        // 承租人关系 非直系亲属
        this.relationsTwo = this.$dict.getDictData('0016').map(function (v) {
            return Object.assign({ text: v.label }, v);
        });
    };
    __decorate([
        lib["c" /* Mutation */]
    ], Login.prototype, "linkman", void 0);
    __decorate([
        lib["d" /* State */]
    ], Login.prototype, "intoA", void 0);
    Login = __decorate([
        vue_class_component_common_default()({})
    ], Login);
    return Login;
}(vue_esm["default"]));
/* harmony default export */ var contact_information = (contact_information_Login);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-63c9560a","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/pages/contact-information.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"page contactInformation"},[_c('van-row',[_c('p',{staticClass:"base-info-title"},[_vm._v("联系人一")]),_vm._v(" "),_c('van-cell-group',[_c('van-field',{attrs:{"label":"与承租人关系","placeholder":"请选择与承租人关系","required":""},on:{"click":function($event){_vm.relationBot=true}},model:{value:(_vm.contactModel.falseRelation),callback:function ($$v) {_vm.$set(_vm.contactModel, "falseRelation", $$v)},expression:"contactModel.falseRelation"}}),_vm._v(" "),_c('van-field',{attrs:{"label":"姓名","placeholder":"请输入联系人姓名","required":""},model:{value:(_vm.contactModel.username),callback:function ($$v) {_vm.$set(_vm.contactModel, "username", $$v)},expression:"contactModel.username"}}),_vm._v(" "),_c('van-field',{attrs:{"label":"手机号","placeholder":"请输入联系人手机号","required":""},model:{value:(_vm.contactModel.phone),callback:function ($$v) {_vm.$set(_vm.contactModel, "phone", $$v)},expression:"contactModel.phone"}})],1)],1),_vm._v(" "),_c('van-row',[_c('p',{staticClass:"base-info-title"},[_vm._v("联系人二")]),_vm._v(" "),_c('van-cell-group',[_c('van-field',{attrs:{"label":"与承租人关系","placeholder":"请选择与承租人关系","required":""},on:{"click":function($event){_vm.relationBotTwo=true}},model:{value:(_vm.contactModel.falseRelationTwo),callback:function ($$v) {_vm.$set(_vm.contactModel, "falseRelationTwo", $$v)},expression:"contactModel.falseRelationTwo"}}),_vm._v(" "),_c('van-field',{attrs:{"label":"姓名","placeholder":"请输入联系人姓名","required":""},model:{value:(_vm.contactModel.usernameTwo),callback:function ($$v) {_vm.$set(_vm.contactModel, "usernameTwo", $$v)},expression:"contactModel.usernameTwo"}}),_vm._v(" "),_c('van-field',{attrs:{"label":"手机号","placeholder":"请输入联系人手机号","required":""},model:{value:(_vm.contactModel.phoneTwo),callback:function ($$v) {_vm.$set(_vm.contactModel, "phoneTwo", $$v)},expression:"contactModel.phoneTwo"}})],1)],1),_vm._v(" "),_c('transition',{attrs:{"name":"fade"}},[_c('van-picker',{directives:[{name:"show",rawName:"v-show",value:(_vm.relationBot),expression:"relationBot"}],ref:"vanpicker",attrs:{"columns":_vm.relations,"show-toolbar":""},on:{"confirm":_vm.relationfirm,"cancel":function($event){_vm.relationBot=false}}})],1),_vm._v(" "),_c('transition',{attrs:{"name":"fade"}},[_c('van-picker',{directives:[{name:"show",rawName:"v-show",value:(_vm.relationBotTwo),expression:"relationBotTwo"}],ref:"vanpicker",attrs:{"columns":_vm.relationsTwo,"show-toolbar":""},on:{"confirm":_vm.relationfirmTwo,"cancel":function($event){_vm.relationBotTwo=false}}})],1),_vm._v(" "),_c('van-button',{attrs:{"type":"primary","bottom-action":""},on:{"click":_vm.relationAffirm}},[_vm._v("下一步")])],1)}
var staticRenderFns = []

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/component-normalizer.js
var component_normalizer = __webpack_require__("XyMi");

// CONCATENATED MODULE: ./src/pages/contact-information.vue
function injectStyle (context) {
  __webpack_require__("2g+w")
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-63c9560a"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(component_normalizer["a" /* default */])(
  contact_information,
  render,
  staticRenderFns,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var pages_contact_information = __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "9New":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("rxp8");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("1e46a342", content, true, {});

/***/ }),

/***/ "AAwO":
/***/ (function(module, exports) {

module.exports = [{"id":1,"pid":0,"name":"中国"},{"id":2,"pid":1,"name":"山东"},{"id":3,"pid":2,"name":"滨州市"},{"id":4,"pid":3,"name":"沾化区"},{"id":5,"pid":3,"name":"博兴县"},{"id":6,"pid":3,"name":"惠民县"},{"id":7,"pid":3,"name":"无棣县"},{"id":8,"pid":3,"name":"阳信县"},{"id":9,"pid":3,"name":"邹平县"},{"id":10,"pid":3,"name":"滨城区"},{"id":11,"pid":2,"name":"烟台市"},{"id":12,"pid":11,"name":"莱阳市"},{"id":13,"pid":11,"name":"莱山区"},{"id":14,"pid":11,"name":"栖霞市"},{"id":15,"pid":11,"name":"芝罘区"},{"id":16,"pid":11,"name":"招远市"},{"id":17,"pid":11,"name":"龙口市"},{"id":18,"pid":11,"name":"福山区"},{"id":19,"pid":11,"name":"海阳市"},{"id":20,"pid":11,"name":"蓬莱市"},{"id":21,"pid":11,"name":"牟平区"},{"id":22,"pid":11,"name":"莱州市"},{"id":23,"pid":11,"name":"长岛县"},{"id":24,"pid":2,"name":"临沂市"},{"id":25,"pid":24,"name":"河东区"},{"id":26,"pid":24,"name":"蒙阴县"},{"id":27,"pid":24,"name":"莒南县"},{"id":28,"pid":24,"name":"兰山区"},{"id":29,"pid":24,"name":"罗庄区"},{"id":30,"pid":24,"name":"平邑县"},{"id":31,"pid":24,"name":"临沭县"},{"id":32,"pid":24,"name":"费县"},{"id":33,"pid":24,"name":"沂水县"},{"id":34,"pid":24,"name":"郯城县"},{"id":35,"pid":24,"name":"沂南县"},{"id":36,"pid":24,"name":"兰陵县"},{"id":37,"pid":2,"name":"德州市"},{"id":38,"pid":37,"name":"德城区"},{"id":39,"pid":37,"name":"夏津县"},{"id":40,"pid":37,"name":"乐陵市"},{"id":41,"pid":37,"name":"临邑县"},{"id":42,"pid":37,"name":"庆云县"},{"id":43,"pid":37,"name":"武城县"},{"id":44,"pid":37,"name":"禹城市"},{"id":45,"pid":37,"name":"陵城区"},{"id":46,"pid":37,"name":"平原县"},{"id":47,"pid":37,"name":"宁津县"},{"id":48,"pid":37,"name":"齐河县"},{"id":49,"pid":2,"name":"菏泽市"},{"id":50,"pid":49,"name":"单县"},{"id":51,"pid":49,"name":"成武县"},{"id":52,"pid":49,"name":"牡丹区"},{"id":53,"pid":49,"name":"定陶县"},{"id":54,"pid":49,"name":"曹县"},{"id":55,"pid":49,"name":"巨野县"},{"id":56,"pid":49,"name":"东明县"},{"id":57,"pid":49,"name":"郓城县"},{"id":58,"pid":49,"name":"鄄城县"},{"id":59,"pid":2,"name":"潍坊市"},{"id":60,"pid":59,"name":"临朐县"},{"id":61,"pid":59,"name":"安丘市"},{"id":62,"pid":59,"name":"昌乐县"},{"id":63,"pid":59,"name":"高密市"},{"id":64,"pid":59,"name":"诸城市"},{"id":65,"pid":59,"name":"潍城区"},{"id":66,"pid":59,"name":"青州市"},{"id":67,"pid":59,"name":"坊子区"},{"id":68,"pid":59,"name":"奎文区"},{"id":69,"pid":59,"name":"寿光市"},{"id":70,"pid":59,"name":"寒亭区"},{"id":71,"pid":59,"name":"昌邑市"},{"id":72,"pid":2,"name":"莱芜市"},{"id":73,"pid":72,"name":"莱城区"},{"id":74,"pid":72,"name":"钢城区"},{"id":75,"pid":2,"name":"淄博市"},{"id":76,"pid":75,"name":"桓台县"},{"id":77,"pid":75,"name":"高青县"},{"id":78,"pid":75,"name":"张店区"},{"id":79,"pid":75,"name":"沂源县"},{"id":80,"pid":75,"name":"淄川区"},{"id":81,"pid":75,"name":"博山区"},{"id":82,"pid":75,"name":"周村区"},{"id":83,"pid":75,"name":"临淄区"},{"id":84,"pid":2,"name":"济宁市"},{"id":85,"pid":84,"name":"金乡县"},{"id":86,"pid":84,"name":"嘉祥县"},{"id":87,"pid":84,"name":"任城区"},{"id":88,"pid":84,"name":"泗水县"},{"id":89,"pid":84,"name":"邹城市"},{"id":90,"pid":84,"name":"汶上县"},{"id":91,"pid":84,"name":"曲阜市"},{"id":92,"pid":84,"name":"梁山县"},{"id":93,"pid":84,"name":"微山县"},{"id":94,"pid":84,"name":"鱼台县"},{"id":95,"pid":84,"name":"兖州区"},{"id":96,"pid":2,"name":"东营市"},{"id":97,"pid":96,"name":"利津县"},{"id":98,"pid":96,"name":"东营区"},{"id":99,"pid":96,"name":"河口区"},{"id":100,"pid":96,"name":"广饶县"},{"id":101,"pid":96,"name":"垦利县"},{"id":102,"pid":2,"name":"日照市"},{"id":103,"pid":102,"name":"岚山区"},{"id":104,"pid":102,"name":"东港区"},{"id":105,"pid":102,"name":"五莲县"},{"id":106,"pid":102,"name":"莒县"},{"id":107,"pid":2,"name":"泰安市"},{"id":108,"pid":107,"name":"肥城市"},{"id":109,"pid":107,"name":"宁阳县"},{"id":110,"pid":107,"name":"东平县"},{"id":111,"pid":107,"name":"新泰市"},{"id":112,"pid":107,"name":"泰山区"},{"id":113,"pid":107,"name":"岱岳区"},{"id":114,"pid":2,"name":"枣庄市"},{"id":115,"pid":114,"name":"台儿庄区"},{"id":116,"pid":114,"name":"滕州市"},{"id":117,"pid":114,"name":"市中区"},{"id":118,"pid":114,"name":"薛城区"},{"id":119,"pid":114,"name":"峄城区"},{"id":120,"pid":114,"name":"山亭区"},{"id":121,"pid":2,"name":"聊城市"},{"id":122,"pid":121,"name":"东昌府区"},{"id":123,"pid":121,"name":"临清市"},{"id":124,"pid":121,"name":"冠县"},{"id":125,"pid":121,"name":"莘县"},{"id":126,"pid":121,"name":"高唐县"},{"id":127,"pid":121,"name":"东阿县"},{"id":128,"pid":121,"name":"阳谷县"},{"id":129,"pid":121,"name":"茌平县"},{"id":130,"pid":2,"name":"威海市"},{"id":131,"pid":130,"name":"乳山市"},{"id":132,"pid":130,"name":"环翠区"},{"id":133,"pid":130,"name":"荣成市"},{"id":134,"pid":130,"name":"文登区"},{"id":135,"pid":2,"name":"青岛市"},{"id":136,"pid":135,"name":"李沧区"},{"id":137,"pid":135,"name":"平度市"},{"id":138,"pid":135,"name":"崂山区"},{"id":139,"pid":135,"name":"胶州市"},{"id":140,"pid":135,"name":"城阳区"},{"id":141,"pid":135,"name":"即墨市"},{"id":142,"pid":135,"name":"莱西市"},{"id":143,"pid":135,"name":"黄岛区"},{"id":144,"pid":135,"name":"市南区"},{"id":145,"pid":135,"name":"市北区"},{"id":146,"pid":2,"name":"济南市"},{"id":147,"pid":146,"name":"槐荫区"},{"id":148,"pid":146,"name":"市中区"},{"id":149,"pid":146,"name":"天桥区"},{"id":150,"pid":146,"name":"历下区"},{"id":151,"pid":146,"name":"历城区"},{"id":152,"pid":146,"name":"济阳县"},{"id":153,"pid":146,"name":"长清区"},{"id":154,"pid":146,"name":"平阴县"},{"id":155,"pid":146,"name":"章丘市"},{"id":156,"pid":146,"name":"商河县"},{"id":157,"pid":1,"name":"福建"},{"id":158,"pid":157,"name":"龙岩市"},{"id":159,"pid":158,"name":"长汀县"},{"id":160,"pid":158,"name":"连城县"},{"id":161,"pid":158,"name":"永定县"},{"id":162,"pid":158,"name":"武平县"},{"id":163,"pid":158,"name":"上杭县"},{"id":164,"pid":158,"name":"新罗区"},{"id":165,"pid":158,"name":"漳平市"},{"id":166,"pid":157,"name":"南平市"},{"id":167,"pid":166,"name":"松溪县"},{"id":168,"pid":166,"name":"浦城县"},{"id":169,"pid":166,"name":"顺昌县"},{"id":170,"pid":166,"name":"政和县"},{"id":171,"pid":166,"name":"光泽县"},{"id":172,"pid":166,"name":"延平区"},{"id":173,"pid":166,"name":"邵武市"},{"id":174,"pid":166,"name":"建瓯市"},{"id":175,"pid":166,"name":"武夷山市"},{"id":176,"pid":166,"name":"建阳市"},{"id":177,"pid":157,"name":"莆田市"},{"id":178,"pid":177,"name":"城厢区"},{"id":179,"pid":177,"name":"仙游县"},{"id":180,"pid":177,"name":"荔城区"},{"id":181,"pid":177,"name":"涵江区"},{"id":182,"pid":177,"name":"秀屿区"},{"id":183,"pid":157,"name":"福州市"},{"id":184,"pid":183,"name":"台江区"},{"id":185,"pid":183,"name":"永泰县"},{"id":186,"pid":183,"name":"马尾区"},{"id":187,"pid":183,"name":"长乐市"},{"id":188,"pid":183,"name":"罗源县"},{"id":189,"pid":183,"name":"仓山区"},{"id":190,"pid":183,"name":"闽侯县"},{"id":191,"pid":183,"name":"鼓楼区"},{"id":192,"pid":183,"name":"平潭县"},{"id":193,"pid":183,"name":"晋安区"},{"id":194,"pid":183,"name":"连江县"},{"id":195,"pid":183,"name":"闽清县"},{"id":196,"pid":183,"name":"福清市"},{"id":197,"pid":157,"name":"泉州市"},{"id":198,"pid":197,"name":"永春县"},{"id":199,"pid":197,"name":"洛江区"},{"id":200,"pid":197,"name":"惠安县"},{"id":201,"pid":197,"name":"德化县"},{"id":202,"pid":197,"name":"泉港区"},{"id":203,"pid":197,"name":"晋江市"},{"id":204,"pid":197,"name":"南安市"},{"id":205,"pid":197,"name":"鲤城区"},{"id":206,"pid":197,"name":"石狮市"},{"id":207,"pid":197,"name":"安溪县"},{"id":208,"pid":197,"name":"金门县"},{"id":209,"pid":197,"name":"丰泽区"},{"id":210,"pid":157,"name":"漳州市"},{"id":211,"pid":210,"name":"龙海市"},{"id":212,"pid":210,"name":"长泰县"},{"id":213,"pid":210,"name":"华安县"},{"id":214,"pid":210,"name":"漳浦县"},{"id":215,"pid":210,"name":"云霄县"},{"id":216,"pid":210,"name":"芗城区"},{"id":217,"pid":210,"name":"东山县"},{"id":218,"pid":210,"name":"平和县"},{"id":219,"pid":210,"name":"南靖县"},{"id":220,"pid":210,"name":"诏安县"},{"id":221,"pid":210,"name":"龙文区"},{"id":222,"pid":157,"name":"三明市"},{"id":223,"pid":222,"name":"永安市"},{"id":224,"pid":222,"name":"将乐县"},{"id":225,"pid":222,"name":"建宁县"},{"id":226,"pid":222,"name":"清流县"},{"id":227,"pid":222,"name":"梅列区"},{"id":228,"pid":222,"name":"泰宁县"},{"id":229,"pid":222,"name":"宁化县"},{"id":230,"pid":222,"name":"大田县"},{"id":231,"pid":222,"name":"沙县"},{"id":232,"pid":222,"name":"尤溪县"},{"id":233,"pid":222,"name":"明溪县"},{"id":234,"pid":222,"name":"三元区"},{"id":235,"pid":157,"name":"厦门市"},{"id":236,"pid":235,"name":"海沧区"},{"id":237,"pid":235,"name":"湖里区"},{"id":238,"pid":235,"name":"集美区"},{"id":239,"pid":235,"name":"同安区"},{"id":240,"pid":235,"name":"思明区"},{"id":241,"pid":235,"name":"翔安区"},{"id":242,"pid":157,"name":"宁德市"},{"id":243,"pid":242,"name":"柘荣县"},{"id":244,"pid":242,"name":"霞浦县"},{"id":245,"pid":242,"name":"屏南县"},{"id":246,"pid":242,"name":"福鼎市"},{"id":247,"pid":242,"name":"寿宁县"},{"id":248,"pid":242,"name":"蕉城区"},{"id":249,"pid":242,"name":"古田县"},{"id":250,"pid":242,"name":"福安市"},{"id":251,"pid":242,"name":"周宁县"},{"id":252,"pid":1,"name":"台湾"},{"id":253,"pid":252,"name":"高雄市"},{"id":254,"pid":253,"name":"前金区"},{"id":255,"pid":253,"name":"三民区"},{"id":256,"pid":253,"name":"新兴区"},{"id":257,"pid":253,"name":"芩雅区"},{"id":258,"pid":253,"name":"旗津区"},{"id":259,"pid":253,"name":"前镇区"},{"id":260,"pid":253,"name":"左营区"},{"id":261,"pid":253,"name":"鼓山区"},{"id":262,"pid":253,"name":"盐埕区"},{"id":263,"pid":253,"name":"小港区"},{"id":264,"pid":253,"name":"楠梓区"},{"id":265,"pid":252,"name":"台中市"},{"id":266,"pid":265,"name":"北屯区"},{"id":267,"pid":265,"name":"中区"},{"id":268,"pid":265,"name":"西屯区"},{"id":269,"pid":265,"name":"南屯区"},{"id":270,"pid":265,"name":"东区"},{"id":271,"pid":265,"name":"南区"},{"id":272,"pid":265,"name":"北区"},{"id":273,"pid":265,"name":"西区"},{"id":274,"pid":252,"name":"南投县"},{"id":275,"pid":274,"name":"南投市"},{"id":276,"pid":274,"name":"水里乡"},{"id":277,"pid":274,"name":"仁爱乡"},{"id":278,"pid":274,"name":"鱼池乡"},{"id":279,"pid":274,"name":"信义乡"},{"id":280,"pid":274,"name":"鹿谷乡"},{"id":281,"pid":274,"name":"集集镇"},{"id":282,"pid":274,"name":"中寮乡"},{"id":283,"pid":274,"name":"埔里镇"},{"id":284,"pid":274,"name":"竹山镇"},{"id":285,"pid":274,"name":"名间乡"},{"id":286,"pid":274,"name":"草屯镇"},{"id":287,"pid":274,"name":"国姓乡"},{"id":288,"pid":252,"name":"花莲县"},{"id":289,"pid":288,"name":"光复乡"},{"id":290,"pid":288,"name":"玉里镇"},{"id":291,"pid":288,"name":"吉安乡"},{"id":292,"pid":288,"name":"新城乡"},{"id":293,"pid":288,"name":"瑞穗乡"},{"id":294,"pid":288,"name":"富里乡"},{"id":295,"pid":288,"name":"卓溪乡"},{"id":296,"pid":288,"name":"万荣乡"},{"id":297,"pid":288,"name":"寿丰乡"},{"id":298,"pid":288,"name":"凤林镇"},{"id":299,"pid":288,"name":"丰滨乡"},{"id":300,"pid":288,"name":"花莲市"},{"id":301,"pid":288,"name":"秀林乡"},{"id":302,"pid":252,"name":"桃园县"},{"id":303,"pid":302,"name":"大园乡"},{"id":304,"pid":302,"name":"复兴乡"},{"id":305,"pid":302,"name":"中坜市"},{"id":306,"pid":302,"name":"观音乡"},{"id":307,"pid":302,"name":"龙潭乡"},{"id":308,"pid":302,"name":"桃园市"},{"id":309,"pid":302,"name":"八德市"},{"id":310,"pid":302,"name":"龟山乡"},{"id":311,"pid":302,"name":"新屋乡"},{"id":312,"pid":302,"name":"芦竹乡"},{"id":313,"pid":302,"name":"大溪镇"},{"id":314,"pid":302,"name":"平镇市"},{"id":315,"pid":302,"name":"杨梅镇"},{"id":316,"pid":252,"name":"苗栗县"},{"id":317,"pid":316,"name":"公馆乡"},{"id":318,"pid":316,"name":"头份镇"},{"id":319,"pid":316,"name":"卓兰镇"},{"id":320,"pid":316,"name":"泰安乡"},{"id":321,"pid":316,"name":"大湖乡"},{"id":322,"pid":316,"name":"三义乡"},{"id":323,"pid":316,"name":"南庄乡"},{"id":324,"pid":316,"name":"头屋乡"},{"id":325,"pid":316,"name":"苑里镇"},{"id":326,"pid":316,"name":"竹南镇"},{"id":327,"pid":316,"name":"通霄镇"},{"id":328,"pid":316,"name":"后龙镇"},{"id":329,"pid":316,"name":"造桥乡"},{"id":330,"pid":316,"name":"苗栗市"},{"id":331,"pid":316,"name":"铜锣乡"},{"id":332,"pid":316,"name":"西湖乡"},{"id":333,"pid":316,"name":"三湾乡"},{"id":334,"pid":316,"name":"狮潭乡"},{"id":335,"pid":252,"name":"澎湖县"},{"id":336,"pid":335,"name":"七美乡"},{"id":337,"pid":335,"name":"湖西乡"},{"id":338,"pid":335,"name":"望安乡"},{"id":339,"pid":335,"name":"西屿乡"},{"id":340,"pid":335,"name":"马公市"},{"id":341,"pid":335,"name":"白沙乡"},{"id":342,"pid":252,"name":"宜兰县"},{"id":343,"pid":342,"name":"员山乡"},{"id":344,"pid":342,"name":"冬山乡"},{"id":345,"pid":342,"name":"壮围乡"},{"id":346,"pid":342,"name":"南澳乡"},{"id":347,"pid":342,"name":"五结乡"},{"id":348,"pid":342,"name":"大同乡"},{"id":349,"pid":342,"name":"头城镇"},{"id":350,"pid":342,"name":"罗东镇"},{"id":351,"pid":342,"name":"苏澳镇"},{"id":352,"pid":342,"name":"三星乡"},{"id":353,"pid":342,"name":"礁溪乡"},{"id":354,"pid":342,"name":"宜兰市"},{"id":355,"pid":252,"name":"彰化县"},{"id":356,"pid":355,"name":"埤头乡"},{"id":357,"pid":355,"name":"溪州乡"},{"id":358,"pid":355,"name":"埔心乡"},{"id":359,"pid":355,"name":"和美镇"},{"id":360,"pid":355,"name":"大村乡"},{"id":361,"pid":355,"name":"二水乡"},{"id":362,"pid":355,"name":"田尾乡"},{"id":363,"pid":355,"name":"鹿港镇"},{"id":364,"pid":355,"name":"芳苑乡"},{"id":365,"pid":355,"name":"竹塘乡"},{"id":366,"pid":355,"name":"员林镇"},{"id":367,"pid":355,"name":"花坛乡"},{"id":368,"pid":355,"name":"北斗镇"},{"id":369,"pid":355,"name":"大城乡"},{"id":370,"pid":355,"name":"田中镇"},{"id":371,"pid":355,"name":"永靖乡"},{"id":372,"pid":355,"name":"彰化市"},{"id":373,"pid":355,"name":"线西乡"},{"id":374,"pid":355,"name":"福兴乡"},{"id":375,"pid":355,"name":"二林镇"},{"id":376,"pid":355,"name":"芬园乡"},{"id":377,"pid":355,"name":"溪湖镇"},{"id":378,"pid":355,"name":"社头乡"},{"id":379,"pid":355,"name":"秀水乡"},{"id":380,"pid":355,"name":"伸港乡"},{"id":381,"pid":355,"name":"埔盐乡"},{"id":382,"pid":252,"name":"基隆市"},{"id":383,"pid":382,"name":"安乐区"},{"id":384,"pid":382,"name":"中正区"},{"id":385,"pid":382,"name":"中山区"},{"id":386,"pid":382,"name":"七堵区"},{"id":387,"pid":382,"name":"暖暖区"},{"id":388,"pid":382,"name":"信义区"},{"id":389,"pid":382,"name":"仁爱区"},{"id":390,"pid":252,"name":"云林县"},{"id":391,"pid":390,"name":"土库镇"},{"id":392,"pid":390,"name":"元长乡"},{"id":393,"pid":390,"name":"口湖乡"},{"id":394,"pid":390,"name":"麦寮乡"},{"id":395,"pid":390,"name":"北港镇"},{"id":396,"pid":390,"name":"斗六市"},{"id":397,"pid":390,"name":"莿桐乡"},{"id":398,"pid":390,"name":"二仑乡"},{"id":399,"pid":390,"name":"斗南镇"},{"id":400,"pid":390,"name":"古坑乡"},{"id":401,"pid":390,"name":"仑背乡"},{"id":402,"pid":390,"name":"东势乡"},{"id":403,"pid":390,"name":"虎尾镇"},{"id":404,"pid":390,"name":"四湖乡"},{"id":405,"pid":390,"name":"西螺镇"},{"id":406,"pid":390,"name":"林内乡"},{"id":407,"pid":390,"name":"大埤乡"},{"id":408,"pid":390,"name":"褒忠乡"},{"id":409,"pid":390,"name":"水林乡"},{"id":410,"pid":390,"name":"台西乡"},{"id":411,"pid":252,"name":"嘉义市"},{"id":412,"pid":411,"name":"东区"},{"id":413,"pid":411,"name":"西区"},{"id":414,"pid":252,"name":"新北市"},{"id":415,"pid":414,"name":"坪林乡"},{"id":416,"pid":414,"name":"土城市"},{"id":417,"pid":414,"name":"五股乡"},{"id":418,"pid":414,"name":"八里乡"},{"id":419,"pid":414,"name":"深坑乡"},{"id":420,"pid":414,"name":"莺歌镇"},{"id":421,"pid":414,"name":"贡寮乡"},{"id":422,"pid":414,"name":"双溪乡"},{"id":423,"pid":414,"name":"永和市"},{"id":424,"pid":414,"name":"芦洲市"},{"id":425,"pid":414,"name":"树林市"},{"id":426,"pid":414,"name":"金山乡"},{"id":427,"pid":414,"name":"中和市"},{"id":428,"pid":414,"name":"汐止市"},{"id":429,"pid":414,"name":"瑞芳镇"},{"id":430,"pid":414,"name":"三芝乡"},{"id":431,"pid":414,"name":"平溪乡"},{"id":432,"pid":414,"name":"乌来乡"},{"id":433,"pid":414,"name":"淡水镇"},{"id":434,"pid":414,"name":"泰山乡"},{"id":435,"pid":414,"name":"新庄市"},{"id":436,"pid":414,"name":"三重市"},{"id":437,"pid":414,"name":"万里乡"},{"id":438,"pid":414,"name":"板桥市"},{"id":439,"pid":414,"name":"新店市"},{"id":440,"pid":414,"name":"石门乡"},{"id":441,"pid":414,"name":"林口乡"},{"id":442,"pid":414,"name":"石碇乡"},{"id":443,"pid":414,"name":"三峡镇"},{"id":444,"pid":252,"name":"嘉义县"},{"id":445,"pid":444,"name":"溪口乡"},{"id":446,"pid":444,"name":"义竹乡"},{"id":447,"pid":444,"name":"民雄乡"},{"id":448,"pid":444,"name":"梅山乡"},{"id":449,"pid":444,"name":"阿里山乡"},{"id":450,"pid":444,"name":"朴子市"},{"id":451,"pid":444,"name":"新港乡"},{"id":452,"pid":444,"name":"中埔乡"},{"id":453,"pid":444,"name":"大林镇"},{"id":454,"pid":444,"name":"布袋镇"},{"id":455,"pid":444,"name":"大埔乡"},{"id":456,"pid":444,"name":"鹿草乡"},{"id":457,"pid":444,"name":"水上乡"},{"id":458,"pid":444,"name":"六脚乡"},{"id":459,"pid":444,"name":"竹崎乡"},{"id":460,"pid":444,"name":"番路乡"},{"id":461,"pid":444,"name":"太保市"},{"id":462,"pid":444,"name":"东石乡"},{"id":463,"pid":252,"name":"新竹市"},{"id":464,"pid":463,"name":"东　区"},{"id":465,"pid":463,"name":"香山区"},{"id":466,"pid":463,"name":"北　区"},{"id":467,"pid":252,"name":"屏东县"},{"id":468,"pid":467,"name":"崁顶乡"},{"id":469,"pid":467,"name":"狮子乡"},{"id":470,"pid":467,"name":"琉球乡"},{"id":471,"pid":467,"name":"林边乡"},{"id":472,"pid":467,"name":"枋山乡"},{"id":473,"pid":467,"name":"新园乡"},{"id":474,"pid":467,"name":"九如乡"},{"id":475,"pid":467,"name":"泰武乡"},{"id":476,"pid":467,"name":"春日乡"},{"id":477,"pid":467,"name":"满州乡"},{"id":478,"pid":467,"name":"来义乡"},{"id":479,"pid":467,"name":"屏东市"},{"id":480,"pid":467,"name":"三地门乡"},{"id":481,"pid":467,"name":"盐埔乡"},{"id":482,"pid":467,"name":"高树乡"},{"id":483,"pid":467,"name":"佳冬乡"},{"id":484,"pid":467,"name":"车城乡"},{"id":485,"pid":467,"name":"南州乡"},{"id":486,"pid":467,"name":"牡丹乡"},{"id":487,"pid":467,"name":"万丹乡"},{"id":488,"pid":467,"name":"恒春镇"},{"id":489,"pid":467,"name":"麟洛乡"},{"id":490,"pid":467,"name":"新埤乡"},{"id":491,"pid":467,"name":"东港镇"},{"id":492,"pid":467,"name":"里港乡"},{"id":493,"pid":467,"name":"内埔乡"},{"id":494,"pid":467,"name":"枋寮乡"},{"id":495,"pid":467,"name":"雾台乡"},{"id":496,"pid":467,"name":"万峦乡"},{"id":497,"pid":467,"name":"竹田乡"},{"id":498,"pid":467,"name":"潮州镇"},{"id":499,"pid":467,"name":"长治乡"},{"id":500,"pid":467,"name":"玛家乡"},{"id":501,"pid":252,"name":"台东县"},{"id":502,"pid":501,"name":"成功镇"},{"id":503,"pid":501,"name":"海端乡"},{"id":504,"pid":501,"name":"长滨乡"},{"id":505,"pid":501,"name":"太麻里乡"},{"id":506,"pid":501,"name":"金峰乡"},{"id":507,"pid":501,"name":"绿岛乡"},{"id":508,"pid":501,"name":"兰屿乡"},{"id":509,"pid":501,"name":"台东市"},{"id":510,"pid":501,"name":"关山镇"},{"id":511,"pid":501,"name":"延平乡"},{"id":512,"pid":501,"name":"鹿野乡"},{"id":513,"pid":501,"name":"池上乡"},{"id":514,"pid":501,"name":"卑南乡"},{"id":515,"pid":501,"name":"东河乡"},{"id":516,"pid":501,"name":"大武乡"},{"id":517,"pid":501,"name":"达仁乡"},{"id":518,"pid":252,"name":"新竹县"},{"id":519,"pid":518,"name":"横山乡"},{"id":520,"pid":518,"name":"新丰乡"},{"id":521,"pid":518,"name":"北埔乡"},{"id":522,"pid":518,"name":"新埔镇"},{"id":523,"pid":518,"name":"峨眉乡"},{"id":524,"pid":518,"name":"尖石乡"},{"id":525,"pid":518,"name":"芎林乡"},{"id":526,"pid":518,"name":"宝山乡"},{"id":527,"pid":518,"name":"竹东镇"},{"id":528,"pid":518,"name":"五峰乡"},{"id":529,"pid":518,"name":"关西镇"},{"id":530,"pid":518,"name":"竹北市"},{"id":531,"pid":518,"name":"湖口乡"},{"id":532,"pid":252,"name":"台北市"},{"id":533,"pid":532,"name":"大安区"},{"id":534,"pid":532,"name":"南港区"},{"id":535,"pid":532,"name":"士林区"},{"id":536,"pid":532,"name":"中正区"},{"id":537,"pid":532,"name":"中山区"},{"id":538,"pid":532,"name":"内湖区"},{"id":539,"pid":532,"name":"信义区"},{"id":540,"pid":532,"name":"松山区"},{"id":541,"pid":532,"name":"北投区"},{"id":542,"pid":532,"name":"文山区"},{"id":543,"pid":532,"name":"大同区"},{"id":544,"pid":532,"name":"万华区"},{"id":545,"pid":252,"name":"台南市"},{"id":546,"pid":545,"name":"安平区"},{"id":547,"pid":545,"name":"东区"},{"id":548,"pid":545,"name":"南区"},{"id":549,"pid":545,"name":"北区"},{"id":550,"pid":545,"name":"安南区"},{"id":551,"pid":545,"name":"中西区"},{"id":552,"pid":1,"name":"河北"},{"id":553,"pid":552,"name":"保定市"},{"id":554,"pid":553,"name":"易县"},{"id":555,"pid":553,"name":"涞水县"},{"id":556,"pid":553,"name":"博野县"},{"id":557,"pid":553,"name":"徐水区"},{"id":558,"pid":553,"name":"清苑区"},{"id":559,"pid":553,"name":"竞秀区"},{"id":560,"pid":553,"name":"涿州市"},{"id":561,"pid":553,"name":"涞源县"},{"id":562,"pid":553,"name":"唐县"},{"id":563,"pid":553,"name":"满城区"},{"id":564,"pid":553,"name":"定兴县"},{"id":565,"pid":553,"name":"望都县"},{"id":566,"pid":553,"name":"雄县"},{"id":567,"pid":553,"name":"容城县"},{"id":568,"pid":553,"name":"曲阳县"},{"id":569,"pid":553,"name":"安国市"},{"id":570,"pid":553,"name":"顺平县"},{"id":571,"pid":553,"name":"蠡县"},{"id":572,"pid":553,"name":"高阳县"},{"id":573,"pid":553,"name":"莲池区"},{"id":574,"pid":553,"name":"高碑店市"},{"id":575,"pid":553,"name":"阜平县"},{"id":576,"pid":553,"name":"安新县"},{"id":577,"pid":553,"name":"定州市"},{"id":578,"pid":552,"name":"衡水市"},{"id":579,"pid":578,"name":"武邑县"},{"id":580,"pid":578,"name":"饶阳县"},{"id":581,"pid":578,"name":"故城县"},{"id":582,"pid":578,"name":"阜城县"},{"id":583,"pid":578,"name":"武强县"},{"id":584,"pid":578,"name":"安平县"},{"id":585,"pid":578,"name":"枣强县"},{"id":586,"pid":578,"name":"冀州市"},{"id":587,"pid":578,"name":"景县"},{"id":588,"pid":578,"name":"桃城区"},{"id":589,"pid":578,"name":"深州市"},{"id":590,"pid":552,"name":"张家口市"},{"id":591,"pid":590,"name":"宣化区"},{"id":592,"pid":590,"name":"怀安县"},{"id":593,"pid":590,"name":"崇礼县"},{"id":594,"pid":590,"name":"张北县"},{"id":595,"pid":590,"name":"赤城县"},{"id":596,"pid":590,"name":"沽源县"},{"id":597,"pid":590,"name":"阳原县"},{"id":598,"pid":590,"name":"宣化县"},{"id":599,"pid":590,"name":"怀来县"},{"id":600,"pid":590,"name":"涿鹿县"},{"id":601,"pid":590,"name":"万全县"},{"id":602,"pid":590,"name":"桥东区"},{"id":603,"pid":590,"name":"尚义县"},{"id":604,"pid":590,"name":"康保县"},{"id":605,"pid":590,"name":"蔚县"},{"id":606,"pid":590,"name":"桥西区"},{"id":607,"pid":590,"name":"下花园区"},{"id":608,"pid":552,"name":"承德市"},{"id":609,"pid":608,"name":"隆化县"},{"id":610,"pid":608,"name":"双桥区"},{"id":611,"pid":608,"name":"双滦区"},{"id":612,"pid":608,"name":"宽城满族自治县"},{"id":613,"pid":608,"name":"鹰手营子矿区"},{"id":614,"pid":608,"name":"兴隆县"},{"id":615,"pid":608,"name":"平泉县"},{"id":616,"pid":608,"name":"承德县"},{"id":617,"pid":608,"name":"围场满族蒙古族自治县"},{"id":618,"pid":608,"name":"丰宁满族自治县"},{"id":619,"pid":608,"name":"滦平县"},{"id":620,"pid":552,"name":"沧州市"},{"id":621,"pid":620,"name":"黄骅市"},{"id":622,"pid":620,"name":"海兴县"},{"id":623,"pid":620,"name":"吴桥县"},{"id":624,"pid":620,"name":"河间市"},{"id":625,"pid":620,"name":"肃宁县"},{"id":626,"pid":620,"name":"南皮县"},{"id":627,"pid":620,"name":"孟村回族自治县"},{"id":628,"pid":620,"name":"新华区"},{"id":629,"pid":620,"name":"沧县"},{"id":630,"pid":620,"name":"任丘市"},{"id":631,"pid":620,"name":"盐山县"},{"id":632,"pid":620,"name":"泊头市"},{"id":633,"pid":620,"name":"东光县"},{"id":634,"pid":620,"name":"运河区"},{"id":635,"pid":620,"name":"青县"},{"id":636,"pid":620,"name":"献县"},{"id":637,"pid":552,"name":"邯郸市"},{"id":638,"pid":637,"name":"大名县"},{"id":639,"pid":637,"name":"武安市"},{"id":640,"pid":637,"name":"永年县"},{"id":641,"pid":637,"name":"魏县"},{"id":642,"pid":637,"name":"广平县"},{"id":643,"pid":637,"name":"曲周县"},{"id":644,"pid":637,"name":"邯郸县"},{"id":645,"pid":637,"name":"丛台区"},{"id":646,"pid":637,"name":"复兴区"},{"id":647,"pid":637,"name":"肥乡县"},{"id":648,"pid":637,"name":"磁县"},{"id":649,"pid":637,"name":"峰峰矿区"},{"id":650,"pid":637,"name":"邯山区"},{"id":651,"pid":637,"name":"临漳县"},{"id":652,"pid":637,"name":"涉县"},{"id":653,"pid":637,"name":"鸡泽县"},{"id":654,"pid":637,"name":"成安县"},{"id":655,"pid":637,"name":"馆陶县"},{"id":656,"pid":637,"name":"邱县"},{"id":657,"pid":552,"name":"秦皇岛市"},{"id":658,"pid":657,"name":"青龙满族自治县"},{"id":659,"pid":657,"name":"卢龙县"},{"id":660,"pid":657,"name":"山海关区"},{"id":661,"pid":657,"name":"北戴河区"},{"id":662,"pid":657,"name":"海港区"},{"id":663,"pid":657,"name":"抚宁区"},{"id":664,"pid":657,"name":"昌黎县"},{"id":665,"pid":552,"name":"石家庄市"},{"id":666,"pid":665,"name":"晋州市"},{"id":667,"pid":665,"name":"灵寿县"},{"id":668,"pid":665,"name":"新乐市"},{"id":669,"pid":665,"name":"长安区"},{"id":670,"pid":665,"name":"藁城区"},{"id":671,"pid":665,"name":"裕华区"},{"id":672,"pid":665,"name":"元氏县"},{"id":673,"pid":665,"name":"平山县"},{"id":674,"pid":665,"name":"鹿泉区"},{"id":675,"pid":665,"name":"行唐县"},{"id":676,"pid":665,"name":"高邑县"},{"id":677,"pid":665,"name":"井陉县"},{"id":678,"pid":665,"name":"新华区"},{"id":679,"pid":665,"name":"井陉矿区"},{"id":680,"pid":665,"name":"无极县"},{"id":681,"pid":665,"name":"正定县"},{"id":682,"pid":665,"name":"赞皇县"},{"id":683,"pid":665,"name":"桥西区"},{"id":684,"pid":665,"name":"栾城区"},{"id":685,"pid":665,"name":"深泽县"},{"id":686,"pid":665,"name":"辛集市"},{"id":687,"pid":665,"name":"赵县"},{"id":688,"pid":552,"name":"唐山市"},{"id":689,"pid":688,"name":"曹妃甸区"},{"id":690,"pid":688,"name":"滦南县"},{"id":691,"pid":688,"name":"遵化市"},{"id":692,"pid":688,"name":"路北区"},{"id":693,"pid":688,"name":"路南区"},{"id":694,"pid":688,"name":"古冶区"},{"id":695,"pid":688,"name":"乐亭县"},{"id":696,"pid":688,"name":"迁西县"},{"id":697,"pid":688,"name":"滦县"},{"id":698,"pid":688,"name":"开平区"},{"id":699,"pid":688,"name":"丰润区"},{"id":700,"pid":688,"name":"玉田县"},{"id":701,"pid":688,"name":"丰南区"},{"id":702,"pid":688,"name":"迁安市"},{"id":703,"pid":552,"name":"廊坊市"},{"id":704,"pid":703,"name":"固安县"},{"id":705,"pid":703,"name":"永清县"},{"id":706,"pid":703,"name":"大城县"},{"id":707,"pid":703,"name":"广阳区"},{"id":708,"pid":703,"name":"文安县"},{"id":709,"pid":703,"name":"安次区"},{"id":710,"pid":703,"name":"三河市"},{"id":711,"pid":703,"name":"大厂回族自治县"},{"id":712,"pid":703,"name":"香河县"},{"id":713,"pid":703,"name":"霸州市"},{"id":714,"pid":552,"name":"邢台市"},{"id":715,"pid":714,"name":"柏乡县"},{"id":716,"pid":714,"name":"临西县"},{"id":717,"pid":714,"name":"南和县"},{"id":718,"pid":714,"name":"广宗县"},{"id":719,"pid":714,"name":"南宫市"},{"id":720,"pid":714,"name":"沙河市"},{"id":721,"pid":714,"name":"任县"},{"id":722,"pid":714,"name":"宁晋县"},{"id":723,"pid":714,"name":"桥东区"},{"id":724,"pid":714,"name":"临城县"},{"id":725,"pid":714,"name":"威县"},{"id":726,"pid":714,"name":"内丘县"},{"id":727,"pid":714,"name":"新河县"},{"id":728,"pid":714,"name":"桥西区"},{"id":729,"pid":714,"name":"邢台县"},{"id":730,"pid":714,"name":"清河县"},{"id":731,"pid":714,"name":"巨鹿县"},{"id":732,"pid":714,"name":"平乡县"},{"id":733,"pid":714,"name":"隆尧县"},{"id":734,"pid":1,"name":"河南"},{"id":735,"pid":734,"name":"周口市"},{"id":736,"pid":735,"name":"郸城县"},{"id":737,"pid":735,"name":"淮阳县"},{"id":738,"pid":735,"name":"太康县"},{"id":739,"pid":735,"name":"扶沟县"},{"id":740,"pid":735,"name":"鹿邑县"},{"id":741,"pid":735,"name":"项城市"},{"id":742,"pid":735,"name":"商水县"},{"id":743,"pid":735,"name":"川汇区"},{"id":744,"pid":735,"name":"西华县"},{"id":745,"pid":735,"name":"沈丘县"},{"id":746,"pid":734,"name":"平顶山市"},{"id":747,"pid":746,"name":"石龙区"},{"id":748,"pid":746,"name":"郏县"},{"id":749,"pid":746,"name":"汝州市"},{"id":750,"pid":746,"name":"叶县"},{"id":751,"pid":746,"name":"新华区"},{"id":752,"pid":746,"name":"舞钢市"},{"id":753,"pid":746,"name":"鲁山县"},{"id":754,"pid":746,"name":"湛河区"},{"id":755,"pid":746,"name":"卫东区"},{"id":756,"pid":746,"name":"宝丰县"},{"id":757,"pid":734,"name":"洛阳市"},{"id":758,"pid":757,"name":"汝阳县"},{"id":759,"pid":757,"name":"宜阳县"},{"id":760,"pid":757,"name":"偃师市"},{"id":761,"pid":757,"name":"老城区"},{"id":762,"pid":757,"name":"涧西区"},{"id":763,"pid":757,"name":"新安县"},{"id":764,"pid":757,"name":"洛龙区"},{"id":765,"pid":757,"name":"栾川县"},{"id":766,"pid":757,"name":"瀍河回族区"},{"id":767,"pid":757,"name":"伊川县"},{"id":768,"pid":757,"name":"西工区"},{"id":769,"pid":757,"name":"孟津县"},{"id":770,"pid":757,"name":"嵩县"},{"id":771,"pid":757,"name":"洛宁县"},{"id":772,"pid":757,"name":"吉利区"},{"id":773,"pid":734,"name":"济源市"},{"id":774,"pid":773,"name":"沁园街道"},{"id":775,"pid":773,"name":"克井镇"},{"id":776,"pid":773,"name":"坡头镇"},{"id":777,"pid":773,"name":"轵城镇"},{"id":778,"pid":773,"name":"北海街道"},{"id":779,"pid":773,"name":"承留镇"},{"id":780,"pid":773,"name":"梨林镇"},{"id":781,"pid":773,"name":"天坛街道"},{"id":782,"pid":773,"name":"思礼镇"},{"id":783,"pid":773,"name":"玉泉街道"},{"id":784,"pid":773,"name":"五龙口镇"},{"id":785,"pid":773,"name":"下冶镇"},{"id":786,"pid":773,"name":"邵原镇"},{"id":787,"pid":773,"name":"济水街道"},{"id":788,"pid":773,"name":"王屋镇"},{"id":789,"pid":773,"name":"大峪镇"},{"id":790,"pid":734,"name":"濮阳市"},{"id":791,"pid":790,"name":"清丰县"},{"id":792,"pid":790,"name":"华龙区"},{"id":793,"pid":790,"name":"南乐县"},{"id":794,"pid":790,"name":"台前县"},{"id":795,"pid":790,"name":"范县"},{"id":796,"pid":790,"name":"濮阳县"},{"id":797,"pid":734,"name":"南阳市"},{"id":798,"pid":797,"name":"淅川县"},{"id":799,"pid":797,"name":"方城县"},{"id":800,"pid":797,"name":"卧龙区"},{"id":801,"pid":797,"name":"宛城区"},{"id":802,"pid":797,"name":"南召县"},{"id":803,"pid":797,"name":"新野县"},{"id":804,"pid":797,"name":"镇平县"},{"id":805,"pid":797,"name":"唐河县"},{"id":806,"pid":797,"name":"西峡县"},{"id":807,"pid":797,"name":"桐柏县"},{"id":808,"pid":797,"name":"社旗县"},{"id":809,"pid":797,"name":"内乡县"},{"id":810,"pid":797,"name":"邓州市"},{"id":811,"pid":734,"name":"信阳市"},{"id":812,"pid":811,"name":"新县"},{"id":813,"pid":811,"name":"浉河区"},{"id":814,"pid":811,"name":"平桥区"},{"id":815,"pid":811,"name":"潢川县"},{"id":816,"pid":811,"name":"光山县"},{"id":817,"pid":811,"name":"息县"},{"id":818,"pid":811,"name":"商城县"},{"id":819,"pid":811,"name":"罗山县"},{"id":820,"pid":811,"name":"淮滨县"},{"id":821,"pid":811,"name":"固始县"},{"id":822,"pid":734,"name":"漯河市"},{"id":823,"pid":822,"name":"舞阳县"},{"id":824,"pid":822,"name":"郾城区"},{"id":825,"pid":822,"name":"召陵区"},{"id":826,"pid":822,"name":"临颍县"},{"id":827,"pid":822,"name":"源汇区"},{"id":828,"pid":734,"name":"开封市"},{"id":829,"pid":828,"name":"鼓楼区"},{"id":830,"pid":828,"name":"龙亭区"},{"id":831,"pid":828,"name":"顺河回族区"},{"id":832,"pid":828,"name":"禹王台区"},{"id":833,"pid":828,"name":"杞县"},{"id":834,"pid":828,"name":"兰考县"},{"id":835,"pid":828,"name":"通许县"},{"id":836,"pid":828,"name":"尉氏县"},{"id":837,"pid":828,"name":"祥符区"},{"id":838,"pid":734,"name":"安阳市"},{"id":839,"pid":838,"name":"殷都区"},{"id":840,"pid":838,"name":"滑县"},{"id":841,"pid":838,"name":"内黄县"},{"id":842,"pid":838,"name":"汤阴县"},{"id":843,"pid":838,"name":"龙安区"},{"id":844,"pid":838,"name":"文峰区"},{"id":845,"pid":838,"name":"林州市"},{"id":846,"pid":838,"name":"北关区"},{"id":847,"pid":838,"name":"安阳县"},{"id":848,"pid":734,"name":"驻马店市"},{"id":849,"pid":848,"name":"新蔡县"},{"id":850,"pid":848,"name":"泌阳县"},{"id":851,"pid":848,"name":"确山县"},{"id":852,"pid":848,"name":"西平县"},{"id":853,"pid":848,"name":"汝南县"},{"id":854,"pid":848,"name":"驿城区"},{"id":855,"pid":848,"name":"遂平县"},{"id":856,"pid":848,"name":"正阳县"},{"id":857,"pid":848,"name":"上蔡县"},{"id":858,"pid":848,"name":"平舆县"},{"id":859,"pid":734,"name":"新乡市"},{"id":860,"pid":859,"name":"延津县"},{"id":861,"pid":859,"name":"获嘉县"},{"id":862,"pid":859,"name":"凤泉区"},{"id":863,"pid":859,"name":"原阳县"},{"id":864,"pid":859,"name":"长垣县"},{"id":865,"pid":859,"name":"辉县市"},{"id":866,"pid":859,"name":"新乡县"},{"id":867,"pid":859,"name":"卫滨区"},{"id":868,"pid":859,"name":"封丘县"},{"id":869,"pid":859,"name":"牧野区"},{"id":870,"pid":859,"name":"红旗区"},{"id":871,"pid":859,"name":"卫辉市"},{"id":872,"pid":734,"name":"三门峡市"},{"id":873,"pid":872,"name":"陕州区"},{"id":874,"pid":872,"name":"湖滨区"},{"id":875,"pid":872,"name":"卢氏县"},{"id":876,"pid":872,"name":"义马市"},{"id":877,"pid":872,"name":"渑池县"},{"id":878,"pid":872,"name":"灵宝市"},{"id":879,"pid":734,"name":"许昌市"},{"id":880,"pid":879,"name":"许昌县"},{"id":881,"pid":879,"name":"魏都区"},{"id":882,"pid":879,"name":"长葛市"},{"id":883,"pid":879,"name":"禹州市"},{"id":884,"pid":879,"name":"襄城县"},{"id":885,"pid":879,"name":"鄢陵县"},{"id":886,"pid":734,"name":"鹤壁市"},{"id":887,"pid":886,"name":"淇滨区"},{"id":888,"pid":886,"name":"鹤山区"},{"id":889,"pid":886,"name":"淇县"},{"id":890,"pid":886,"name":"山城区"},{"id":891,"pid":886,"name":"浚县"},{"id":892,"pid":734,"name":"商丘市"},{"id":893,"pid":892,"name":"宁陵县"},{"id":894,"pid":892,"name":"睢县"},{"id":895,"pid":892,"name":"柘城县"},{"id":896,"pid":892,"name":"睢阳区"},{"id":897,"pid":892,"name":"虞城县"},{"id":898,"pid":892,"name":"梁园区"},{"id":899,"pid":892,"name":"永城市"},{"id":900,"pid":892,"name":"夏邑县"},{"id":901,"pid":892,"name":"民权县"},{"id":902,"pid":734,"name":"郑州市"},{"id":903,"pid":902,"name":"二七区"},{"id":904,"pid":902,"name":"登封市"},{"id":905,"pid":902,"name":"惠济区"},{"id":906,"pid":902,"name":"新密市"},{"id":907,"pid":902,"name":"中原区"},{"id":908,"pid":902,"name":"金水区"},{"id":909,"pid":902,"name":"管城回族区"},{"id":910,"pid":902,"name":"上街区"},{"id":911,"pid":902,"name":"巩义市"},{"id":912,"pid":902,"name":"荥阳市"},{"id":913,"pid":902,"name":"新郑市"},{"id":914,"pid":902,"name":"中牟县"},{"id":915,"pid":734,"name":"焦作市"},{"id":916,"pid":915,"name":"孟州市"},{"id":917,"pid":915,"name":"武陟县"},{"id":918,"pid":915,"name":"山阳区"},{"id":919,"pid":915,"name":"马村区"},{"id":920,"pid":915,"name":"沁阳市"},{"id":921,"pid":915,"name":"中站区"},{"id":922,"pid":915,"name":"温县"},{"id":923,"pid":915,"name":"解放区"},{"id":924,"pid":915,"name":"修武县"},{"id":925,"pid":915,"name":"博爱县"},{"id":926,"pid":1,"name":"重庆"},{"id":927,"pid":926,"name":"重庆市"},{"id":928,"pid":927,"name":"合川区"},{"id":929,"pid":927,"name":"江北区"},{"id":930,"pid":927,"name":"綦江区"},{"id":931,"pid":927,"name":"云阳县"},{"id":932,"pid":927,"name":"渝北区"},{"id":933,"pid":927,"name":"铜梁区"},{"id":934,"pid":927,"name":"南川区"},{"id":935,"pid":927,"name":"璧山区"},{"id":936,"pid":927,"name":"潼南区"},{"id":937,"pid":927,"name":"万州区"},{"id":938,"pid":927,"name":"九龙坡区"},{"id":939,"pid":927,"name":"永川区"},{"id":940,"pid":927,"name":"忠县"},{"id":941,"pid":927,"name":"奉节县"},{"id":942,"pid":927,"name":"巴南区"},{"id":943,"pid":927,"name":"南岸区"},{"id":944,"pid":927,"name":"沙坪坝区"},{"id":945,"pid":927,"name":"城口县"},{"id":946,"pid":927,"name":"彭水苗族土家族自治县"},{"id":947,"pid":927,"name":"涪陵区"},{"id":948,"pid":927,"name":"丰都县"},{"id":949,"pid":927,"name":"长寿区"},{"id":950,"pid":927,"name":"荣昌区"},{"id":951,"pid":927,"name":"开州区"},{"id":952,"pid":927,"name":"渝中区"},{"id":953,"pid":927,"name":"大足区"},{"id":954,"pid":927,"name":"黔江区"},{"id":955,"pid":927,"name":"巫溪县"},{"id":956,"pid":927,"name":"酉阳土家族苗族自治县"},{"id":957,"pid":927,"name":"江津区"},{"id":958,"pid":927,"name":"北碚区"},{"id":959,"pid":927,"name":"秀山土家族苗族自治县"},{"id":960,"pid":927,"name":"巫山县"},{"id":961,"pid":927,"name":"梁平县"},{"id":962,"pid":927,"name":"武隆县"},{"id":963,"pid":927,"name":"石柱土家族自治县"},{"id":964,"pid":927,"name":"垫江县"},{"id":965,"pid":927,"name":"大渡口区"},{"id":966,"pid":1,"name":"湖北"},{"id":967,"pid":966,"name":"黄冈市"},{"id":968,"pid":967,"name":"麻城市"},{"id":969,"pid":967,"name":"浠水县"},{"id":970,"pid":967,"name":"武穴市"},{"id":971,"pid":967,"name":"英山县"},{"id":972,"pid":967,"name":"罗田县"},{"id":973,"pid":967,"name":"团风县"},{"id":974,"pid":967,"name":"蕲春县"},{"id":975,"pid":967,"name":"红安县"},{"id":976,"pid":967,"name":"黄梅县"},{"id":977,"pid":967,"name":"黄州区"},{"id":978,"pid":966,"name":"天门市"},{"id":979,"pid":978,"name":"彭市镇"},{"id":980,"pid":978,"name":"多祥镇"},{"id":981,"pid":978,"name":"胡市镇"},{"id":982,"pid":978,"name":"皂市镇"},{"id":983,"pid":978,"name":"九真镇"},{"id":984,"pid":978,"name":"岳口镇"},{"id":985,"pid":978,"name":"小板镇"},{"id":986,"pid":978,"name":"净潭乡"},{"id":987,"pid":978,"name":"汪场镇"},{"id":988,"pid":978,"name":"杨林街道"},{"id":989,"pid":978,"name":"渔薪镇"},{"id":990,"pid":978,"name":"黄潭镇"},{"id":991,"pid":978,"name":"横林镇"},{"id":992,"pid":978,"name":"卢市镇"},{"id":993,"pid":978,"name":"蒋场镇"},{"id":994,"pid":978,"name":"马湾镇"},{"id":995,"pid":978,"name":"拖市镇"},{"id":996,"pid":978,"name":"其他"},{"id":997,"pid":978,"name":"张港镇"},{"id":998,"pid":978,"name":"干驿镇"},{"id":999,"pid":978,"name":"竟陵街道"},{"id":1000,"pid":978,"name":"候口街道"},{"id":1001,"pid":978,"name":"麻洋镇"},{"id":1002,"pid":978,"name":"石河镇"},{"id":1003,"pid":978,"name":"多宝镇"},{"id":1004,"pid":978,"name":"佛子山镇"},{"id":1005,"pid":966,"name":"孝感市"},{"id":1006,"pid":1005,"name":"孝南区"},{"id":1007,"pid":1005,"name":"孝昌县"},{"id":1008,"pid":1005,"name":"应城市"},{"id":1009,"pid":1005,"name":"云梦县"},{"id":1010,"pid":1005,"name":"汉川市"},{"id":1011,"pid":1005,"name":"大悟县"},{"id":1012,"pid":1005,"name":"安陆市"},{"id":1013,"pid":966,"name":"恩施土家族苗族自治州"},{"id":1014,"pid":1013,"name":"咸丰县"},{"id":1015,"pid":1013,"name":"建始县"},{"id":1016,"pid":1013,"name":"恩施市"},{"id":1017,"pid":1013,"name":"宣恩县"},{"id":1018,"pid":1013,"name":"巴东县"},{"id":1019,"pid":1013,"name":"鹤峰县"},{"id":1020,"pid":1013,"name":"利川市"},{"id":1021,"pid":1013,"name":"来凤县"},{"id":1022,"pid":966,"name":"襄阳市"},{"id":1023,"pid":1022,"name":"谷城县"},{"id":1024,"pid":1022,"name":"宜城市"},{"id":1025,"pid":1022,"name":"保康县"},{"id":1026,"pid":1022,"name":"老河口市"},{"id":1027,"pid":1022,"name":"枣阳市"},{"id":1028,"pid":1022,"name":"南漳县"},{"id":1029,"pid":1022,"name":"襄城区"},{"id":1030,"pid":1022,"name":"襄州区"},{"id":1031,"pid":1022,"name":"樊城区"},{"id":1032,"pid":966,"name":"神农架林区"},{"id":1033,"pid":1032,"name":"新华镇"},{"id":1034,"pid":1032,"name":"下谷坪土家族乡"},{"id":1035,"pid":1032,"name":"宋洛乡"},{"id":1036,"pid":1032,"name":"阳日镇"},{"id":1037,"pid":1032,"name":"木鱼镇"},{"id":1038,"pid":1032,"name":"松柏镇"},{"id":1039,"pid":1032,"name":"红坪镇"},{"id":1040,"pid":1032,"name":"九湖镇"},{"id":1041,"pid":966,"name":"鄂州市"},{"id":1042,"pid":1041,"name":"鄂城区"},{"id":1043,"pid":1041,"name":"梁子湖区"},{"id":1044,"pid":1041,"name":"华容区"},{"id":1045,"pid":966,"name":"仙桃市"},{"id":1046,"pid":1045,"name":"胡场镇"},{"id":1047,"pid":1045,"name":"沙嘴街道"},{"id":1048,"pid":1045,"name":"干河街道"},{"id":1049,"pid":1045,"name":"杨林尾镇"},{"id":1050,"pid":1045,"name":"陈场镇"},{"id":1051,"pid":1045,"name":"其他"},{"id":1052,"pid":1045,"name":"彭场镇"},{"id":1053,"pid":1045,"name":"郭河镇"},{"id":1054,"pid":1045,"name":"三伏潭镇"},{"id":1055,"pid":1045,"name":"沙湖镇"},{"id":1056,"pid":1045,"name":"沔城回族镇"},{"id":1057,"pid":1045,"name":"毛嘴镇"},{"id":1058,"pid":1045,"name":"长倘口镇"},{"id":1059,"pid":1045,"name":"郑场镇"},{"id":1060,"pid":1045,"name":"龙华山街道"},{"id":1061,"pid":1045,"name":"张沟镇"},{"id":1062,"pid":1045,"name":"剅河镇"},{"id":1063,"pid":1045,"name":"工业园区"},{"id":1064,"pid":1045,"name":"西流河镇"},{"id":1065,"pid":1045,"name":"海口镇"},{"id":1066,"pid":966,"name":"十堰市"},{"id":1067,"pid":1066,"name":"丹江口市"},{"id":1068,"pid":1066,"name":"竹溪县"},{"id":1069,"pid":1066,"name":"郧西县"},{"id":1070,"pid":1066,"name":"茅箭区"},{"id":1071,"pid":1066,"name":"郧阳区"},{"id":1072,"pid":1066,"name":"房县"},{"id":1073,"pid":1066,"name":"张湾区"},{"id":1074,"pid":1066,"name":"竹山县"},{"id":1075,"pid":966,"name":"咸宁市"},{"id":1076,"pid":1075,"name":"咸安区"},{"id":1077,"pid":1075,"name":"通山县"},{"id":1078,"pid":1075,"name":"赤壁市"},{"id":1079,"pid":1075,"name":"嘉鱼县"},{"id":1080,"pid":1075,"name":"通城县"},{"id":1081,"pid":1075,"name":"崇阳县"},{"id":1082,"pid":966,"name":"潜江市"},{"id":1083,"pid":1082,"name":"张金镇"},{"id":1084,"pid":1082,"name":"王场镇"},{"id":1085,"pid":1082,"name":"杨市街道"},{"id":1086,"pid":1082,"name":"高场街道"},{"id":1087,"pid":1082,"name":"竹根滩镇"},{"id":1088,"pid":1082,"name":"高石碑镇"},{"id":1089,"pid":1082,"name":"泰丰街道"},{"id":1090,"pid":1082,"name":"龙湾镇"},{"id":1091,"pid":1082,"name":"浩口镇"},{"id":1092,"pid":1082,"name":"管理区"},{"id":1093,"pid":1082,"name":"广华街道"},{"id":1094,"pid":1082,"name":"泽口街道"},{"id":1095,"pid":1082,"name":"老新镇"},{"id":1096,"pid":1082,"name":"积玉口镇"},{"id":1097,"pid":1082,"name":"江汉石油管理局"},{"id":1098,"pid":1082,"name":"熊口镇"},{"id":1099,"pid":1082,"name":"周矶街道"},{"id":1100,"pid":1082,"name":"渔洋镇"},{"id":1101,"pid":1082,"name":"园林街道"},{"id":1102,"pid":966,"name":"黄石市"},{"id":1103,"pid":1102,"name":"黄石港区"},{"id":1104,"pid":1102,"name":"阳新县"},{"id":1105,"pid":1102,"name":"铁山区"},{"id":1106,"pid":1102,"name":"下陆区"},{"id":1107,"pid":1102,"name":"大冶市"},{"id":1108,"pid":1102,"name":"西塞山区"},{"id":1109,"pid":966,"name":"荆州市"},{"id":1110,"pid":1109,"name":"江陵县"},{"id":1111,"pid":1109,"name":"洪湖市"},{"id":1112,"pid":1109,"name":"沙市区"},{"id":1113,"pid":1109,"name":"松滋市"},{"id":1114,"pid":1109,"name":"荆州区"},{"id":1115,"pid":1109,"name":"石首市"},{"id":1116,"pid":1109,"name":"公安县"},{"id":1117,"pid":1109,"name":"监利县"},{"id":1118,"pid":966,"name":"随州市"},{"id":1119,"pid":1118,"name":"随县"},{"id":1120,"pid":1118,"name":"广水市"},{"id":1121,"pid":1118,"name":"曾都区"},{"id":1122,"pid":966,"name":"宜昌市"},{"id":1123,"pid":1122,"name":"长阳土家族自治县"},{"id":1124,"pid":1122,"name":"宜都市"},{"id":1125,"pid":1122,"name":"点军区"},{"id":1126,"pid":1122,"name":"猇亭区"},{"id":1127,"pid":1122,"name":"秭归县"},{"id":1128,"pid":1122,"name":"五峰土家族自治县"},{"id":1129,"pid":1122,"name":"西陵区"},{"id":1130,"pid":1122,"name":"枝江市"},{"id":1131,"pid":1122,"name":"远安县"},{"id":1132,"pid":1122,"name":"当阳市"},{"id":1133,"pid":1122,"name":"夷陵区"},{"id":1134,"pid":1122,"name":"伍家岗区"},{"id":1135,"pid":1122,"name":"兴山县"},{"id":1136,"pid":966,"name":"武汉市"},{"id":1137,"pid":1136,"name":"蔡甸区"},{"id":1138,"pid":1136,"name":"江岸区"},{"id":1139,"pid":1136,"name":"武昌区"},{"id":1140,"pid":1136,"name":"江夏区"},{"id":1141,"pid":1136,"name":"汉南区"},{"id":1142,"pid":1136,"name":"新洲区"},{"id":1143,"pid":1136,"name":"江汉区"},{"id":1144,"pid":1136,"name":"东西湖区"},{"id":1145,"pid":1136,"name":"洪山区"},{"id":1146,"pid":1136,"name":"青山区"},{"id":1147,"pid":1136,"name":"汉阳区"},{"id":1148,"pid":1136,"name":"黄陂区"},{"id":1149,"pid":1136,"name":"硚口区"},{"id":1150,"pid":966,"name":"荆门市"},{"id":1151,"pid":1150,"name":"钟祥市"},{"id":1152,"pid":1150,"name":"沙洋县"},{"id":1153,"pid":1150,"name":"京山县"},{"id":1154,"pid":1150,"name":"东宝区"},{"id":1155,"pid":1150,"name":"掇刀区"},{"id":1156,"pid":1,"name":"湖南"},{"id":1157,"pid":1156,"name":"湘潭市"},{"id":1158,"pid":1157,"name":"湘乡市"},{"id":1159,"pid":1157,"name":"韶山市"},{"id":1160,"pid":1157,"name":"岳塘区"},{"id":1161,"pid":1157,"name":"湘潭县"},{"id":1162,"pid":1157,"name":"雨湖区"},{"id":1163,"pid":1156,"name":"衡阳市"},{"id":1164,"pid":1163,"name":"耒阳市"},{"id":1165,"pid":1163,"name":"衡南县"},{"id":1166,"pid":1163,"name":"常宁市"},{"id":1167,"pid":1163,"name":"衡山县"},{"id":1168,"pid":1163,"name":"祁东县"},{"id":1169,"pid":1163,"name":"蒸湘区"},{"id":1170,"pid":1163,"name":"雁峰区"},{"id":1171,"pid":1163,"name":"南岳区"},{"id":1172,"pid":1163,"name":"珠晖区"},{"id":1173,"pid":1163,"name":"衡东县"},{"id":1174,"pid":1163,"name":"石鼓区"},{"id":1175,"pid":1163,"name":"衡阳县"},{"id":1176,"pid":1156,"name":"张家界市"},{"id":1177,"pid":1176,"name":"桑植县"},{"id":1178,"pid":1176,"name":"永定区"},{"id":1179,"pid":1176,"name":"慈利县"},{"id":1180,"pid":1176,"name":"武陵源区"},{"id":1181,"pid":1156,"name":"益阳市"},{"id":1182,"pid":1181,"name":"安化县"},{"id":1183,"pid":1181,"name":"南县"},{"id":1184,"pid":1181,"name":"桃江县"},{"id":1185,"pid":1181,"name":"赫山区"},{"id":1186,"pid":1181,"name":"沅江市"},{"id":1187,"pid":1181,"name":"资阳区"},{"id":1188,"pid":1156,"name":"岳阳市"},{"id":1189,"pid":1188,"name":"华容县"},{"id":1190,"pid":1188,"name":"岳阳县"},{"id":1191,"pid":1188,"name":"君山区"},{"id":1192,"pid":1188,"name":"湘阴县"},{"id":1193,"pid":1188,"name":"平江县"},{"id":1194,"pid":1188,"name":"云溪区"},{"id":1195,"pid":1188,"name":"汨罗市"},{"id":1196,"pid":1188,"name":"岳阳楼区"},{"id":1197,"pid":1188,"name":"临湘市"},{"id":1198,"pid":1156,"name":"娄底市"},{"id":1199,"pid":1198,"name":"娄星区"},{"id":1200,"pid":1198,"name":"新化县"},{"id":1201,"pid":1198,"name":"冷水江市"},{"id":1202,"pid":1198,"name":"涟源市"},{"id":1203,"pid":1198,"name":"双峰县"},{"id":1204,"pid":1156,"name":"常德市"},{"id":1205,"pid":1204,"name":"津市市"},{"id":1206,"pid":1204,"name":"澧县"},{"id":1207,"pid":1204,"name":"安乡县"},{"id":1208,"pid":1204,"name":"桃源县"},{"id":1209,"pid":1204,"name":"汉寿县"},{"id":1210,"pid":1204,"name":"鼎城区"},{"id":1211,"pid":1204,"name":"武陵区"},{"id":1212,"pid":1204,"name":"石门县"},{"id":1213,"pid":1204,"name":"临澧县"},{"id":1214,"pid":1156,"name":"株洲市"},{"id":1215,"pid":1214,"name":"石峰区"},{"id":1216,"pid":1214,"name":"荷塘区"},{"id":1217,"pid":1214,"name":"炎陵县"},{"id":1218,"pid":1214,"name":"株洲县"},{"id":1219,"pid":1214,"name":"醴陵市"},{"id":1220,"pid":1214,"name":"天元区"},{"id":1221,"pid":1214,"name":"芦淞区"},{"id":1222,"pid":1214,"name":"攸县"},{"id":1223,"pid":1214,"name":"茶陵县"},{"id":1224,"pid":1156,"name":"湘西土家族苗族自治州"},{"id":1225,"pid":1224,"name":"永顺县"},{"id":1226,"pid":1224,"name":"龙山县"},{"id":1227,"pid":1224,"name":"花垣县"},{"id":1228,"pid":1224,"name":"保靖县"},{"id":1229,"pid":1224,"name":"吉首市"},{"id":1230,"pid":1224,"name":"泸溪县"},{"id":1231,"pid":1224,"name":"凤凰县"},{"id":1232,"pid":1224,"name":"古丈县"},{"id":1233,"pid":1156,"name":"郴州市"},{"id":1234,"pid":1233,"name":"永兴县"},{"id":1235,"pid":1233,"name":"苏仙区"},{"id":1236,"pid":1233,"name":"桂东县"},{"id":1237,"pid":1233,"name":"安仁县"},{"id":1238,"pid":1233,"name":"桂阳县"},{"id":1239,"pid":1233,"name":"嘉禾县"},{"id":1240,"pid":1233,"name":"宜章县"},{"id":1241,"pid":1233,"name":"北湖区"},{"id":1242,"pid":1233,"name":"资兴市"},{"id":1243,"pid":1233,"name":"临武县"},{"id":1244,"pid":1233,"name":"汝城县"},{"id":1245,"pid":1156,"name":"邵阳市"},{"id":1246,"pid":1245,"name":"邵阳县"},{"id":1247,"pid":1245,"name":"大祥区"},{"id":1248,"pid":1245,"name":"邵东县"},{"id":1249,"pid":1245,"name":"城步苗族自治县"},{"id":1250,"pid":1245,"name":"绥宁县"},{"id":1251,"pid":1245,"name":"新邵县"},{"id":1252,"pid":1245,"name":"新宁县"},{"id":1253,"pid":1245,"name":"隆回县"},{"id":1254,"pid":1245,"name":"双清区"},{"id":1255,"pid":1245,"name":"武冈市"},{"id":1256,"pid":1245,"name":"洞口县"},{"id":1257,"pid":1245,"name":"北塔区"},{"id":1258,"pid":1156,"name":"长沙市"},{"id":1259,"pid":1258,"name":"芙蓉区"},{"id":1260,"pid":1258,"name":"浏阳市"},{"id":1261,"pid":1258,"name":"岳麓区"},{"id":1262,"pid":1258,"name":"雨花区"},{"id":1263,"pid":1258,"name":"开福区"},{"id":1264,"pid":1258,"name":"望城区"},{"id":1265,"pid":1258,"name":"天心区"},{"id":1266,"pid":1258,"name":"长沙县"},{"id":1267,"pid":1258,"name":"宁乡县"},{"id":1268,"pid":1156,"name":"永州市"},{"id":1269,"pid":1268,"name":"江华瑶族自治县"},{"id":1270,"pid":1268,"name":"零陵区"},{"id":1271,"pid":1268,"name":"东安县"},{"id":1272,"pid":1268,"name":"江永县"},{"id":1273,"pid":1268,"name":"新田县"},{"id":1274,"pid":1268,"name":"祁阳县"},{"id":1275,"pid":1268,"name":"蓝山县"},{"id":1276,"pid":1268,"name":"冷水滩区"},{"id":1277,"pid":1268,"name":"双牌县"},{"id":1278,"pid":1268,"name":"道县"},{"id":1279,"pid":1268,"name":"宁远县"},{"id":1280,"pid":1156,"name":"怀化市"},{"id":1281,"pid":1280,"name":"中方县"},{"id":1282,"pid":1280,"name":"通道侗族自治县"},{"id":1283,"pid":1280,"name":"溆浦县"},{"id":1284,"pid":1280,"name":"沅陵县"},{"id":1285,"pid":1280,"name":"芷江侗族自治县"},{"id":1286,"pid":1280,"name":"新晃侗族自治县"},{"id":1287,"pid":1280,"name":"洪江市"},{"id":1288,"pid":1280,"name":"麻阳苗族自治县"},{"id":1289,"pid":1280,"name":"辰溪县"},{"id":1290,"pid":1280,"name":"靖州苗族侗族自治县"},{"id":1291,"pid":1280,"name":"鹤城区"},{"id":1292,"pid":1280,"name":"会同县"},{"id":1293,"pid":1,"name":"海南"},{"id":1294,"pid":1293,"name":"三沙市"},{"id":1295,"pid":1294,"name":"南沙群岛"},{"id":1296,"pid":1294,"name":"中沙群岛"},{"id":1297,"pid":1294,"name":"西沙群岛"},{"id":1298,"pid":1293,"name":"昌江黎族自治县"},{"id":1299,"pid":1298,"name":"昌化镇"},{"id":1300,"pid":1298,"name":"叉河镇"},{"id":1301,"pid":1298,"name":"海尾镇"},{"id":1302,"pid":1298,"name":"十月田镇"},{"id":1303,"pid":1298,"name":"王下乡"},{"id":1304,"pid":1298,"name":"七叉镇"},{"id":1305,"pid":1298,"name":"石碌镇"},{"id":1306,"pid":1298,"name":"乌烈镇"},{"id":1307,"pid":1293,"name":"临高县"},{"id":1308,"pid":1307,"name":"多文镇"},{"id":1309,"pid":1307,"name":"新盈镇"},{"id":1310,"pid":1307,"name":"博厚镇"},{"id":1311,"pid":1307,"name":"皇桐镇"},{"id":1312,"pid":1307,"name":"调楼镇"},{"id":1313,"pid":1307,"name":"南宝镇"},{"id":1314,"pid":1307,"name":"东英镇"},{"id":1315,"pid":1307,"name":"和舍镇"},{"id":1316,"pid":1307,"name":"临城镇"},{"id":1317,"pid":1307,"name":"波莲镇"},{"id":1318,"pid":1293,"name":"琼中黎族苗族自治县"},{"id":1319,"pid":1318,"name":"中平镇"},{"id":1320,"pid":1318,"name":"吊罗山乡"},{"id":1321,"pid":1318,"name":"湾岭镇"},{"id":1322,"pid":1318,"name":"上安乡"},{"id":1323,"pid":1318,"name":"黎母山镇"},{"id":1324,"pid":1318,"name":"红毛镇"},{"id":1325,"pid":1318,"name":"长征镇"},{"id":1326,"pid":1318,"name":"什运乡"},{"id":1327,"pid":1318,"name":"和平镇"},{"id":1328,"pid":1318,"name":"营根镇"},{"id":1329,"pid":1293,"name":"屯昌县"},{"id":1330,"pid":1329,"name":"坡心镇"},{"id":1331,"pid":1329,"name":"乌坡镇"},{"id":1332,"pid":1329,"name":"枫木镇"},{"id":1333,"pid":1329,"name":"南吕镇"},{"id":1334,"pid":1329,"name":"新兴镇"},{"id":1335,"pid":1329,"name":"西昌镇"},{"id":1336,"pid":1329,"name":"屯城镇"},{"id":1337,"pid":1329,"name":"南坤镇"},{"id":1338,"pid":1293,"name":"琼海市"},{"id":1339,"pid":1338,"name":"嘉积镇"},{"id":1340,"pid":1338,"name":"石壁镇"},{"id":1341,"pid":1338,"name":"会山镇"},{"id":1342,"pid":1338,"name":"中原镇"},{"id":1343,"pid":1338,"name":"龙江镇"},{"id":1344,"pid":1338,"name":"万泉镇"},{"id":1345,"pid":1338,"name":"博鳌镇"},{"id":1346,"pid":1338,"name":"潭门镇"},{"id":1347,"pid":1338,"name":"塔洋镇"},{"id":1348,"pid":1338,"name":"长坡镇"},{"id":1349,"pid":1338,"name":"阳江镇"},{"id":1350,"pid":1338,"name":"大路镇"},{"id":1351,"pid":1293,"name":"陵水黎族自治县"},{"id":1352,"pid":1351,"name":"三才镇"},{"id":1353,"pid":1351,"name":"本号镇"},{"id":1354,"pid":1351,"name":"光坡镇"},{"id":1355,"pid":1351,"name":"黎安镇"},{"id":1356,"pid":1351,"name":"椰林镇"},{"id":1357,"pid":1351,"name":"文罗镇"},{"id":1358,"pid":1351,"name":"群英乡"},{"id":1359,"pid":1351,"name":"新村镇"},{"id":1360,"pid":1351,"name":"英州镇"},{"id":1361,"pid":1351,"name":"隆广镇"},{"id":1362,"pid":1351,"name":"提蒙乡"},{"id":1363,"pid":1293,"name":"澄迈县"},{"id":1364,"pid":1363,"name":"老城镇"},{"id":1365,"pid":1363,"name":"福山镇"},{"id":1366,"pid":1363,"name":"仁兴镇"},{"id":1367,"pid":1363,"name":"加乐镇"},{"id":1368,"pid":1363,"name":"金江镇"},{"id":1369,"pid":1363,"name":"瑞溪镇"},{"id":1370,"pid":1363,"name":"文儒镇"},{"id":1371,"pid":1363,"name":"桥头镇"},{"id":1372,"pid":1363,"name":"永发镇"},{"id":1373,"pid":1363,"name":"中兴镇"},{"id":1374,"pid":1293,"name":"洋浦经济开发区"},{"id":1375,"pid":1374,"name":"三都区"},{"id":1376,"pid":1374,"name":"干冲区"},{"id":1377,"pid":1374,"name":"新英湾区"},{"id":1378,"pid":1293,"name":"海口市"},{"id":1379,"pid":1378,"name":"秀英区"},{"id":1380,"pid":1378,"name":"美兰区"},{"id":1381,"pid":1378,"name":"龙华区"},{"id":1382,"pid":1378,"name":"琼山区"},{"id":1383,"pid":1293,"name":"五指山市"},{"id":1384,"pid":1383,"name":"番阳镇"},{"id":1385,"pid":1383,"name":"通什镇"},{"id":1386,"pid":1383,"name":"水满乡"},{"id":1387,"pid":1383,"name":"南圣镇"},{"id":1388,"pid":1383,"name":"毛阳镇"},{"id":1389,"pid":1383,"name":"畅好乡"},{"id":1390,"pid":1383,"name":"毛道乡"},{"id":1391,"pid":1293,"name":"定安县"},{"id":1392,"pid":1391,"name":"定城镇"},{"id":1393,"pid":1391,"name":"黄竹镇"},{"id":1394,"pid":1391,"name":"雷鸣镇"},{"id":1395,"pid":1391,"name":"龙门镇"},{"id":1396,"pid":1391,"name":"新竹镇"},{"id":1397,"pid":1391,"name":"岭口镇"},{"id":1398,"pid":1391,"name":"龙河镇"},{"id":1399,"pid":1391,"name":"富文镇"},{"id":1400,"pid":1391,"name":"翰林镇"},{"id":1401,"pid":1391,"name":"龙湖镇"},{"id":1402,"pid":1293,"name":"保亭黎族苗族自治县"},{"id":1403,"pid":1402,"name":"保城镇"},{"id":1404,"pid":1402,"name":"新政镇"},{"id":1405,"pid":1402,"name":"什玲镇"},{"id":1406,"pid":1402,"name":"加茂镇"},{"id":1407,"pid":1402,"name":"南林乡"},{"id":1408,"pid":1402,"name":"六弓乡"},{"id":1409,"pid":1402,"name":"三道镇"},{"id":1410,"pid":1402,"name":"响水镇"},{"id":1411,"pid":1402,"name":"毛感乡"},{"id":1412,"pid":1293,"name":"儋州市"},{"id":1413,"pid":1412,"name":"光村镇"},{"id":1414,"pid":1412,"name":"东成镇"},{"id":1415,"pid":1412,"name":"和庆镇"},{"id":1416,"pid":1412,"name":"三都镇"},{"id":1417,"pid":1412,"name":"大成镇"},{"id":1418,"pid":1412,"name":"王五镇"},{"id":1419,"pid":1412,"name":"那大镇"},{"id":1420,"pid":1412,"name":"白马井镇"},{"id":1421,"pid":1412,"name":"南丰镇"},{"id":1422,"pid":1412,"name":"海头镇"},{"id":1423,"pid":1412,"name":"雅星镇"},{"id":1424,"pid":1412,"name":"排浦镇"},{"id":1425,"pid":1412,"name":"新州镇"},{"id":1426,"pid":1412,"name":"峨蔓镇"},{"id":1427,"pid":1412,"name":"兰洋镇"},{"id":1428,"pid":1412,"name":"中和镇"},{"id":1429,"pid":1412,"name":"木棠镇"},{"id":1430,"pid":1293,"name":"文昌市"},{"id":1431,"pid":1430,"name":"龙楼镇"},{"id":1432,"pid":1430,"name":"蓬莱镇"},{"id":1433,"pid":1430,"name":"东路镇"},{"id":1434,"pid":1430,"name":"抱罗镇"},{"id":1435,"pid":1430,"name":"锦山镇"},{"id":1436,"pid":1430,"name":"文城镇"},{"id":1437,"pid":1430,"name":"冯坡镇"},{"id":1438,"pid":1430,"name":"潭牛镇"},{"id":1439,"pid":1430,"name":"重兴镇"},{"id":1440,"pid":1430,"name":"昌洒镇"},{"id":1441,"pid":1430,"name":"铺前镇"},{"id":1442,"pid":1430,"name":"东郊镇"},{"id":1443,"pid":1430,"name":"公坡镇"},{"id":1444,"pid":1430,"name":"会文镇"},{"id":1445,"pid":1430,"name":"东阁镇"},{"id":1446,"pid":1430,"name":"翁田镇"},{"id":1447,"pid":1430,"name":"文教镇"},{"id":1448,"pid":1293,"name":"东方市"},{"id":1449,"pid":1448,"name":"板桥镇"},{"id":1450,"pid":1448,"name":"东河镇"},{"id":1451,"pid":1448,"name":"大田镇"},{"id":1452,"pid":1448,"name":"三家镇"},{"id":1453,"pid":1448,"name":"天安乡"},{"id":1454,"pid":1448,"name":"八所镇"},{"id":1455,"pid":1448,"name":"四更镇"},{"id":1456,"pid":1448,"name":"感城镇"},{"id":1457,"pid":1448,"name":"新龙镇"},{"id":1458,"pid":1448,"name":"江边乡"},{"id":1459,"pid":1293,"name":"万宁市"},{"id":1460,"pid":1459,"name":"万城镇"},{"id":1461,"pid":1459,"name":"三更罗镇"},{"id":1462,"pid":1459,"name":"龙滚镇"},{"id":1463,"pid":1459,"name":"大茂镇"},{"id":1464,"pid":1459,"name":"东澳镇"},{"id":1465,"pid":1459,"name":"和乐镇"},{"id":1466,"pid":1459,"name":"北大镇"},{"id":1467,"pid":1459,"name":"山根镇"},{"id":1468,"pid":1459,"name":"后安镇"},{"id":1469,"pid":1459,"name":"长丰镇"},{"id":1470,"pid":1459,"name":"礼纪镇"},{"id":1471,"pid":1459,"name":"南桥镇"},{"id":1472,"pid":1293,"name":"白沙黎族自治县"},{"id":1473,"pid":1472,"name":"牙叉镇"},{"id":1474,"pid":1472,"name":"七坊镇"},{"id":1475,"pid":1472,"name":"金波乡"},{"id":1476,"pid":1472,"name":"青松乡"},{"id":1477,"pid":1472,"name":"荣邦乡"},{"id":1478,"pid":1472,"name":"阜龙乡"},{"id":1479,"pid":1472,"name":"细水乡"},{"id":1480,"pid":1472,"name":"南开乡"},{"id":1481,"pid":1472,"name":"打安镇"},{"id":1482,"pid":1472,"name":"邦溪镇"},{"id":1483,"pid":1472,"name":"元门乡"},{"id":1484,"pid":1293,"name":"乐东黎族自治县"},{"id":1485,"pid":1484,"name":"千家镇"},{"id":1486,"pid":1484,"name":"佛罗镇"},{"id":1487,"pid":1484,"name":"万冲镇"},{"id":1488,"pid":1484,"name":"莺歌海镇"},{"id":1489,"pid":1484,"name":"抱由镇"},{"id":1490,"pid":1484,"name":"九所镇"},{"id":1491,"pid":1484,"name":"尖峰镇"},{"id":1492,"pid":1484,"name":"黄流镇"},{"id":1493,"pid":1484,"name":"利国镇"},{"id":1494,"pid":1484,"name":"志仲镇"},{"id":1495,"pid":1484,"name":"大安镇"},{"id":1496,"pid":1293,"name":"三亚市"},{"id":1497,"pid":1496,"name":"海棠区"},{"id":1498,"pid":1496,"name":"天涯区"},{"id":1499,"pid":1496,"name":"崖州区"},{"id":1500,"pid":1496,"name":"吉阳区"},{"id":1501,"pid":1,"name":"江西"},{"id":1502,"pid":1501,"name":"上饶市"},{"id":1503,"pid":1502,"name":"弋阳县"},{"id":1504,"pid":1502,"name":"万年县"},{"id":1505,"pid":1502,"name":"横峰县"},{"id":1506,"pid":1502,"name":"余干县"},{"id":1507,"pid":1502,"name":"德兴市"},{"id":1508,"pid":1502,"name":"上饶县"},{"id":1509,"pid":1502,"name":"广丰区"},{"id":1510,"pid":1502,"name":"婺源县"},{"id":1511,"pid":1502,"name":"信州区"},{"id":1512,"pid":1502,"name":"玉山县"},{"id":1513,"pid":1502,"name":"铅山县"},{"id":1514,"pid":1502,"name":"鄱阳县"},{"id":1515,"pid":1501,"name":"九江市"},{"id":1516,"pid":1515,"name":"修水县"},{"id":1517,"pid":1515,"name":"星子县"},{"id":1518,"pid":1515,"name":"永修县"},{"id":1519,"pid":1515,"name":"九江县"},{"id":1520,"pid":1515,"name":"瑞昌市"},{"id":1521,"pid":1515,"name":"浔阳区"},{"id":1522,"pid":1515,"name":"庐山区"},{"id":1523,"pid":1515,"name":"武宁县"},{"id":1524,"pid":1515,"name":"湖口县"},{"id":1525,"pid":1515,"name":"都昌县"},{"id":1526,"pid":1515,"name":"彭泽县"},{"id":1527,"pid":1515,"name":"共青城市"},{"id":1528,"pid":1515,"name":"德安县"},{"id":1529,"pid":1501,"name":"抚州市"},{"id":1530,"pid":1529,"name":"临川区"},{"id":1531,"pid":1529,"name":"崇仁县"},{"id":1532,"pid":1529,"name":"南丰县"},{"id":1533,"pid":1529,"name":"东乡县"},{"id":1534,"pid":1529,"name":"乐安县"},{"id":1535,"pid":1529,"name":"金溪县"},{"id":1536,"pid":1529,"name":"资溪县"},{"id":1537,"pid":1529,"name":"南城县"},{"id":1538,"pid":1529,"name":"宜黄县"},{"id":1539,"pid":1529,"name":"广昌县"},{"id":1540,"pid":1529,"name":"黎川县"},{"id":1541,"pid":1501,"name":"吉安市"},{"id":1542,"pid":1541,"name":"泰和县"},{"id":1543,"pid":1541,"name":"吉州区"},{"id":1544,"pid":1541,"name":"永新县"},{"id":1545,"pid":1541,"name":"永丰县"},{"id":1546,"pid":1541,"name":"峡江县"},{"id":1547,"pid":1541,"name":"遂川县"},{"id":1548,"pid":1541,"name":"万安县"},{"id":1549,"pid":1541,"name":"青原区"},{"id":1550,"pid":1541,"name":"井冈山市"},{"id":1551,"pid":1541,"name":"新干县"},{"id":1552,"pid":1541,"name":"吉安县"},{"id":1553,"pid":1541,"name":"吉水县"},{"id":1554,"pid":1541,"name":"安福县"},{"id":1555,"pid":1501,"name":"鹰潭市"},{"id":1556,"pid":1555,"name":"贵溪市"},{"id":1557,"pid":1555,"name":"月湖区"},{"id":1558,"pid":1555,"name":"余江县"},{"id":1559,"pid":1501,"name":"萍乡市"},{"id":1560,"pid":1559,"name":"上栗县"},{"id":1561,"pid":1559,"name":"芦溪县"},{"id":1562,"pid":1559,"name":"安源区"},{"id":1563,"pid":1559,"name":"湘东区"},{"id":1564,"pid":1559,"name":"莲花县"},{"id":1565,"pid":1501,"name":"南昌市"},{"id":1566,"pid":1565,"name":"青山湖区"},{"id":1567,"pid":1565,"name":"东湖区"},{"id":1568,"pid":1565,"name":"西湖区"},{"id":1569,"pid":1565,"name":"青云谱区"},{"id":1570,"pid":1565,"name":"新建区"},{"id":1571,"pid":1565,"name":"进贤县"},{"id":1572,"pid":1565,"name":"湾里区"},{"id":1573,"pid":1565,"name":"安义县"},{"id":1574,"pid":1565,"name":"南昌县"},{"id":1575,"pid":1501,"name":"景德镇市"},{"id":1576,"pid":1575,"name":"珠山区"},{"id":1577,"pid":1575,"name":"昌江区"},{"id":1578,"pid":1575,"name":"浮梁县"},{"id":1579,"pid":1575,"name":"乐平市"},{"id":1580,"pid":1501,"name":"赣州市"},{"id":1581,"pid":1580,"name":"龙南县"},{"id":1582,"pid":1580,"name":"定南县"},{"id":1583,"pid":1580,"name":"上犹县"},{"id":1584,"pid":1580,"name":"信丰县"},{"id":1585,"pid":1580,"name":"安远县"},{"id":1586,"pid":1580,"name":"章贡区"},{"id":1587,"pid":1580,"name":"于都县"},{"id":1588,"pid":1580,"name":"瑞金市"},{"id":1589,"pid":1580,"name":"石城县"},{"id":1590,"pid":1580,"name":"宁都县"},{"id":1591,"pid":1580,"name":"兴国县"},{"id":1592,"pid":1580,"name":"全南县"},{"id":1593,"pid":1580,"name":"赣县"},{"id":1594,"pid":1580,"name":"寻乌县"},{"id":1595,"pid":1580,"name":"大余县"},{"id":1596,"pid":1580,"name":"会昌县"},{"id":1597,"pid":1580,"name":"崇义县"},{"id":1598,"pid":1580,"name":"南康区"},{"id":1599,"pid":1501,"name":"宜春市"},{"id":1600,"pid":1599,"name":"袁州区"},{"id":1601,"pid":1599,"name":"高安市"},{"id":1602,"pid":1599,"name":"奉新县"},{"id":1603,"pid":1599,"name":"丰城市"},{"id":1604,"pid":1599,"name":"上高县"},{"id":1605,"pid":1599,"name":"宜丰县"},{"id":1606,"pid":1599,"name":"铜鼓县"},{"id":1607,"pid":1599,"name":"樟树市"},{"id":1608,"pid":1599,"name":"万载县"},{"id":1609,"pid":1599,"name":"靖安县"},{"id":1610,"pid":1501,"name":"新余市"},{"id":1611,"pid":1610,"name":"分宜县"},{"id":1612,"pid":1610,"name":"渝水区"},{"id":1613,"pid":1,"name":"黑龙江"},{"id":1614,"pid":1613,"name":"黑河市"},{"id":1615,"pid":1614,"name":"五大连池市"},{"id":1616,"pid":1614,"name":"北安市"},{"id":1617,"pid":1614,"name":"孙吴县"},{"id":1618,"pid":1614,"name":"逊克县"},{"id":1619,"pid":1614,"name":"嫩江县"},{"id":1620,"pid":1614,"name":"爱辉区"},{"id":1621,"pid":1613,"name":"七台河市"},{"id":1622,"pid":1621,"name":"新兴区"},{"id":1623,"pid":1621,"name":"茄子河区"},{"id":1624,"pid":1621,"name":"勃利县"},{"id":1625,"pid":1621,"name":"桃山区"},{"id":1626,"pid":1613,"name":"齐齐哈尔市"},{"id":1627,"pid":1626,"name":"甘南县"},{"id":1628,"pid":1626,"name":"依安县"},{"id":1629,"pid":1626,"name":"克山县"},{"id":1630,"pid":1626,"name":"建华区"},{"id":1631,"pid":1626,"name":"泰来县"},{"id":1632,"pid":1626,"name":"铁锋区"},{"id":1633,"pid":1626,"name":"梅里斯达斡尔族区"},{"id":1634,"pid":1626,"name":"拜泉县"},{"id":1635,"pid":1626,"name":"克东县"},{"id":1636,"pid":1626,"name":"富拉尔基区"},{"id":1637,"pid":1626,"name":"昂昂溪区"},{"id":1638,"pid":1626,"name":"讷河市"},{"id":1639,"pid":1626,"name":"龙江县"},{"id":1640,"pid":1626,"name":"龙沙区"},{"id":1641,"pid":1626,"name":"碾子山区"},{"id":1642,"pid":1626,"name":"富裕县"},{"id":1643,"pid":1613,"name":"佳木斯市"},{"id":1644,"pid":1643,"name":"东风区"},{"id":1645,"pid":1643,"name":"郊区"},{"id":1646,"pid":1643,"name":"富锦市"},{"id":1647,"pid":1643,"name":"汤原县"},{"id":1648,"pid":1643,"name":"向阳区"},{"id":1649,"pid":1643,"name":"同江市"},{"id":1650,"pid":1643,"name":"前进区"},{"id":1651,"pid":1643,"name":"桦川县"},{"id":1652,"pid":1643,"name":"桦南县"},{"id":1653,"pid":1643,"name":"抚远县"},{"id":1654,"pid":1613,"name":"双鸭山市"},{"id":1655,"pid":1654,"name":"宝清县"},{"id":1656,"pid":1654,"name":"宝山区"},{"id":1657,"pid":1654,"name":"集贤县"},{"id":1658,"pid":1654,"name":"尖山区"},{"id":1659,"pid":1654,"name":"四方台区"},{"id":1660,"pid":1654,"name":"友谊县"},{"id":1661,"pid":1654,"name":"岭东区"},{"id":1662,"pid":1654,"name":"饶河县"},{"id":1663,"pid":1613,"name":"鸡西市"},{"id":1664,"pid":1663,"name":"鸡冠区"},{"id":1665,"pid":1663,"name":"密山市"},{"id":1666,"pid":1663,"name":"梨树区"},{"id":1667,"pid":1663,"name":"城子河区"},{"id":1668,"pid":1663,"name":"滴道区"},{"id":1669,"pid":1663,"name":"麻山区"},{"id":1670,"pid":1663,"name":"虎林市"},{"id":1671,"pid":1663,"name":"恒山区"},{"id":1672,"pid":1663,"name":"鸡东县"},{"id":1673,"pid":1613,"name":"牡丹江市"},{"id":1674,"pid":1673,"name":"爱民区"},{"id":1675,"pid":1673,"name":"绥芬河市"},{"id":1676,"pid":1673,"name":"海林市"},{"id":1677,"pid":1673,"name":"宁安市"},{"id":1678,"pid":1673,"name":"林口县"},{"id":1679,"pid":1673,"name":"东安区"},{"id":1680,"pid":1673,"name":"东宁市"},{"id":1681,"pid":1673,"name":"阳明区"},{"id":1682,"pid":1673,"name":"西安区"},{"id":1683,"pid":1673,"name":"穆棱市"},{"id":1684,"pid":1613,"name":"大兴安岭地区"},{"id":1685,"pid":1684,"name":"漠河县"},{"id":1686,"pid":1684,"name":"塔河县"},{"id":1687,"pid":1684,"name":"呼玛县"},{"id":1688,"pid":1613,"name":"鹤岗市"},{"id":1689,"pid":1688,"name":"兴山区"},{"id":1690,"pid":1688,"name":"南山区"},{"id":1691,"pid":1688,"name":"东山区"},{"id":1692,"pid":1688,"name":"向阳区"},{"id":1693,"pid":1688,"name":"绥滨县"},{"id":1694,"pid":1688,"name":"兴安区"},{"id":1695,"pid":1688,"name":"工农区"},{"id":1696,"pid":1688,"name":"萝北县"},{"id":1697,"pid":1613,"name":"伊春市"},{"id":1698,"pid":1697,"name":"乌伊岭区"},{"id":1699,"pid":1697,"name":"金山屯区"},{"id":1700,"pid":1697,"name":"上甘岭区"},{"id":1701,"pid":1697,"name":"新青区"},{"id":1702,"pid":1697,"name":"伊春区"},{"id":1703,"pid":1697,"name":"汤旺河区"},{"id":1704,"pid":1697,"name":"友好区"},{"id":1705,"pid":1697,"name":"嘉荫县"},{"id":1706,"pid":1697,"name":"乌马河区"},{"id":1707,"pid":1697,"name":"铁力市"},{"id":1708,"pid":1697,"name":"美溪区"},{"id":1709,"pid":1697,"name":"西林区"},{"id":1710,"pid":1697,"name":"红星区"},{"id":1711,"pid":1697,"name":"南岔区"},{"id":1712,"pid":1697,"name":"五营区"},{"id":1713,"pid":1697,"name":"翠峦区"},{"id":1714,"pid":1697,"name":"带岭区"},{"id":1715,"pid":1613,"name":"哈尔滨市"},{"id":1716,"pid":1715,"name":"平房区"},{"id":1717,"pid":1715,"name":"尚志市"},{"id":1718,"pid":1715,"name":"呼兰区"},{"id":1719,"pid":1715,"name":"巴彦县"},{"id":1720,"pid":1715,"name":"香坊区"},{"id":1721,"pid":1715,"name":"宾县"},{"id":1722,"pid":1715,"name":"五常市"},{"id":1723,"pid":1715,"name":"通河县"},{"id":1724,"pid":1715,"name":"道里区"},{"id":1725,"pid":1715,"name":"松北区"},{"id":1726,"pid":1715,"name":"阿城区"},{"id":1727,"pid":1715,"name":"依兰县"},{"id":1728,"pid":1715,"name":"延寿县"},{"id":1729,"pid":1715,"name":"木兰县"},{"id":1730,"pid":1715,"name":"双城区"},{"id":1731,"pid":1715,"name":"南岗区"},{"id":1732,"pid":1715,"name":"方正县"},{"id":1733,"pid":1715,"name":"道外区"},{"id":1734,"pid":1613,"name":"绥化市"},{"id":1735,"pid":1734,"name":"肇东市"},{"id":1736,"pid":1734,"name":"望奎县"},{"id":1737,"pid":1734,"name":"兰西县"},{"id":1738,"pid":1734,"name":"庆安县"},{"id":1739,"pid":1734,"name":"安达市"},{"id":1740,"pid":1734,"name":"明水县"},{"id":1741,"pid":1734,"name":"海伦市"},{"id":1742,"pid":1734,"name":"绥棱县"},{"id":1743,"pid":1734,"name":"青冈县"},{"id":1744,"pid":1734,"name":"北林区"},{"id":1745,"pid":1613,"name":"大庆市"},{"id":1746,"pid":1745,"name":"让胡路区"},{"id":1747,"pid":1745,"name":"红岗区"},{"id":1748,"pid":1745,"name":"肇州县"},{"id":1749,"pid":1745,"name":"肇源县"},{"id":1750,"pid":1745,"name":"杜尔伯特蒙古族自治县"},{"id":1751,"pid":1745,"name":"大同区"},{"id":1752,"pid":1745,"name":"林甸县"},{"id":1753,"pid":1745,"name":"龙凤区"},{"id":1754,"pid":1745,"name":"萨尔图区"},{"id":1755,"pid":1,"name":"天津"},{"id":1756,"pid":1755,"name":"天津市"},{"id":1757,"pid":1756,"name":"蓟州区"},{"id":1758,"pid":1756,"name":"河西区"},{"id":1759,"pid":1756,"name":"滨海新区"},{"id":1760,"pid":1756,"name":"北辰区"},{"id":1761,"pid":1756,"name":"津南区"},{"id":1762,"pid":1756,"name":"宁河区"},{"id":1763,"pid":1756,"name":"河东区"},{"id":1764,"pid":1756,"name":"西青区"},{"id":1765,"pid":1756,"name":"河北区"},{"id":1766,"pid":1756,"name":"南开区"},{"id":1767,"pid":1756,"name":"东丽区"},{"id":1768,"pid":1756,"name":"静海区"},{"id":1769,"pid":1756,"name":"和平区"},{"id":1770,"pid":1756,"name":"武清区"},{"id":1771,"pid":1756,"name":"宝坻区"},{"id":1772,"pid":1756,"name":"红桥区"},{"id":1773,"pid":1,"name":"贵州"},{"id":1774,"pid":1773,"name":"贵阳市"},{"id":1775,"pid":1774,"name":"白云区"},{"id":1776,"pid":1774,"name":"云岩区"},{"id":1777,"pid":1774,"name":"乌当区"},{"id":1778,"pid":1774,"name":"观山湖区"},{"id":1779,"pid":1774,"name":"南明区"},{"id":1780,"pid":1774,"name":"花溪区"},{"id":1781,"pid":1774,"name":"息烽县"},{"id":1782,"pid":1774,"name":"开阳县"},{"id":1783,"pid":1774,"name":"修文县"},{"id":1784,"pid":1774,"name":"清镇市"},{"id":1785,"pid":1773,"name":"毕节市"},{"id":1786,"pid":1785,"name":"黔西县"},{"id":1787,"pid":1785,"name":"大方县"},{"id":1788,"pid":1785,"name":"金沙县"},{"id":1789,"pid":1785,"name":"赫章县"},{"id":1790,"pid":1785,"name":"织金县"},{"id":1791,"pid":1785,"name":"纳雍县"},{"id":1792,"pid":1785,"name":"七星关区"},{"id":1793,"pid":1785,"name":"威宁彝族回族苗族自治县"},{"id":1794,"pid":1773,"name":"铜仁市"},{"id":1795,"pid":1794,"name":"碧江区"},{"id":1796,"pid":1794,"name":"万山区"},{"id":1797,"pid":1794,"name":"德江县"},{"id":1798,"pid":1794,"name":"印江土家族苗族自治县"},{"id":1799,"pid":1794,"name":"沿河土家族自治县"},{"id":1800,"pid":1794,"name":"石阡县"},{"id":1801,"pid":1794,"name":"思南县"},{"id":1802,"pid":1794,"name":"玉屏侗族自治县"},{"id":1803,"pid":1794,"name":"江口县"},{"id":1804,"pid":1794,"name":"松桃苗族自治县"},{"id":1805,"pid":1773,"name":"六盘水市"},{"id":1806,"pid":1805,"name":"钟山区"},{"id":1807,"pid":1805,"name":"水城县"},{"id":1808,"pid":1805,"name":"六枝特区"},{"id":1809,"pid":1805,"name":"盘县"},{"id":1810,"pid":1773,"name":"遵义市"},{"id":1811,"pid":1810,"name":"遵义县"},{"id":1812,"pid":1810,"name":"凤冈县"},{"id":1813,"pid":1810,"name":"汇川区"},{"id":1814,"pid":1810,"name":"余庆县"},{"id":1815,"pid":1810,"name":"正安县"},{"id":1816,"pid":1810,"name":"桐梓县"},{"id":1817,"pid":1810,"name":"务川仡佬族苗族自治县"},{"id":1818,"pid":1810,"name":"仁怀市"},{"id":1819,"pid":1810,"name":"赤水市"},{"id":1820,"pid":1810,"name":"红花岗区"},{"id":1821,"pid":1810,"name":"习水县"},{"id":1822,"pid":1810,"name":"道真仡佬族苗族自治县"},{"id":1823,"pid":1810,"name":"湄潭县"},{"id":1824,"pid":1810,"name":"绥阳县"},{"id":1825,"pid":1773,"name":"黔西南布依族苗族自治州"},{"id":1826,"pid":1825,"name":"安龙县"},{"id":1827,"pid":1825,"name":"兴义市"},{"id":1828,"pid":1825,"name":"贞丰县"},{"id":1829,"pid":1825,"name":"册亨县"},{"id":1830,"pid":1825,"name":"兴仁县"},{"id":1831,"pid":1825,"name":"晴隆县"},{"id":1832,"pid":1825,"name":"普安县"},{"id":1833,"pid":1825,"name":"望谟县"},{"id":1834,"pid":1773,"name":"安顺市"},{"id":1835,"pid":1834,"name":"关岭布依族苗族自治县"},{"id":1836,"pid":1834,"name":"紫云苗族布依族自治县"},{"id":1837,"pid":1834,"name":"普定县"},{"id":1838,"pid":1834,"name":"镇宁布依族苗族自治县"},{"id":1839,"pid":1834,"name":"西秀区"},{"id":1840,"pid":1834,"name":"平坝区"},{"id":1841,"pid":1773,"name":"黔东南苗族侗族自治州"},{"id":1842,"pid":1841,"name":"岑巩县"},{"id":1843,"pid":1841,"name":"凯里市"},{"id":1844,"pid":1841,"name":"丹寨县"},{"id":1845,"pid":1841,"name":"黎平县"},{"id":1846,"pid":1841,"name":"三穗县"},{"id":1847,"pid":1841,"name":"雷山县"},{"id":1848,"pid":1841,"name":"镇远县"},{"id":1849,"pid":1841,"name":"榕江县"},{"id":1850,"pid":1841,"name":"天柱县"},{"id":1851,"pid":1841,"name":"锦屏县"},{"id":1852,"pid":1841,"name":"黄平县"},{"id":1853,"pid":1841,"name":"台江县"},{"id":1854,"pid":1841,"name":"麻江县"},{"id":1855,"pid":1841,"name":"从江县"},{"id":1856,"pid":1841,"name":"剑河县"},{"id":1857,"pid":1841,"name":"施秉县"},{"id":1858,"pid":1773,"name":"黔南布依族苗族自治州"},{"id":1859,"pid":1858,"name":"独山县"},{"id":1860,"pid":1858,"name":"惠水县"},{"id":1861,"pid":1858,"name":"罗甸县"},{"id":1862,"pid":1858,"name":"三都水族自治县"},{"id":1863,"pid":1858,"name":"都匀市"},{"id":1864,"pid":1858,"name":"龙里县"},{"id":1865,"pid":1858,"name":"瓮安县"},{"id":1866,"pid":1858,"name":"长顺县"},{"id":1867,"pid":1858,"name":"贵定县"},{"id":1868,"pid":1858,"name":"平塘县"},{"id":1869,"pid":1858,"name":"荔波县"},{"id":1870,"pid":1858,"name":"福泉市"},{"id":1871,"pid":1,"name":"陕西"},{"id":1872,"pid":1871,"name":"延安市"},{"id":1873,"pid":1872,"name":"延长县"},{"id":1874,"pid":1872,"name":"宝塔区"},{"id":1875,"pid":1872,"name":"延川县"},{"id":1876,"pid":1872,"name":"安塞县"},{"id":1877,"pid":1872,"name":"黄陵县"},{"id":1878,"pid":1872,"name":"甘泉县"},{"id":1879,"pid":1872,"name":"志丹县"},{"id":1880,"pid":1872,"name":"黄龙县"},{"id":1881,"pid":1872,"name":"吴起县"},{"id":1882,"pid":1872,"name":"富县"},{"id":1883,"pid":1872,"name":"洛川县"},{"id":1884,"pid":1872,"name":"子长县"},{"id":1885,"pid":1872,"name":"宜川县"},{"id":1886,"pid":1871,"name":"渭南市"},{"id":1887,"pid":1886,"name":"临渭区"},{"id":1888,"pid":1886,"name":"白水县"},{"id":1889,"pid":1886,"name":"潼关县"},{"id":1890,"pid":1886,"name":"华阴市"},{"id":1891,"pid":1886,"name":"韩城市"},{"id":1892,"pid":1886,"name":"澄城县"},{"id":1893,"pid":1886,"name":"合阳县"},{"id":1894,"pid":1886,"name":"大荔县"},{"id":1895,"pid":1886,"name":"富平县"},{"id":1896,"pid":1886,"name":"华州区"},{"id":1897,"pid":1886,"name":"蒲城县"},{"id":1898,"pid":1871,"name":"商洛市"},{"id":1899,"pid":1898,"name":"洛南县"},{"id":1900,"pid":1898,"name":"山阳县"},{"id":1901,"pid":1898,"name":"商南县"},{"id":1902,"pid":1898,"name":"镇安县"},{"id":1903,"pid":1898,"name":"商州区"},{"id":1904,"pid":1898,"name":"柞水县"},{"id":1905,"pid":1898,"name":"丹凤县"},{"id":1906,"pid":1871,"name":"宝鸡市"},{"id":1907,"pid":1906,"name":"陈仓区"},{"id":1908,"pid":1906,"name":"凤县"},{"id":1909,"pid":1906,"name":"太白县"},{"id":1910,"pid":1906,"name":"扶风县"},{"id":1911,"pid":1906,"name":"渭滨区"},{"id":1912,"pid":1906,"name":"千阳县"},{"id":1913,"pid":1906,"name":"金台区"},{"id":1914,"pid":1906,"name":"麟游县"},{"id":1915,"pid":1906,"name":"岐山县"},{"id":1916,"pid":1906,"name":"眉县"},{"id":1917,"pid":1906,"name":"陇县"},{"id":1918,"pid":1906,"name":"凤翔县"},{"id":1919,"pid":1871,"name":"西安市"},{"id":1920,"pid":1919,"name":"灞桥区"},{"id":1921,"pid":1919,"name":"临潼区"},{"id":1922,"pid":1919,"name":"户县"},{"id":1923,"pid":1919,"name":"碑林区"},{"id":1924,"pid":1919,"name":"雁塔区"},{"id":1925,"pid":1919,"name":"莲湖区"},{"id":1926,"pid":1919,"name":"高陵区"},{"id":1927,"pid":1919,"name":"长安区"},{"id":1928,"pid":1919,"name":"蓝田县"},{"id":1929,"pid":1919,"name":"新城区"},{"id":1930,"pid":1919,"name":"未央区"},{"id":1931,"pid":1919,"name":"周至县"},{"id":1932,"pid":1919,"name":"阎良区"},{"id":1933,"pid":1871,"name":"咸阳市"},{"id":1934,"pid":1933,"name":"泾阳县"},{"id":1935,"pid":1933,"name":"三原县"},{"id":1936,"pid":1933,"name":"礼泉县"},{"id":1937,"pid":1933,"name":"长武县"},{"id":1938,"pid":1933,"name":"乾县"},{"id":1939,"pid":1933,"name":"旬邑县"},{"id":1940,"pid":1933,"name":"渭城区"},{"id":1941,"pid":1933,"name":"秦都区"},{"id":1942,"pid":1933,"name":"彬县"},{"id":1943,"pid":1933,"name":"永寿县"},{"id":1944,"pid":1933,"name":"杨陵区"},{"id":1945,"pid":1933,"name":"淳化县"},{"id":1946,"pid":1933,"name":"武功县"},{"id":1947,"pid":1933,"name":"兴平市"},{"id":1948,"pid":1871,"name":"安康市"},{"id":1949,"pid":1948,"name":"宁陕县"},{"id":1950,"pid":1948,"name":"白河县"},{"id":1951,"pid":1948,"name":"岚皋县"},{"id":1952,"pid":1948,"name":"平利县"},{"id":1953,"pid":1948,"name":"石泉县"},{"id":1954,"pid":1948,"name":"镇坪县"},{"id":1955,"pid":1948,"name":"旬阳县"},{"id":1956,"pid":1948,"name":"汉阴县"},{"id":1957,"pid":1948,"name":"汉滨区"},{"id":1958,"pid":1948,"name":"紫阳县"},{"id":1959,"pid":1871,"name":"榆林市"},{"id":1960,"pid":1959,"name":"府谷县"},{"id":1961,"pid":1959,"name":"神木县"},{"id":1962,"pid":1959,"name":"榆阳区"},{"id":1963,"pid":1959,"name":"米脂县"},{"id":1964,"pid":1959,"name":"靖边县"},{"id":1965,"pid":1959,"name":"绥德县"},{"id":1966,"pid":1959,"name":"佳县"},{"id":1967,"pid":1959,"name":"吴堡县"},{"id":1968,"pid":1959,"name":"清涧县"},{"id":1969,"pid":1959,"name":"横山区"},{"id":1970,"pid":1959,"name":"定边县"},{"id":1971,"pid":1959,"name":"子洲县"},{"id":1972,"pid":1871,"name":"铜川市"},{"id":1973,"pid":1972,"name":"耀州区"},{"id":1974,"pid":1972,"name":"宜君县"},{"id":1975,"pid":1972,"name":"印台区"},{"id":1976,"pid":1972,"name":"王益区"},{"id":1977,"pid":1871,"name":"汉中市"},{"id":1978,"pid":1977,"name":"西乡县"},{"id":1979,"pid":1977,"name":"汉台区"},{"id":1980,"pid":1977,"name":"佛坪县"},{"id":1981,"pid":1977,"name":"宁强县"},{"id":1982,"pid":1977,"name":"城固县"},{"id":1983,"pid":1977,"name":"留坝县"},{"id":1984,"pid":1977,"name":"洋县"},{"id":1985,"pid":1977,"name":"略阳县"},{"id":1986,"pid":1977,"name":"勉县"},{"id":1987,"pid":1977,"name":"镇巴县"},{"id":1988,"pid":1977,"name":"南郑县"},{"id":1989,"pid":1,"name":"新疆"},{"id":1990,"pid":1989,"name":"阿勒泰地区"},{"id":1991,"pid":1990,"name":"哈巴河县"},{"id":1992,"pid":1990,"name":"福海县"},{"id":1993,"pid":1990,"name":"阿勒泰市"},{"id":1994,"pid":1990,"name":"布尔津县"},{"id":1995,"pid":1990,"name":"青河县"},{"id":1996,"pid":1990,"name":"吉木乃县"},{"id":1997,"pid":1990,"name":"富蕴县"},{"id":1998,"pid":1989,"name":"克孜勒苏柯尔克孜自治州"},{"id":1999,"pid":1998,"name":"阿合奇县"},{"id":2000,"pid":1998,"name":"阿克陶县"},{"id":2001,"pid":1998,"name":"乌恰县"},{"id":2002,"pid":1998,"name":"阿图什市"},{"id":2003,"pid":1989,"name":"哈密地区"},{"id":2004,"pid":2003,"name":"伊吾县"},{"id":2005,"pid":2003,"name":"哈密市"},{"id":2006,"pid":2003,"name":"巴里坤哈萨克自治县"},{"id":2007,"pid":1989,"name":"图木舒克市"},{"id":2008,"pid":2007,"name":"图木舒克市"},{"id":2009,"pid":1989,"name":"博尔塔拉蒙古自治州"},{"id":2010,"pid":2009,"name":"温泉县"},{"id":2011,"pid":2009,"name":"精河县"},{"id":2012,"pid":2009,"name":"阿拉山口市"},{"id":2013,"pid":2009,"name":"博乐市"},{"id":2014,"pid":1989,"name":"北屯市"},{"id":2015,"pid":2014,"name":"北屯市"},{"id":2016,"pid":1989,"name":"阿克苏地区"},{"id":2017,"pid":2016,"name":"温宿县"},{"id":2018,"pid":2016,"name":"阿克苏市"},{"id":2019,"pid":2016,"name":"拜城县"},{"id":2020,"pid":2016,"name":"乌什县"},{"id":2021,"pid":2016,"name":"柯坪县"},{"id":2022,"pid":2016,"name":"库车县"},{"id":2023,"pid":2016,"name":"沙雅县"},{"id":2024,"pid":2016,"name":"阿瓦提县"},{"id":2025,"pid":2016,"name":"新和县"},{"id":2026,"pid":1989,"name":"巴音郭楞蒙古自治州"},{"id":2027,"pid":2026,"name":"库尔勒市"},{"id":2028,"pid":2026,"name":"尉犁县"},{"id":2029,"pid":2026,"name":"和静县"},{"id":2030,"pid":2026,"name":"若羌县"},{"id":2031,"pid":2026,"name":"博湖县"},{"id":2032,"pid":2026,"name":"焉耆回族自治县"},{"id":2033,"pid":2026,"name":"轮台县"},{"id":2034,"pid":2026,"name":"且末县"},{"id":2035,"pid":2026,"name":"和硕县"},{"id":2036,"pid":1989,"name":"铁门关市"},{"id":2037,"pid":2036,"name":"铁门关市"},{"id":2038,"pid":1989,"name":"昌吉回族自治州"},{"id":2039,"pid":2038,"name":"吉木萨尔县"},{"id":2040,"pid":2038,"name":"阜康市"},{"id":2041,"pid":2038,"name":"呼图壁县"},{"id":2042,"pid":2038,"name":"木垒哈萨克自治县"},{"id":2043,"pid":2038,"name":"昌吉市"},{"id":2044,"pid":2038,"name":"玛纳斯县"},{"id":2045,"pid":2038,"name":"奇台县"},{"id":2046,"pid":1989,"name":"阿拉尔市"},{"id":2047,"pid":2046,"name":"阿拉尔市"},{"id":2048,"pid":1989,"name":"双河市"},{"id":2049,"pid":2048,"name":"双河市"},{"id":2050,"pid":1989,"name":"乌鲁木齐市"},{"id":2051,"pid":2050,"name":"新市区"},{"id":2052,"pid":2050,"name":"乌鲁木齐县"},{"id":2053,"pid":2050,"name":"头屯河区"},{"id":2054,"pid":2050,"name":"天山区"},{"id":2055,"pid":2050,"name":"达坂城区"},{"id":2056,"pid":2050,"name":"水磨沟区"},{"id":2057,"pid":2050,"name":"沙依巴克区"},{"id":2058,"pid":2050,"name":"米东区"},{"id":2059,"pid":1989,"name":"克拉玛依市"},{"id":2060,"pid":2059,"name":"乌尔禾区"},{"id":2061,"pid":2059,"name":"白碱滩区"},{"id":2062,"pid":2059,"name":"独山子区"},{"id":2063,"pid":2059,"name":"克拉玛依区"},{"id":2064,"pid":1989,"name":"石河子市"},{"id":2065,"pid":2064,"name":"北泉镇"},{"id":2066,"pid":2064,"name":"老街街道"},{"id":2067,"pid":2064,"name":"东城街道"},{"id":2068,"pid":2064,"name":"向阳街道"},{"id":2069,"pid":2064,"name":"红山街道"},{"id":2070,"pid":2064,"name":"石河子镇"},{"id":2071,"pid":2064,"name":"新城街道"},{"id":2072,"pid":1989,"name":"吐鲁番市"},{"id":2073,"pid":2072,"name":"鄯善县"},{"id":2074,"pid":2072,"name":"高昌区"},{"id":2075,"pid":2072,"name":"托克逊县"},{"id":2076,"pid":1989,"name":"可克达拉市"},{"id":2077,"pid":2076,"name":"可克达拉市"},{"id":2078,"pid":1989,"name":"喀什地区"},{"id":2079,"pid":2078,"name":"英吉沙县"},{"id":2080,"pid":2078,"name":"疏附县"},{"id":2081,"pid":2078,"name":"叶城县"},{"id":2082,"pid":2078,"name":"伽师县"},{"id":2083,"pid":2078,"name":"巴楚县"},{"id":2084,"pid":2078,"name":"岳普湖县"},{"id":2085,"pid":2078,"name":"麦盖提县"},{"id":2086,"pid":2078,"name":"喀什市"},{"id":2087,"pid":2078,"name":"莎车县"},{"id":2088,"pid":2078,"name":"泽普县"},{"id":2089,"pid":2078,"name":"塔什库尔干塔吉克自治县"},{"id":2090,"pid":2078,"name":"疏勒县"},{"id":2091,"pid":1989,"name":"五家渠市"},{"id":2092,"pid":2091,"name":"五家渠市"},{"id":2093,"pid":1989,"name":"伊犁哈萨克自治州"},{"id":2094,"pid":2093,"name":"巩留县"},{"id":2095,"pid":2093,"name":"昭苏县"},{"id":2096,"pid":2093,"name":"新源县"},{"id":2097,"pid":2093,"name":"尼勒克县"},{"id":2098,"pid":2093,"name":"特克斯县"},{"id":2099,"pid":2093,"name":"霍尔果斯市"},{"id":2100,"pid":2093,"name":"奎屯市"},{"id":2101,"pid":2093,"name":"察布查尔锡伯自治县"},{"id":2102,"pid":2093,"name":"伊宁县"},{"id":2103,"pid":2093,"name":"伊宁市"},{"id":2104,"pid":2093,"name":"霍城县"},{"id":2105,"pid":1989,"name":"和田地区"},{"id":2106,"pid":2105,"name":"和田县"},{"id":2107,"pid":2105,"name":"洛浦县"},{"id":2108,"pid":2105,"name":"和田市"},{"id":2109,"pid":2105,"name":"墨玉县"},{"id":2110,"pid":2105,"name":"皮山县"},{"id":2111,"pid":2105,"name":"于田县"},{"id":2112,"pid":2105,"name":"策勒县"},{"id":2113,"pid":2105,"name":"民丰县"},{"id":2114,"pid":1989,"name":"塔城地区"},{"id":2115,"pid":2114,"name":"额敏县"},{"id":2116,"pid":2114,"name":"托里县"},{"id":2117,"pid":2114,"name":"乌苏市"},{"id":2118,"pid":2114,"name":"裕民县"},{"id":2119,"pid":2114,"name":"塔城市"},{"id":2120,"pid":2114,"name":"和布克赛尔蒙古自治县"},{"id":2121,"pid":2114,"name":"沙湾县"},{"id":2122,"pid":1,"name":"澳门"},{"id":2123,"pid":2122,"name":"澳门半岛"},{"id":2124,"pid":2123,"name":"圣安多尼堂区"},{"id":2125,"pid":2123,"name":"望德堂区"},{"id":2126,"pid":2123,"name":"大堂区"},{"id":2127,"pid":2123,"name":"花地玛堂区"},{"id":2128,"pid":2123,"name":"风顺堂区"},{"id":2129,"pid":2122,"name":"路氹城"},{"id":2130,"pid":2129,"name":"路氹城"},{"id":2131,"pid":2122,"name":"离岛"},{"id":2132,"pid":2131,"name":"嘉模堂区"},{"id":2133,"pid":2131,"name":"圣方济各堂区"},{"id":2134,"pid":1,"name":"江苏"},{"id":2135,"pid":2134,"name":"苏州市"},{"id":2136,"pid":2135,"name":"虎丘区"},{"id":2137,"pid":2135,"name":"太仓市"},{"id":2138,"pid":2135,"name":"吴中区"},{"id":2139,"pid":2135,"name":"常熟市"},{"id":2140,"pid":2135,"name":"吴江区"},{"id":2141,"pid":2135,"name":"张家港市"},{"id":2142,"pid":2135,"name":"姑苏区"},{"id":2143,"pid":2135,"name":"相城区"},{"id":2144,"pid":2135,"name":"昆山市"},{"id":2145,"pid":2134,"name":"徐州市"},{"id":2146,"pid":2145,"name":"贾汪区"},{"id":2147,"pid":2145,"name":"泉山区"},{"id":2148,"pid":2145,"name":"鼓楼区"},{"id":2149,"pid":2145,"name":"丰县"},{"id":2150,"pid":2145,"name":"云龙区"},{"id":2151,"pid":2145,"name":"沛县"},{"id":2152,"pid":2145,"name":"新沂市"},{"id":2153,"pid":2145,"name":"睢宁县"},{"id":2154,"pid":2145,"name":"邳州市"},{"id":2155,"pid":2145,"name":"铜山区"},{"id":2156,"pid":2134,"name":"宿迁市"},{"id":2157,"pid":2156,"name":"沭阳县"},{"id":2158,"pid":2156,"name":"宿豫区"},{"id":2159,"pid":2156,"name":"宿城区"},{"id":2160,"pid":2156,"name":"泗阳县"},{"id":2161,"pid":2156,"name":"泗洪县"},{"id":2162,"pid":2134,"name":"盐城市"},{"id":2163,"pid":2162,"name":"东台市"},{"id":2164,"pid":2162,"name":"建湖县"},{"id":2165,"pid":2162,"name":"盐都区"},{"id":2166,"pid":2162,"name":"响水县"},{"id":2167,"pid":2162,"name":"亭湖区"},{"id":2168,"pid":2162,"name":"阜宁县"},{"id":2169,"pid":2162,"name":"大丰区"},{"id":2170,"pid":2162,"name":"射阳县"},{"id":2171,"pid":2162,"name":"滨海县"},{"id":2172,"pid":2134,"name":"扬州市"},{"id":2173,"pid":2172,"name":"广陵区"},{"id":2174,"pid":2172,"name":"江都区"},{"id":2175,"pid":2172,"name":"高邮市"},{"id":2176,"pid":2172,"name":"宝应县"},{"id":2177,"pid":2172,"name":"邗江区"},{"id":2178,"pid":2172,"name":"仪征市"},{"id":2179,"pid":2134,"name":"南京市"},{"id":2180,"pid":2179,"name":"溧水区"},{"id":2181,"pid":2179,"name":"鼓楼区"},{"id":2182,"pid":2179,"name":"六合区"},{"id":2183,"pid":2179,"name":"秦淮区"},{"id":2184,"pid":2179,"name":"玄武区"},{"id":2185,"pid":2179,"name":"浦口区"},{"id":2186,"pid":2179,"name":"江宁区"},{"id":2187,"pid":2179,"name":"栖霞区"},{"id":2188,"pid":2179,"name":"建邺区"},{"id":2189,"pid":2179,"name":"高淳区"},{"id":2190,"pid":2179,"name":"雨花台区"},{"id":2191,"pid":2134,"name":"淮安市"},{"id":2192,"pid":2191,"name":"涟水县"},{"id":2193,"pid":2191,"name":"清浦区"},{"id":2194,"pid":2191,"name":"清河区"},{"id":2195,"pid":2191,"name":"淮安区"},{"id":2196,"pid":2191,"name":"盱眙县"},{"id":2197,"pid":2191,"name":"淮阴区"},{"id":2198,"pid":2191,"name":"金湖县"},{"id":2199,"pid":2191,"name":"洪泽县"},{"id":2200,"pid":2134,"name":"泰州市"},{"id":2201,"pid":2200,"name":"海陵区"},{"id":2202,"pid":2200,"name":"高港区"},{"id":2203,"pid":2200,"name":"姜堰区"},{"id":2204,"pid":2200,"name":"靖江市"},{"id":2205,"pid":2200,"name":"兴化市"},{"id":2206,"pid":2200,"name":"泰兴市"},{"id":2207,"pid":2134,"name":"常州市"},{"id":2208,"pid":2207,"name":"武进区"},{"id":2209,"pid":2207,"name":"钟楼区"},{"id":2210,"pid":2207,"name":"溧阳市"},{"id":2211,"pid":2207,"name":"天宁区"},{"id":2212,"pid":2207,"name":"新北区"},{"id":2213,"pid":2207,"name":"金坛区"},{"id":2214,"pid":2134,"name":"无锡市"},{"id":2215,"pid":2214,"name":"锡山区"},{"id":2216,"pid":2214,"name":"滨湖区"},{"id":2217,"pid":2214,"name":"江阴市"},{"id":2218,"pid":2214,"name":"梁溪区"},{"id":2219,"pid":2214,"name":"宜兴市"},{"id":2220,"pid":2214,"name":"新吴区"},{"id":2221,"pid":2214,"name":"惠山区"},{"id":2222,"pid":2134,"name":"南通市"},{"id":2223,"pid":2222,"name":"启东市"},{"id":2224,"pid":2222,"name":"港闸区"},{"id":2225,"pid":2222,"name":"如皋市"},{"id":2226,"pid":2222,"name":"海安县"},{"id":2227,"pid":2222,"name":"崇川区"},{"id":2228,"pid":2222,"name":"海门市"},{"id":2229,"pid":2222,"name":"如东县"},{"id":2230,"pid":2222,"name":"通州区"},{"id":2231,"pid":2134,"name":"镇江市"},{"id":2232,"pid":2231,"name":"丹徒区"},{"id":2233,"pid":2231,"name":"丹阳市"},{"id":2234,"pid":2231,"name":"京口区"},{"id":2235,"pid":2231,"name":"润州区"},{"id":2236,"pid":2231,"name":"句容市"},{"id":2237,"pid":2231,"name":"扬中市"},{"id":2238,"pid":2134,"name":"连云港市"},{"id":2239,"pid":2238,"name":"连云区"},{"id":2240,"pid":2238,"name":"海州区"},{"id":2241,"pid":2238,"name":"灌云县"},{"id":2242,"pid":2238,"name":"东海县"},{"id":2243,"pid":2238,"name":"赣榆区"},{"id":2244,"pid":2238,"name":"灌南县"},{"id":2245,"pid":1,"name":"安徽"},{"id":2246,"pid":2245,"name":"马鞍山市"},{"id":2247,"pid":2246,"name":"雨山区"},{"id":2248,"pid":2246,"name":"当涂县"},{"id":2249,"pid":2246,"name":"和县"},{"id":2250,"pid":2246,"name":"博望区"},{"id":2251,"pid":2246,"name":"花山区"},{"id":2252,"pid":2246,"name":"含山县"},{"id":2253,"pid":2245,"name":"亳州市"},{"id":2254,"pid":2253,"name":"谯城区"},{"id":2255,"pid":2253,"name":"涡阳县"},{"id":2256,"pid":2253,"name":"蒙城县"},{"id":2257,"pid":2253,"name":"利辛县"},{"id":2258,"pid":2245,"name":"安庆市"},{"id":2259,"pid":2258,"name":"迎江区"},{"id":2260,"pid":2258,"name":"宜秀区"},{"id":2261,"pid":2258,"name":"大观区"},{"id":2262,"pid":2258,"name":"宿松县"},{"id":2263,"pid":2258,"name":"桐城市"},{"id":2264,"pid":2258,"name":"潜山县"},{"id":2265,"pid":2258,"name":"望江县"},{"id":2266,"pid":2258,"name":"怀宁县"},{"id":2267,"pid":2258,"name":"太湖县"},{"id":2268,"pid":2258,"name":"岳西县"},{"id":2269,"pid":2245,"name":"池州市"},{"id":2270,"pid":2269,"name":"贵池区"},{"id":2271,"pid":2269,"name":"青阳县"},{"id":2272,"pid":2269,"name":"东至县"},{"id":2273,"pid":2269,"name":"石台县"},{"id":2274,"pid":2245,"name":"宿州市"},{"id":2275,"pid":2274,"name":"砀山县"},{"id":2276,"pid":2274,"name":"泗县"},{"id":2277,"pid":2274,"name":"萧县"},{"id":2278,"pid":2274,"name":"灵璧县"},{"id":2279,"pid":2274,"name":"埇桥区"},{"id":2280,"pid":2245,"name":"铜陵市"},{"id":2281,"pid":2280,"name":"郊区"},{"id":2282,"pid":2280,"name":"铜官区"},{"id":2283,"pid":2280,"name":"义安区"},{"id":2284,"pid":2280,"name":"枞阳县"},{"id":2285,"pid":2245,"name":"蚌埠市"},{"id":2286,"pid":2285,"name":"蚌山区"},{"id":2287,"pid":2285,"name":"五河县"},{"id":2288,"pid":2285,"name":"淮上区"},{"id":2289,"pid":2285,"name":"怀远县"},{"id":2290,"pid":2285,"name":"龙子湖区"},{"id":2291,"pid":2285,"name":"固镇县"},{"id":2292,"pid":2285,"name":"禹会区"},{"id":2293,"pid":2245,"name":"黄山市"},{"id":2294,"pid":2293,"name":"祁门县"},{"id":2295,"pid":2293,"name":"黄山区"},{"id":2296,"pid":2293,"name":"黟县"},{"id":2297,"pid":2293,"name":"屯溪区"},{"id":2298,"pid":2293,"name":"徽州区"},{"id":2299,"pid":2293,"name":"休宁县"},{"id":2300,"pid":2293,"name":"歙县"},{"id":2301,"pid":2245,"name":"阜阳市"},{"id":2302,"pid":2301,"name":"颍州区"},{"id":2303,"pid":2301,"name":"界首市"},{"id":2304,"pid":2301,"name":"颍泉区"},{"id":2305,"pid":2301,"name":"太和县"},{"id":2306,"pid":2301,"name":"颍上县"},{"id":2307,"pid":2301,"name":"临泉县"},{"id":2308,"pid":2301,"name":"阜南县"},{"id":2309,"pid":2301,"name":"颍东区"},{"id":2310,"pid":2245,"name":"合肥市"},{"id":2311,"pid":2310,"name":"庐江县"},{"id":2312,"pid":2310,"name":"巢湖市"},{"id":2313,"pid":2310,"name":"庐阳区"},{"id":2314,"pid":2310,"name":"长丰县"},{"id":2315,"pid":2310,"name":"肥东县"},{"id":2316,"pid":2310,"name":"肥西县"},{"id":2317,"pid":2310,"name":"包河区"},{"id":2318,"pid":2310,"name":"瑶海区"},{"id":2319,"pid":2310,"name":"蜀山区"},{"id":2320,"pid":2245,"name":"芜湖市"},{"id":2321,"pid":2320,"name":"芜湖县"},{"id":2322,"pid":2320,"name":"三山区"},{"id":2323,"pid":2320,"name":"繁昌县"},{"id":2324,"pid":2320,"name":"鸠江区"},{"id":2325,"pid":2320,"name":"弋江区"},{"id":2326,"pid":2320,"name":"南陵县"},{"id":2327,"pid":2320,"name":"无为县"},{"id":2328,"pid":2320,"name":"镜湖区"},{"id":2329,"pid":2245,"name":"宣城市"},{"id":2330,"pid":2329,"name":"绩溪县"},{"id":2331,"pid":2329,"name":"宁国市"},{"id":2332,"pid":2329,"name":"广德县"},{"id":2333,"pid":2329,"name":"宣州区"},{"id":2334,"pid":2329,"name":"泾县"},{"id":2335,"pid":2329,"name":"郎溪县"},{"id":2336,"pid":2329,"name":"旌德县"},{"id":2337,"pid":2245,"name":"六安市"},{"id":2338,"pid":2337,"name":"舒城县"},{"id":2339,"pid":2337,"name":"霍邱县"},{"id":2340,"pid":2337,"name":"金寨县"},{"id":2341,"pid":2337,"name":"叶集区"},{"id":2342,"pid":2337,"name":"霍山县"},{"id":2343,"pid":2337,"name":"裕安区"},{"id":2344,"pid":2337,"name":"金安区"},{"id":2345,"pid":2245,"name":"淮南市"},{"id":2346,"pid":2345,"name":"田家庵区"},{"id":2347,"pid":2345,"name":"八公山区"},{"id":2348,"pid":2345,"name":"谢家集区"},{"id":2349,"pid":2345,"name":"大通区"},{"id":2350,"pid":2345,"name":"潘集区"},{"id":2351,"pid":2345,"name":"寿县"},{"id":2352,"pid":2345,"name":"凤台县"},{"id":2353,"pid":2245,"name":"淮北市"},{"id":2354,"pid":2353,"name":"烈山区"},{"id":2355,"pid":2353,"name":"杜集区"},{"id":2356,"pid":2353,"name":"相山区"},{"id":2357,"pid":2353,"name":"濉溪县"},{"id":2358,"pid":1,"name":"西藏"},{"id":2359,"pid":2358,"name":"拉萨市"},{"id":2360,"pid":2359,"name":"堆龙德庆区"},{"id":2361,"pid":2359,"name":"林周县"},{"id":2362,"pid":2359,"name":"曲水县"},{"id":2363,"pid":2359,"name":"尼木县"},{"id":2364,"pid":2359,"name":"城关区"},{"id":2365,"pid":2359,"name":"当雄县"},{"id":2366,"pid":2359,"name":"达孜县"},{"id":2367,"pid":2359,"name":"墨竹工卡县"},{"id":2368,"pid":2358,"name":"昌都市"},{"id":2369,"pid":2368,"name":"察雅县"},{"id":2370,"pid":2368,"name":"贡觉县"},{"id":2371,"pid":2368,"name":"左贡县"},{"id":2372,"pid":2368,"name":"八宿县"},{"id":2373,"pid":2368,"name":"江达县"},{"id":2374,"pid":2368,"name":"洛隆县"},{"id":2375,"pid":2368,"name":"丁青县"},{"id":2376,"pid":2368,"name":"边坝县"},{"id":2377,"pid":2368,"name":"卡若区"},{"id":2378,"pid":2368,"name":"类乌齐县"},{"id":2379,"pid":2368,"name":"芒康县"},{"id":2380,"pid":2358,"name":"那曲地区"},{"id":2381,"pid":2380,"name":"申扎县"},{"id":2382,"pid":2380,"name":"索县"},{"id":2383,"pid":2380,"name":"巴青县"},{"id":2384,"pid":2380,"name":"尼玛县"},{"id":2385,"pid":2380,"name":"那曲县"},{"id":2386,"pid":2380,"name":"班戈县"},{"id":2387,"pid":2380,"name":"嘉黎县"},{"id":2388,"pid":2380,"name":"安多县"},{"id":2389,"pid":2380,"name":"双湖县"},{"id":2390,"pid":2380,"name":"比如县"},{"id":2391,"pid":2380,"name":"聂荣县"},{"id":2392,"pid":2358,"name":"日喀则市"},{"id":2393,"pid":2392,"name":"江孜县"},{"id":2394,"pid":2392,"name":"萨迦县"},{"id":2395,"pid":2392,"name":"定结县"},{"id":2396,"pid":2392,"name":"萨嘎县"},{"id":2397,"pid":2392,"name":"桑珠孜区"},{"id":2398,"pid":2392,"name":"岗巴县"},{"id":2399,"pid":2392,"name":"昂仁县"},{"id":2400,"pid":2392,"name":"仲巴县"},{"id":2401,"pid":2392,"name":"南木林县"},{"id":2402,"pid":2392,"name":"白朗县"},{"id":2403,"pid":2392,"name":"吉隆县"},{"id":2404,"pid":2392,"name":"谢通门县"},{"id":2405,"pid":2392,"name":"亚东县"},{"id":2406,"pid":2392,"name":"仁布县"},{"id":2407,"pid":2392,"name":"定日县"},{"id":2408,"pid":2392,"name":"拉孜县"},{"id":2409,"pid":2392,"name":"聂拉木县"},{"id":2410,"pid":2392,"name":"康马县"},{"id":2411,"pid":2358,"name":"林芝市"},{"id":2412,"pid":2411,"name":"察隅县"},{"id":2413,"pid":2411,"name":"朗县"},{"id":2414,"pid":2411,"name":"墨脱县"},{"id":2415,"pid":2411,"name":"工布江达县"},{"id":2416,"pid":2411,"name":"米林县"},{"id":2417,"pid":2411,"name":"巴宜区"},{"id":2418,"pid":2411,"name":"波密县"},{"id":2419,"pid":2358,"name":"山南地区"},{"id":2420,"pid":2419,"name":"错那县"},{"id":2421,"pid":2419,"name":"隆子县"},{"id":2422,"pid":2419,"name":"浪卡子县"},{"id":2423,"pid":2419,"name":"扎囊县"},{"id":2424,"pid":2419,"name":"乃东县"},{"id":2425,"pid":2419,"name":"洛扎县"},{"id":2426,"pid":2419,"name":"加查县"},{"id":2427,"pid":2419,"name":"琼结县"},{"id":2428,"pid":2419,"name":"曲松县"},{"id":2429,"pid":2419,"name":"贡嘎县"},{"id":2430,"pid":2419,"name":"措美县"},{"id":2431,"pid":2419,"name":"桑日县"},{"id":2432,"pid":2358,"name":"阿里地区"},{"id":2433,"pid":2432,"name":"噶尔县"},{"id":2434,"pid":2432,"name":"措勤县"},{"id":2435,"pid":2432,"name":"普兰县"},{"id":2436,"pid":2432,"name":"改则县"},{"id":2437,"pid":2432,"name":"札达县"},{"id":2438,"pid":2432,"name":"日土县"},{"id":2439,"pid":2432,"name":"革吉县"},{"id":2440,"pid":1,"name":"上海"},{"id":2441,"pid":2440,"name":"上海市"},{"id":2442,"pid":2441,"name":"闵行区"},{"id":2443,"pid":2441,"name":"青浦区"},{"id":2444,"pid":2441,"name":"长宁区"},{"id":2445,"pid":2441,"name":"宝山区"},{"id":2446,"pid":2441,"name":"嘉定区"},{"id":2447,"pid":2441,"name":"松江区"},{"id":2448,"pid":2441,"name":"静安区"},{"id":2449,"pid":2441,"name":"浦东新区"},{"id":2450,"pid":2441,"name":"杨浦区"},{"id":2451,"pid":2441,"name":"虹口区"},{"id":2452,"pid":2441,"name":"金山区"},{"id":2453,"pid":2441,"name":"徐汇区"},{"id":2454,"pid":2441,"name":"黄浦区"},{"id":2455,"pid":2441,"name":"崇明区"},{"id":2456,"pid":2441,"name":"普陀区"},{"id":2457,"pid":2441,"name":"奉贤区"},{"id":2458,"pid":1,"name":"吉林"},{"id":2459,"pid":2458,"name":"长春市"},{"id":2460,"pid":2459,"name":"朝阳区"},{"id":2461,"pid":2459,"name":"九台区"},{"id":2462,"pid":2459,"name":"宽城区"},{"id":2463,"pid":2459,"name":"德惠市"},{"id":2464,"pid":2459,"name":"二道区"},{"id":2465,"pid":2459,"name":"绿园区"},{"id":2466,"pid":2459,"name":"南关区"},{"id":2467,"pid":2459,"name":"双阳区"},{"id":2468,"pid":2459,"name":"榆树市"},{"id":2469,"pid":2459,"name":"农安县"},{"id":2470,"pid":2458,"name":"通化市"},{"id":2471,"pid":2470,"name":"通化县"},{"id":2472,"pid":2470,"name":"辉南县"},{"id":2473,"pid":2470,"name":"梅河口市"},{"id":2474,"pid":2470,"name":"东昌区"},{"id":2475,"pid":2470,"name":"柳河县"},{"id":2476,"pid":2470,"name":"二道江区"},{"id":2477,"pid":2470,"name":"集安市"},{"id":2478,"pid":2458,"name":"白城市"},{"id":2479,"pid":2478,"name":"洮北区"},{"id":2480,"pid":2478,"name":"通榆县"},{"id":2481,"pid":2478,"name":"大安市"},{"id":2482,"pid":2478,"name":"镇赉县"},{"id":2483,"pid":2478,"name":"洮南市"},{"id":2484,"pid":2458,"name":"辽源市"},{"id":2485,"pid":2484,"name":"龙山区"},{"id":2486,"pid":2484,"name":"东丰县"},{"id":2487,"pid":2484,"name":"东辽县"},{"id":2488,"pid":2484,"name":"西安区"},{"id":2489,"pid":2458,"name":"白山市"},{"id":2490,"pid":2489,"name":"临江市"},{"id":2491,"pid":2489,"name":"抚松县"},{"id":2492,"pid":2489,"name":"长白朝鲜族自治县"},{"id":2493,"pid":2489,"name":"浑江区"},{"id":2494,"pid":2489,"name":"江源区"},{"id":2495,"pid":2489,"name":"靖宇县"},{"id":2496,"pid":2458,"name":"四平市"},{"id":2497,"pid":2496,"name":"公主岭市"},{"id":2498,"pid":2496,"name":"铁西区"},{"id":2499,"pid":2496,"name":"梨树县"},{"id":2500,"pid":2496,"name":"铁东区"},{"id":2501,"pid":2496,"name":"伊通满族自治县"},{"id":2502,"pid":2496,"name":"双辽市"},{"id":2503,"pid":2458,"name":"吉林市"},{"id":2504,"pid":2503,"name":"龙潭区"},{"id":2505,"pid":2503,"name":"昌邑区"},{"id":2506,"pid":2503,"name":"桦甸市"},{"id":2507,"pid":2503,"name":"舒兰市"},{"id":2508,"pid":2503,"name":"船营区"},{"id":2509,"pid":2503,"name":"蛟河市"},{"id":2510,"pid":2503,"name":"丰满区"},{"id":2511,"pid":2503,"name":"磐石市"},{"id":2512,"pid":2503,"name":"永吉县"},{"id":2513,"pid":2458,"name":"松原市"},{"id":2514,"pid":2513,"name":"扶余市"},{"id":2515,"pid":2513,"name":"前郭尔罗斯蒙古族自治县"},{"id":2516,"pid":2513,"name":"乾安县"},{"id":2517,"pid":2513,"name":"宁江区"},{"id":2518,"pid":2513,"name":"长岭县"},{"id":2519,"pid":2458,"name":"延边朝鲜族自治州"},{"id":2520,"pid":2519,"name":"延吉市"},{"id":2521,"pid":2519,"name":"珲春市"},{"id":2522,"pid":2519,"name":"汪清县"},{"id":2523,"pid":2519,"name":"图们市"},{"id":2524,"pid":2519,"name":"和龙市"},{"id":2525,"pid":2519,"name":"敦化市"},{"id":2526,"pid":2519,"name":"龙井市"},{"id":2527,"pid":2519,"name":"安图县"},{"id":2528,"pid":1,"name":"甘肃"},{"id":2529,"pid":2528,"name":"庆阳市"},{"id":2530,"pid":2529,"name":"宁县"},{"id":2531,"pid":2529,"name":"西峰区"},{"id":2532,"pid":2529,"name":"庆城县"},{"id":2533,"pid":2529,"name":"华池县"},{"id":2534,"pid":2529,"name":"合水县"},{"id":2535,"pid":2529,"name":"镇原县"},{"id":2536,"pid":2529,"name":"环县"},{"id":2537,"pid":2529,"name":"正宁县"},{"id":2538,"pid":2528,"name":"平凉市"},{"id":2539,"pid":2538,"name":"崇信县"},{"id":2540,"pid":2538,"name":"华亭县"},{"id":2541,"pid":2538,"name":"泾川县"},{"id":2542,"pid":2538,"name":"灵台县"},{"id":2543,"pid":2538,"name":"静宁县"},{"id":2544,"pid":2538,"name":"崆峒区"},{"id":2545,"pid":2538,"name":"庄浪县"},{"id":2546,"pid":2528,"name":"酒泉市"},{"id":2547,"pid":2546,"name":"肃北蒙古族自治县"},{"id":2548,"pid":2546,"name":"肃州区"},{"id":2549,"pid":2546,"name":"金塔县"},{"id":2550,"pid":2546,"name":"敦煌市"},{"id":2551,"pid":2546,"name":"玉门市"},{"id":2552,"pid":2546,"name":"阿克塞哈萨克族自治县"},{"id":2553,"pid":2546,"name":"瓜州县"},{"id":2554,"pid":2528,"name":"白银市"},{"id":2555,"pid":2554,"name":"靖远县"},{"id":2556,"pid":2554,"name":"景泰县"},{"id":2557,"pid":2554,"name":"会宁县"},{"id":2558,"pid":2554,"name":"白银区"},{"id":2559,"pid":2554,"name":"平川区"},{"id":2560,"pid":2528,"name":"兰州市"},{"id":2561,"pid":2560,"name":"西固区"},{"id":2562,"pid":2560,"name":"安宁区"},{"id":2563,"pid":2560,"name":"城关区"},{"id":2564,"pid":2560,"name":"七里河区"},{"id":2565,"pid":2560,"name":"永登县"},{"id":2566,"pid":2560,"name":"红古区"},{"id":2567,"pid":2560,"name":"皋兰县"},{"id":2568,"pid":2560,"name":"榆中县"},{"id":2569,"pid":2528,"name":"天水市"},{"id":2570,"pid":2569,"name":"麦积区"},{"id":2571,"pid":2569,"name":"张家川回族自治县"},{"id":2572,"pid":2569,"name":"秦州区"},{"id":2573,"pid":2569,"name":"甘谷县"},{"id":2574,"pid":2569,"name":"秦安县"},{"id":2575,"pid":2569,"name":"清水县"},{"id":2576,"pid":2569,"name":"武山县"},{"id":2577,"pid":2528,"name":"陇南市"},{"id":2578,"pid":2577,"name":"两当县"},{"id":2579,"pid":2577,"name":"成县"},{"id":2580,"pid":2577,"name":"康县"},{"id":2581,"pid":2577,"name":"文县"},{"id":2582,"pid":2577,"name":"武都区"},{"id":2583,"pid":2577,"name":"徽县"},{"id":2584,"pid":2577,"name":"宕昌县"},{"id":2585,"pid":2577,"name":"西和县"},{"id":2586,"pid":2577,"name":"礼县"},{"id":2587,"pid":2528,"name":"嘉峪关市"},{"id":2588,"pid":2587,"name":"新城镇"},{"id":2589,"pid":2587,"name":"峪泉镇"},{"id":2590,"pid":2587,"name":"镜铁区"},{"id":2591,"pid":2587,"name":"长城区"},{"id":2592,"pid":2587,"name":"雄关区"},{"id":2593,"pid":2587,"name":"文殊镇"},{"id":2594,"pid":2528,"name":"定西市"},{"id":2595,"pid":2594,"name":"漳县"},{"id":2596,"pid":2594,"name":"陇西县"},{"id":2597,"pid":2594,"name":"岷县"},{"id":2598,"pid":2594,"name":"通渭县"},{"id":2599,"pid":2594,"name":"临洮县"},{"id":2600,"pid":2594,"name":"渭源县"},{"id":2601,"pid":2594,"name":"安定区"},{"id":2602,"pid":2528,"name":"临夏回族自治州"},{"id":2603,"pid":2602,"name":"东乡族自治县"},{"id":2604,"pid":2602,"name":"临夏县"},{"id":2605,"pid":2602,"name":"和政县"},{"id":2606,"pid":2602,"name":"临夏市"},{"id":2607,"pid":2602,"name":"永靖县"},{"id":2608,"pid":2602,"name":"康乐县"},{"id":2609,"pid":2602,"name":"广河县"},{"id":2610,"pid":2602,"name":"积石山保安族东乡族撒拉族自治县"},{"id":2611,"pid":2528,"name":"金昌市"},{"id":2612,"pid":2611,"name":"金川区"},{"id":2613,"pid":2611,"name":"永昌县"},{"id":2614,"pid":2528,"name":"武威市"},{"id":2615,"pid":2614,"name":"古浪县"},{"id":2616,"pid":2614,"name":"凉州区"},{"id":2617,"pid":2614,"name":"民勤县"},{"id":2618,"pid":2614,"name":"天祝藏族自治县"},{"id":2619,"pid":2528,"name":"张掖市"},{"id":2620,"pid":2619,"name":"山丹县"},{"id":2621,"pid":2619,"name":"临泽县"},{"id":2622,"pid":2619,"name":"甘州区"},{"id":2623,"pid":2619,"name":"肃南裕固族自治县"},{"id":2624,"pid":2619,"name":"高台县"},{"id":2625,"pid":2619,"name":"民乐县"},{"id":2626,"pid":2528,"name":"甘南藏族自治州"},{"id":2627,"pid":2626,"name":"夏河县"},{"id":2628,"pid":2626,"name":"卓尼县"},{"id":2629,"pid":2626,"name":"临潭县"},{"id":2630,"pid":2626,"name":"玛曲县"},{"id":2631,"pid":2626,"name":"碌曲县"},{"id":2632,"pid":2626,"name":"舟曲县"},{"id":2633,"pid":2626,"name":"迭部县"},{"id":2634,"pid":2626,"name":"合作市"},{"id":2635,"pid":1,"name":"宁夏"},{"id":2636,"pid":2635,"name":"银川市"},{"id":2637,"pid":2636,"name":"灵武市"},{"id":2638,"pid":2636,"name":"兴庆区"},{"id":2639,"pid":2636,"name":"西夏区"},{"id":2640,"pid":2636,"name":"贺兰县"},{"id":2641,"pid":2636,"name":"永宁县"},{"id":2642,"pid":2636,"name":"金凤区"},{"id":2643,"pid":2635,"name":"石嘴山市"},{"id":2644,"pid":2643,"name":"大武口区"},{"id":2645,"pid":2643,"name":"平罗县"},{"id":2646,"pid":2643,"name":"惠农区"},{"id":2647,"pid":2635,"name":"中卫市"},{"id":2648,"pid":2647,"name":"海原县"},{"id":2649,"pid":2647,"name":"中宁县"},{"id":2650,"pid":2647,"name":"沙坡头区"},{"id":2651,"pid":2635,"name":"固原市"},{"id":2652,"pid":2651,"name":"彭阳县"},{"id":2653,"pid":2651,"name":"西吉县"},{"id":2654,"pid":2651,"name":"泾源县"},{"id":2655,"pid":2651,"name":"原州区"},{"id":2656,"pid":2651,"name":"隆德县"},{"id":2657,"pid":2635,"name":"吴忠市"},{"id":2658,"pid":2657,"name":"盐池县"},{"id":2659,"pid":2657,"name":"红寺堡区"},{"id":2660,"pid":2657,"name":"青铜峡市"},{"id":2661,"pid":2657,"name":"利通区"},{"id":2662,"pid":2657,"name":"同心县"},{"id":2663,"pid":1,"name":"山西"},{"id":2664,"pid":2663,"name":"运城市"},{"id":2665,"pid":2664,"name":"闻喜县"},{"id":2666,"pid":2664,"name":"垣曲县"},{"id":2667,"pid":2664,"name":"芮城县"},{"id":2668,"pid":2664,"name":"绛县"},{"id":2669,"pid":2664,"name":"永济市"},{"id":2670,"pid":2664,"name":"临猗县"},{"id":2671,"pid":2664,"name":"稷山县"},{"id":2672,"pid":2664,"name":"河津市"},{"id":2673,"pid":2664,"name":"万荣县"},{"id":2674,"pid":2664,"name":"新绛县"},{"id":2675,"pid":2664,"name":"平陆县"},{"id":2676,"pid":2664,"name":"夏县"},{"id":2677,"pid":2664,"name":"盐湖区"},{"id":2678,"pid":2663,"name":"太原市"},{"id":2679,"pid":2678,"name":"尖草坪区"},{"id":2680,"pid":2678,"name":"阳曲县"},{"id":2681,"pid":2678,"name":"万柏林区"},{"id":2682,"pid":2678,"name":"迎泽区"},{"id":2683,"pid":2678,"name":"娄烦县"},{"id":2684,"pid":2678,"name":"杏花岭区"},{"id":2685,"pid":2678,"name":"古交市"},{"id":2686,"pid":2678,"name":"小店区"},{"id":2687,"pid":2678,"name":"晋源区"},{"id":2688,"pid":2678,"name":"清徐县"},{"id":2689,"pid":2663,"name":"大同市"},{"id":2690,"pid":2689,"name":"天镇县"},{"id":2691,"pid":2689,"name":"灵丘县"},{"id":2692,"pid":2689,"name":"大同县"},{"id":2693,"pid":2689,"name":"矿区"},{"id":2694,"pid":2689,"name":"城区"},{"id":2695,"pid":2689,"name":"浑源县"},{"id":2696,"pid":2689,"name":"广灵县"},{"id":2697,"pid":2689,"name":"新荣区"},{"id":2698,"pid":2689,"name":"阳高县"},{"id":2699,"pid":2689,"name":"南郊区"},{"id":2700,"pid":2689,"name":"左云县"},{"id":2701,"pid":2663,"name":"晋城市"},{"id":2702,"pid":2701,"name":"城区"},{"id":2703,"pid":2701,"name":"高平市"},{"id":2704,"pid":2701,"name":"陵川县"},{"id":2705,"pid":2701,"name":"沁水县"},{"id":2706,"pid":2701,"name":"泽州县"},{"id":2707,"pid":2701,"name":"阳城县"},{"id":2708,"pid":2663,"name":"朔州市"},{"id":2709,"pid":2708,"name":"应县"},{"id":2710,"pid":2708,"name":"右玉县"},{"id":2711,"pid":2708,"name":"山阴县"},{"id":2712,"pid":2708,"name":"平鲁区"},{"id":2713,"pid":2708,"name":"怀仁县"},{"id":2714,"pid":2708,"name":"朔城区"},{"id":2715,"pid":2663,"name":"长治市"},{"id":2716,"pid":2715,"name":"黎城县"},{"id":2717,"pid":2715,"name":"郊区"},{"id":2718,"pid":2715,"name":"城区"},{"id":2719,"pid":2715,"name":"平顺县"},{"id":2720,"pid":2715,"name":"襄垣县"},{"id":2721,"pid":2715,"name":"长子县"},{"id":2722,"pid":2715,"name":"沁县"},{"id":2723,"pid":2715,"name":"沁源县"},{"id":2724,"pid":2715,"name":"武乡县"},{"id":2725,"pid":2715,"name":"壶关县"},{"id":2726,"pid":2715,"name":"屯留县"},{"id":2727,"pid":2715,"name":"长治县"},{"id":2728,"pid":2715,"name":"潞城市"},{"id":2729,"pid":2663,"name":"晋中市"},{"id":2730,"pid":2729,"name":"寿阳县"},{"id":2731,"pid":2729,"name":"和顺县"},{"id":2732,"pid":2729,"name":"昔阳县"},{"id":2733,"pid":2729,"name":"祁县"},{"id":2734,"pid":2729,"name":"太谷县"},{"id":2735,"pid":2729,"name":"灵石县"},{"id":2736,"pid":2729,"name":"榆次区"},{"id":2737,"pid":2729,"name":"平遥县"},{"id":2738,"pid":2729,"name":"榆社县"},{"id":2739,"pid":2729,"name":"介休市"},{"id":2740,"pid":2729,"name":"左权县"},{"id":2741,"pid":2663,"name":"忻州市"},{"id":2742,"pid":2741,"name":"岢岚县"},{"id":2743,"pid":2741,"name":"繁峙县"},{"id":2744,"pid":2741,"name":"河曲县"},{"id":2745,"pid":2741,"name":"神池县"},{"id":2746,"pid":2741,"name":"静乐县"},{"id":2747,"pid":2741,"name":"原平市"},{"id":2748,"pid":2741,"name":"偏关县"},{"id":2749,"pid":2741,"name":"忻府区"},{"id":2750,"pid":2741,"name":"五台县"},{"id":2751,"pid":2741,"name":"保德县"},{"id":2752,"pid":2741,"name":"代县"},{"id":2753,"pid":2741,"name":"五寨县"},{"id":2754,"pid":2741,"name":"定襄县"},{"id":2755,"pid":2741,"name":"宁武县"},{"id":2756,"pid":2663,"name":"临汾市"},{"id":2757,"pid":2756,"name":"曲沃县"},{"id":2758,"pid":2756,"name":"翼城县"},{"id":2759,"pid":2756,"name":"永和县"},{"id":2760,"pid":2756,"name":"洪洞县"},{"id":2761,"pid":2756,"name":"安泽县"},{"id":2762,"pid":2756,"name":"乡宁县"},{"id":2763,"pid":2756,"name":"尧都区"},{"id":2764,"pid":2756,"name":"古县"},{"id":2765,"pid":2756,"name":"霍州市"},{"id":2766,"pid":2756,"name":"襄汾县"},{"id":2767,"pid":2756,"name":"汾西县"},{"id":2768,"pid":2756,"name":"浮山县"},{"id":2769,"pid":2756,"name":"侯马市"},{"id":2770,"pid":2756,"name":"吉县"},{"id":2771,"pid":2756,"name":"蒲县"},{"id":2772,"pid":2756,"name":"隰县"},{"id":2773,"pid":2756,"name":"大宁县"},{"id":2774,"pid":2663,"name":"阳泉市"},{"id":2775,"pid":2774,"name":"郊区"},{"id":2776,"pid":2774,"name":"盂县"},{"id":2777,"pid":2774,"name":"矿区"},{"id":2778,"pid":2774,"name":"平定县"},{"id":2779,"pid":2774,"name":"城区"},{"id":2780,"pid":2663,"name":"吕梁市"},{"id":2781,"pid":2780,"name":"兴县"},{"id":2782,"pid":2780,"name":"临县"},{"id":2783,"pid":2780,"name":"汾阳市"},{"id":2784,"pid":2780,"name":"交城县"},{"id":2785,"pid":2780,"name":"柳林县"},{"id":2786,"pid":2780,"name":"中阳县"},{"id":2787,"pid":2780,"name":"方山县"},{"id":2788,"pid":2780,"name":"岚县"},{"id":2789,"pid":2780,"name":"交口县"},{"id":2790,"pid":2780,"name":"离石区"},{"id":2791,"pid":2780,"name":"孝义市"},{"id":2792,"pid":2780,"name":"文水县"},{"id":2793,"pid":2780,"name":"石楼县"},{"id":2794,"pid":1,"name":"香港"},{"id":2795,"pid":2794,"name":"新界"},{"id":2796,"pid":2795,"name":"大埔区"},{"id":2797,"pid":2795,"name":"沙田区"},{"id":2798,"pid":2795,"name":"荃湾区"},{"id":2799,"pid":2795,"name":"北区"},{"id":2800,"pid":2795,"name":"元朗区"},{"id":2801,"pid":2795,"name":"屯门区"},{"id":2802,"pid":2795,"name":"西贡区"},{"id":2803,"pid":2795,"name":"葵青区"},{"id":2804,"pid":2795,"name":"离岛区"},{"id":2805,"pid":2794,"name":"香港岛"},{"id":2806,"pid":2805,"name":"东区"},{"id":2807,"pid":2805,"name":"南区"},{"id":2808,"pid":2805,"name":"湾仔区"},{"id":2809,"pid":2805,"name":"中西区"},{"id":2810,"pid":2794,"name":"九龙半岛"},{"id":2811,"pid":2810,"name":"黄大仙区"},{"id":2812,"pid":2810,"name":"观塘区"},{"id":2813,"pid":2810,"name":"九龙城区"},{"id":2814,"pid":2810,"name":"深水埗区"},{"id":2815,"pid":2810,"name":"油尖旺区"},{"id":2816,"pid":1,"name":"四川"},{"id":2817,"pid":2816,"name":"阿坝藏族羌族自治州"},{"id":2818,"pid":2817,"name":"马尔康市"},{"id":2819,"pid":2817,"name":"红原县"},{"id":2820,"pid":2817,"name":"茂县"},{"id":2821,"pid":2817,"name":"九寨沟县"},{"id":2822,"pid":2817,"name":"若尔盖县"},{"id":2823,"pid":2817,"name":"壤塘县"},{"id":2824,"pid":2817,"name":"小金县"},{"id":2825,"pid":2817,"name":"理县"},{"id":2826,"pid":2817,"name":"松潘县"},{"id":2827,"pid":2817,"name":"汶川县"},{"id":2828,"pid":2817,"name":"金川县"},{"id":2829,"pid":2817,"name":"黑水县"},{"id":2830,"pid":2817,"name":"阿坝县"},{"id":2831,"pid":2816,"name":"宜宾市"},{"id":2832,"pid":2831,"name":"翠屏区"},{"id":2833,"pid":2831,"name":"南溪区"},{"id":2834,"pid":2831,"name":"长宁县"},{"id":2835,"pid":2831,"name":"筠连县"},{"id":2836,"pid":2831,"name":"兴文县"},{"id":2837,"pid":2831,"name":"高县"},{"id":2838,"pid":2831,"name":"江安县"},{"id":2839,"pid":2831,"name":"珙县"},{"id":2840,"pid":2831,"name":"屏山县"},{"id":2841,"pid":2831,"name":"宜宾县"},{"id":2842,"pid":2816,"name":"巴中市"},{"id":2843,"pid":2842,"name":"通江县"},{"id":2844,"pid":2842,"name":"南江县"},{"id":2845,"pid":2842,"name":"平昌县"},{"id":2846,"pid":2842,"name":"巴州区"},{"id":2847,"pid":2842,"name":"恩阳区"},{"id":2848,"pid":2816,"name":"达州市"},{"id":2849,"pid":2848,"name":"大竹县"},{"id":2850,"pid":2848,"name":"开江县"},{"id":2851,"pid":2848,"name":"渠县"},{"id":2852,"pid":2848,"name":"万源市"},{"id":2853,"pid":2848,"name":"达川区"},{"id":2854,"pid":2848,"name":"宣汉县"},{"id":2855,"pid":2848,"name":"通川区"},{"id":2856,"pid":2816,"name":"甘孜藏族自治州"},{"id":2857,"pid":2856,"name":"炉霍县"},{"id":2858,"pid":2856,"name":"乡城县"},{"id":2859,"pid":2856,"name":"得荣县"},{"id":2860,"pid":2856,"name":"雅江县"},{"id":2861,"pid":2856,"name":"新龙县"},{"id":2862,"pid":2856,"name":"色达县"},{"id":2863,"pid":2856,"name":"德格县"},{"id":2864,"pid":2856,"name":"康定市"},{"id":2865,"pid":2856,"name":"巴塘县"},{"id":2866,"pid":2856,"name":"道孚县"},{"id":2867,"pid":2856,"name":"理塘县"},{"id":2868,"pid":2856,"name":"丹巴县"},{"id":2869,"pid":2856,"name":"白玉县"},{"id":2870,"pid":2856,"name":"泸定县"},{"id":2871,"pid":2856,"name":"甘孜县"},{"id":2872,"pid":2856,"name":"稻城县"},{"id":2873,"pid":2856,"name":"九龙县"},{"id":2874,"pid":2856,"name":"石渠县"},{"id":2875,"pid":2816,"name":"绵阳市"},{"id":2876,"pid":2875,"name":"涪城区"},{"id":2877,"pid":2875,"name":"梓潼县"},{"id":2878,"pid":2875,"name":"平武县"},{"id":2879,"pid":2875,"name":"盐亭县"},{"id":2880,"pid":2875,"name":"北川羌族自治县"},{"id":2881,"pid":2875,"name":"三台县"},{"id":2882,"pid":2875,"name":"江油市"},{"id":2883,"pid":2875,"name":"安县"},{"id":2884,"pid":2875,"name":"游仙区"},{"id":2885,"pid":2816,"name":"遂宁市"},{"id":2886,"pid":2885,"name":"蓬溪县"},{"id":2887,"pid":2885,"name":"船山区"},{"id":2888,"pid":2885,"name":"大英县"},{"id":2889,"pid":2885,"name":"安居区"},{"id":2890,"pid":2885,"name":"射洪县"},{"id":2891,"pid":2816,"name":"乐山市"},{"id":2892,"pid":2891,"name":"沙湾区"},{"id":2893,"pid":2891,"name":"沐川县"},{"id":2894,"pid":2891,"name":"峨眉山市"},{"id":2895,"pid":2891,"name":"马边彝族自治县"},{"id":2896,"pid":2891,"name":"市中区"},{"id":2897,"pid":2891,"name":"犍为县"},{"id":2898,"pid":2891,"name":"井研县"},{"id":2899,"pid":2891,"name":"夹江县"},{"id":2900,"pid":2891,"name":"金口河区"},{"id":2901,"pid":2891,"name":"五通桥区"},{"id":2902,"pid":2891,"name":"峨边彝族自治县"},{"id":2903,"pid":2816,"name":"攀枝花市"},{"id":2904,"pid":2903,"name":"米易县"},{"id":2905,"pid":2903,"name":"东区"},{"id":2906,"pid":2903,"name":"盐边县"},{"id":2907,"pid":2903,"name":"西区"},{"id":2908,"pid":2903,"name":"仁和区"},{"id":2909,"pid":2816,"name":"眉山市"},{"id":2910,"pid":2909,"name":"仁寿县"},{"id":2911,"pid":2909,"name":"青神县"},{"id":2912,"pid":2909,"name":"东坡区"},{"id":2913,"pid":2909,"name":"丹棱县"},{"id":2914,"pid":2909,"name":"彭山区"},{"id":2915,"pid":2909,"name":"洪雅县"},{"id":2916,"pid":2816,"name":"广元市"},{"id":2917,"pid":2916,"name":"朝天区"},{"id":2918,"pid":2916,"name":"旺苍县"},{"id":2919,"pid":2916,"name":"利州区"},{"id":2920,"pid":2916,"name":"青川县"},{"id":2921,"pid":2916,"name":"昭化区"},{"id":2922,"pid":2916,"name":"剑阁县"},{"id":2923,"pid":2916,"name":"苍溪县"},{"id":2924,"pid":2816,"name":"自贡市"},{"id":2925,"pid":2924,"name":"大安区"},{"id":2926,"pid":2924,"name":"沿滩区"},{"id":2927,"pid":2924,"name":"富顺县"},{"id":2928,"pid":2924,"name":"荣县"},{"id":2929,"pid":2924,"name":"贡井区"},{"id":2930,"pid":2924,"name":"自流井区"},{"id":2931,"pid":2816,"name":"广安市"},{"id":2932,"pid":2931,"name":"华蓥市"},{"id":2933,"pid":2931,"name":"武胜县"},{"id":2934,"pid":2931,"name":"邻水县"},{"id":2935,"pid":2931,"name":"岳池县"},{"id":2936,"pid":2931,"name":"前锋区"},{"id":2937,"pid":2931,"name":"广安区"},{"id":2938,"pid":2816,"name":"凉山彝族自治州"},{"id":2939,"pid":2938,"name":"布拖县"},{"id":2940,"pid":2938,"name":"会理县"},{"id":2941,"pid":2938,"name":"西昌市"},{"id":2942,"pid":2938,"name":"宁南县"},{"id":2943,"pid":2938,"name":"金阳县"},{"id":2944,"pid":2938,"name":"喜德县"},{"id":2945,"pid":2938,"name":"冕宁县"},{"id":2946,"pid":2938,"name":"越西县"},{"id":2947,"pid":2938,"name":"会东县"},{"id":2948,"pid":2938,"name":"雷波县"},{"id":2949,"pid":2938,"name":"昭觉县"},{"id":2950,"pid":2938,"name":"盐源县"},{"id":2951,"pid":2938,"name":"美姑县"},{"id":2952,"pid":2938,"name":"德昌县"},{"id":2953,"pid":2938,"name":"甘洛县"},{"id":2954,"pid":2938,"name":"普格县"},{"id":2955,"pid":2938,"name":"木里藏族自治县"},{"id":2956,"pid":2816,"name":"成都市"},{"id":2957,"pid":2956,"name":"彭州市"},{"id":2958,"pid":2956,"name":"金堂县"},{"id":2959,"pid":2956,"name":"金牛区"},{"id":2960,"pid":2956,"name":"新津县"},{"id":2961,"pid":2956,"name":"新都区"},{"id":2962,"pid":2956,"name":"崇州市"},{"id":2963,"pid":2956,"name":"青羊区"},{"id":2964,"pid":2956,"name":"郫县"},{"id":2965,"pid":2956,"name":"成华区"},{"id":2966,"pid":2956,"name":"武侯区"},{"id":2967,"pid":2956,"name":"双流区"},{"id":2968,"pid":2956,"name":"蒲江县"},{"id":2969,"pid":2956,"name":"温江区"},{"id":2970,"pid":2956,"name":"邛崃市"},{"id":2971,"pid":2956,"name":"青白江区"},{"id":2972,"pid":2956,"name":"大邑县"},{"id":2973,"pid":2956,"name":"锦江区"},{"id":2974,"pid":2956,"name":"龙泉驿区"},{"id":2975,"pid":2956,"name":"都江堰市"},{"id":2976,"pid":2816,"name":"南充市"},{"id":2977,"pid":2976,"name":"南部县"},{"id":2978,"pid":2976,"name":"顺庆区"},{"id":2979,"pid":2976,"name":"阆中市"},{"id":2980,"pid":2976,"name":"西充县"},{"id":2981,"pid":2976,"name":"高坪区"},{"id":2982,"pid":2976,"name":"营山县"},{"id":2983,"pid":2976,"name":"仪陇县"},{"id":2984,"pid":2976,"name":"嘉陵区"},{"id":2985,"pid":2976,"name":"蓬安县"},{"id":2986,"pid":2816,"name":"内江市"},{"id":2987,"pid":2986,"name":"市中区"},{"id":2988,"pid":2986,"name":"威远县"},{"id":2989,"pid":2986,"name":"隆昌县"},{"id":2990,"pid":2986,"name":"资中县"},{"id":2991,"pid":2986,"name":"东兴区"},{"id":2992,"pid":2816,"name":"资阳市"},{"id":2993,"pid":2992,"name":"安岳县"},{"id":2994,"pid":2992,"name":"乐至县"},{"id":2995,"pid":2992,"name":"简阳市"},{"id":2996,"pid":2992,"name":"雁江区"},{"id":2997,"pid":2816,"name":"泸州市"},{"id":2998,"pid":2997,"name":"合江县"},{"id":2999,"pid":2997,"name":"古蔺县"},{"id":3000,"pid":2997,"name":"叙永县"},{"id":3001,"pid":2997,"name":"纳溪区"},{"id":3002,"pid":2997,"name":"泸县"},{"id":3003,"pid":2997,"name":"龙马潭区"},{"id":3004,"pid":2997,"name":"江阳区"},{"id":3005,"pid":2816,"name":"德阳市"},{"id":3006,"pid":3005,"name":"旌阳区"},{"id":3007,"pid":3005,"name":"绵竹市"},{"id":3008,"pid":3005,"name":"什邡市"},{"id":3009,"pid":3005,"name":"广汉市"},{"id":3010,"pid":3005,"name":"罗江县"},{"id":3011,"pid":3005,"name":"中江县"},{"id":3012,"pid":2816,"name":"雅安市"},{"id":3013,"pid":3012,"name":"名山区"},{"id":3014,"pid":3012,"name":"芦山县"},{"id":3015,"pid":3012,"name":"雨城区"},{"id":3016,"pid":3012,"name":"石棉县"},{"id":3017,"pid":3012,"name":"天全县"},{"id":3018,"pid":3012,"name":"荥经县"},{"id":3019,"pid":3012,"name":"宝兴县"},{"id":3020,"pid":3012,"name":"汉源县"},{"id":3021,"pid":1,"name":"广西"},{"id":3022,"pid":3021,"name":"百色市"},{"id":3023,"pid":3022,"name":"靖西市"},{"id":3024,"pid":3022,"name":"田东县"},{"id":3025,"pid":3022,"name":"右江区"},{"id":3026,"pid":3022,"name":"田阳县"},{"id":3027,"pid":3022,"name":"凌云县"},{"id":3028,"pid":3022,"name":"西林县"},{"id":3029,"pid":3022,"name":"德保县"},{"id":3030,"pid":3022,"name":"那坡县"},{"id":3031,"pid":3022,"name":"隆林各族自治县"},{"id":3032,"pid":3022,"name":"平果县"},{"id":3033,"pid":3022,"name":"乐业县"},{"id":3034,"pid":3022,"name":"田林县"},{"id":3035,"pid":3021,"name":"贺州市"},{"id":3036,"pid":3035,"name":"昭平县"},{"id":3037,"pid":3035,"name":"钟山县"},{"id":3038,"pid":3035,"name":"八步区"},{"id":3039,"pid":3035,"name":"富川瑶族自治县"},{"id":3040,"pid":3021,"name":"柳州市"},{"id":3041,"pid":3040,"name":"柳江县"},{"id":3042,"pid":3040,"name":"鱼峰区"},{"id":3043,"pid":3040,"name":"融水苗族自治县"},{"id":3044,"pid":3040,"name":"三江侗族自治县"},{"id":3045,"pid":3040,"name":"柳城县"},{"id":3046,"pid":3040,"name":"柳北区"},{"id":3047,"pid":3040,"name":"柳南区"},{"id":3048,"pid":3040,"name":"城中区"},{"id":3049,"pid":3040,"name":"鹿寨县"},{"id":3050,"pid":3040,"name":"融安县"},{"id":3051,"pid":3021,"name":"来宾市"},{"id":3052,"pid":3051,"name":"象州县"},{"id":3053,"pid":3051,"name":"金秀瑶族自治县"},{"id":3054,"pid":3051,"name":"武宣县"},{"id":3055,"pid":3051,"name":"兴宾区"},{"id":3056,"pid":3051,"name":"合山市"},{"id":3057,"pid":3051,"name":"忻城县"},{"id":3058,"pid":3021,"name":"北海市"},{"id":3059,"pid":3058,"name":"银海区"},{"id":3060,"pid":3058,"name":"海城区"},{"id":3061,"pid":3058,"name":"合浦县"},{"id":3062,"pid":3058,"name":"铁山港区"},{"id":3063,"pid":3021,"name":"玉林市"},{"id":3064,"pid":3063,"name":"兴业县"},{"id":3065,"pid":3063,"name":"陆川县"},{"id":3066,"pid":3063,"name":"玉州区"},{"id":3067,"pid":3063,"name":"博白县"},{"id":3068,"pid":3063,"name":"福绵区"},{"id":3069,"pid":3063,"name":"北流市"},{"id":3070,"pid":3063,"name":"容县"},{"id":3071,"pid":3021,"name":"崇左市"},{"id":3072,"pid":3071,"name":"扶绥县"},{"id":3073,"pid":3071,"name":"天等县"},{"id":3074,"pid":3071,"name":"江洲区"},{"id":3075,"pid":3071,"name":"宁明县"},{"id":3076,"pid":3071,"name":"凭祥市"},{"id":3077,"pid":3071,"name":"龙州县"},{"id":3078,"pid":3071,"name":"大新县"},{"id":3079,"pid":3021,"name":"河池市"},{"id":3080,"pid":3079,"name":"环江毛南族自治县"},{"id":3081,"pid":3079,"name":"大化瑶族自治县"},{"id":3082,"pid":3079,"name":"宜州市"},{"id":3083,"pid":3079,"name":"东兰县"},{"id":3084,"pid":3079,"name":"罗城仫佬族自治县"},{"id":3085,"pid":3079,"name":"金城江区"},{"id":3086,"pid":3079,"name":"巴马瑶族自治县"},{"id":3087,"pid":3079,"name":"天峨县"},{"id":3088,"pid":3079,"name":"凤山县"},{"id":3089,"pid":3079,"name":"都安瑶族自治县"},{"id":3090,"pid":3079,"name":"南丹县"},{"id":3091,"pid":3021,"name":"防城港市"},{"id":3092,"pid":3091,"name":"防城区"},{"id":3093,"pid":3091,"name":"东兴市"},{"id":3094,"pid":3091,"name":"上思县"},{"id":3095,"pid":3091,"name":"港口区"},{"id":3096,"pid":3021,"name":"钦州市"},{"id":3097,"pid":3096,"name":"钦南区"},{"id":3098,"pid":3096,"name":"钦北区"},{"id":3099,"pid":3096,"name":"灵山县"},{"id":3100,"pid":3096,"name":"浦北县"},{"id":3101,"pid":3021,"name":"贵港市"},{"id":3102,"pid":3101,"name":"桂平市"},{"id":3103,"pid":3101,"name":"平南县"},{"id":3104,"pid":3101,"name":"港北区"},{"id":3105,"pid":3101,"name":"港南区"},{"id":3106,"pid":3101,"name":"覃塘区"},{"id":3107,"pid":3021,"name":"桂林市"},{"id":3108,"pid":3107,"name":"灌阳县"},{"id":3109,"pid":3107,"name":"灵川县"},{"id":3110,"pid":3107,"name":"雁山区"},{"id":3111,"pid":3107,"name":"龙胜各族自治县"},{"id":3112,"pid":3107,"name":"永福县"},{"id":3113,"pid":3107,"name":"平乐县"},{"id":3114,"pid":3107,"name":"七星区"},{"id":3115,"pid":3107,"name":"象山区"},{"id":3116,"pid":3107,"name":"恭城瑶族自治县"},{"id":3117,"pid":3107,"name":"资源县"},{"id":3118,"pid":3107,"name":"全州县"},{"id":3119,"pid":3107,"name":"叠彩区"},{"id":3120,"pid":3107,"name":"兴安县"},{"id":3121,"pid":3107,"name":"荔浦县"},{"id":3122,"pid":3107,"name":"秀峰区"},{"id":3123,"pid":3107,"name":"临桂区"},{"id":3124,"pid":3107,"name":"阳朔县"},{"id":3125,"pid":3021,"name":"南宁市"},{"id":3126,"pid":3125,"name":"兴宁区"},{"id":3127,"pid":3125,"name":"宾阳县"},{"id":3128,"pid":3125,"name":"江南区"},{"id":3129,"pid":3125,"name":"上林县"},{"id":3130,"pid":3125,"name":"邕宁区"},{"id":3131,"pid":3125,"name":"西乡塘区"},{"id":3132,"pid":3125,"name":"马山县"},{"id":3133,"pid":3125,"name":"良庆区"},{"id":3134,"pid":3125,"name":"横县"},{"id":3135,"pid":3125,"name":"青秀区"},{"id":3136,"pid":3125,"name":"武鸣区"},{"id":3137,"pid":3125,"name":"隆安县"},{"id":3138,"pid":3021,"name":"梧州市"},{"id":3139,"pid":3138,"name":"岑溪市"},{"id":3140,"pid":3138,"name":"万秀区"},{"id":3141,"pid":3138,"name":"长洲区"},{"id":3142,"pid":3138,"name":"蒙山县"},{"id":3143,"pid":3138,"name":"龙圩区"},{"id":3144,"pid":3138,"name":"藤县"},{"id":3145,"pid":3138,"name":"苍梧县"},{"id":3146,"pid":1,"name":"浙江"},{"id":3147,"pid":3146,"name":"台州市"},{"id":3148,"pid":3147,"name":"仙居县"},{"id":3149,"pid":3147,"name":"天台县"},{"id":3150,"pid":3147,"name":"路桥区"},{"id":3151,"pid":3147,"name":"温岭市"},{"id":3152,"pid":3147,"name":"三门县"},{"id":3153,"pid":3147,"name":"玉环县"},{"id":3154,"pid":3147,"name":"椒江区"},{"id":3155,"pid":3147,"name":"黄岩区"},{"id":3156,"pid":3147,"name":"临海市"},{"id":3157,"pid":3146,"name":"湖州市"},{"id":3158,"pid":3157,"name":"长兴县"},{"id":3159,"pid":3157,"name":"德清县"},{"id":3160,"pid":3157,"name":"南浔区"},{"id":3161,"pid":3157,"name":"吴兴区"},{"id":3162,"pid":3157,"name":"安吉县"},{"id":3163,"pid":3146,"name":"宁波市"},{"id":3164,"pid":3163,"name":"北仑区"},{"id":3165,"pid":3163,"name":"江北区"},{"id":3166,"pid":3163,"name":"余姚市"},{"id":3167,"pid":3163,"name":"象山县"},{"id":3168,"pid":3163,"name":"鄞州区"},{"id":3169,"pid":3163,"name":"镇海区"},{"id":3170,"pid":3163,"name":"慈溪市"},{"id":3171,"pid":3163,"name":"奉化市"},{"id":3172,"pid":3163,"name":"宁海县"},{"id":3173,"pid":3163,"name":"江东区"},{"id":3174,"pid":3163,"name":"海曙区"},{"id":3175,"pid":3146,"name":"温州市"},{"id":3176,"pid":3175,"name":"洞头区"},{"id":3177,"pid":3175,"name":"苍南县"},{"id":3178,"pid":3175,"name":"龙湾区"},{"id":3179,"pid":3175,"name":"鹿城区"},{"id":3180,"pid":3175,"name":"瓯海区"},{"id":3181,"pid":3175,"name":"瑞安市"},{"id":3182,"pid":3175,"name":"平阳县"},{"id":3183,"pid":3175,"name":"乐清市"},{"id":3184,"pid":3175,"name":"永嘉县"},{"id":3185,"pid":3175,"name":"泰顺县"},{"id":3186,"pid":3175,"name":"文成县"},{"id":3187,"pid":3146,"name":"舟山市"},{"id":3188,"pid":3187,"name":"定海区"},{"id":3189,"pid":3187,"name":"岱山县"},{"id":3190,"pid":3187,"name":"嵊泗县"},{"id":3191,"pid":3187,"name":"普陀区"},{"id":3192,"pid":3146,"name":"金华市"},{"id":3193,"pid":3192,"name":"义乌市"},{"id":3194,"pid":3192,"name":"武义县"},{"id":3195,"pid":3192,"name":"永康市"},{"id":3196,"pid":3192,"name":"金东区"},{"id":3197,"pid":3192,"name":"磐安县"},{"id":3198,"pid":3192,"name":"兰溪市"},{"id":3199,"pid":3192,"name":"婺城区"},{"id":3200,"pid":3192,"name":"东阳市"},{"id":3201,"pid":3192,"name":"浦江县"},{"id":3202,"pid":3146,"name":"丽水市"},{"id":3203,"pid":3202,"name":"缙云县"},{"id":3204,"pid":3202,"name":"云和县"},{"id":3205,"pid":3202,"name":"龙泉市"},{"id":3206,"pid":3202,"name":"青田县"},{"id":3207,"pid":3202,"name":"松阳县"},{"id":3208,"pid":3202,"name":"景宁畲族自治县"},{"id":3209,"pid":3202,"name":"庆元县"},{"id":3210,"pid":3202,"name":"莲都区"},{"id":3211,"pid":3202,"name":"遂昌县"},{"id":3212,"pid":3146,"name":"嘉兴市"},{"id":3213,"pid":3212,"name":"桐乡市"},{"id":3214,"pid":3212,"name":"嘉善县"},{"id":3215,"pid":3212,"name":"南湖区"},{"id":3216,"pid":3212,"name":"秀洲区"},{"id":3217,"pid":3212,"name":"海宁市"},{"id":3218,"pid":3212,"name":"平湖市"},{"id":3219,"pid":3212,"name":"海盐县"},{"id":3220,"pid":3146,"name":"衢州市"},{"id":3221,"pid":3220,"name":"衢江区"},{"id":3222,"pid":3220,"name":"江山市"},{"id":3223,"pid":3220,"name":"龙游县"},{"id":3224,"pid":3220,"name":"开化县"},{"id":3225,"pid":3220,"name":"柯城区"},{"id":3226,"pid":3220,"name":"常山县"},{"id":3227,"pid":3146,"name":"绍兴市"},{"id":3228,"pid":3227,"name":"上虞区"},{"id":3229,"pid":3227,"name":"嵊州市"},{"id":3230,"pid":3227,"name":"柯桥区"},{"id":3231,"pid":3227,"name":"越城区"},{"id":3232,"pid":3227,"name":"诸暨市"},{"id":3233,"pid":3227,"name":"新昌县"},{"id":3234,"pid":3146,"name":"杭州市"},{"id":3235,"pid":3234,"name":"淳安县"},{"id":3236,"pid":3234,"name":"江干区"},{"id":3237,"pid":3234,"name":"萧山区"},{"id":3238,"pid":3234,"name":"桐庐县"},{"id":3239,"pid":3234,"name":"滨江区"},{"id":3240,"pid":3234,"name":"余杭区"},{"id":3241,"pid":3234,"name":"西湖区"},{"id":3242,"pid":3234,"name":"建德市"},{"id":3243,"pid":3234,"name":"拱墅区"},{"id":3244,"pid":3234,"name":"下城区"},{"id":3245,"pid":3234,"name":"富阳区"},{"id":3246,"pid":3234,"name":"上城区"},{"id":3247,"pid":3234,"name":"临安市"},{"id":3248,"pid":1,"name":"云南"},{"id":3249,"pid":3248,"name":"楚雄彝族自治州"},{"id":3250,"pid":3249,"name":"禄丰县"},{"id":3251,"pid":3249,"name":"大姚县"},{"id":3252,"pid":3249,"name":"元谋县"},{"id":3253,"pid":3249,"name":"武定县"},{"id":3254,"pid":3249,"name":"楚雄市"},{"id":3255,"pid":3249,"name":"永仁县"},{"id":3256,"pid":3249,"name":"双柏县"},{"id":3257,"pid":3249,"name":"南华县"},{"id":3258,"pid":3249,"name":"牟定县"},{"id":3259,"pid":3249,"name":"姚安县"},{"id":3260,"pid":3248,"name":"怒江傈僳族自治州"},{"id":3261,"pid":3260,"name":"兰坪白族普米族自治县"},{"id":3262,"pid":3260,"name":"福贡县"},{"id":3263,"pid":3260,"name":"泸水县"},{"id":3264,"pid":3260,"name":"贡山独龙族怒族自治县"},{"id":3265,"pid":3248,"name":"昭通市"},{"id":3266,"pid":3265,"name":"镇雄县"},{"id":3267,"pid":3265,"name":"盐津县"},{"id":3268,"pid":3265,"name":"鲁甸县"},{"id":3269,"pid":3265,"name":"永善县"},{"id":3270,"pid":3265,"name":"威信县"},{"id":3271,"pid":3265,"name":"昭阳区"},{"id":3272,"pid":3265,"name":"水富县"},{"id":3273,"pid":3265,"name":"巧家县"},{"id":3274,"pid":3265,"name":"大关县"},{"id":3275,"pid":3265,"name":"彝良县"},{"id":3276,"pid":3265,"name":"绥江县"},{"id":3277,"pid":3248,"name":"迪庆藏族自治州"},{"id":3278,"pid":3277,"name":"德钦县"},{"id":3279,"pid":3277,"name":"香格里拉市"},{"id":3280,"pid":3277,"name":"维西傈僳族自治县"},{"id":3281,"pid":3248,"name":"德宏傣族景颇族自治州"},{"id":3282,"pid":3281,"name":"芒市"},{"id":3283,"pid":3281,"name":"盈江县"},{"id":3284,"pid":3281,"name":"陇川县"},{"id":3285,"pid":3281,"name":"梁河县"},{"id":3286,"pid":3281,"name":"瑞丽市"},{"id":3287,"pid":3248,"name":"曲靖市"},{"id":3288,"pid":3287,"name":"陆良县"},{"id":3289,"pid":3287,"name":"马龙县"},{"id":3290,"pid":3287,"name":"沾益县"},{"id":3291,"pid":3287,"name":"宣威市"},{"id":3292,"pid":3287,"name":"罗平县"},{"id":3293,"pid":3287,"name":"会泽县"},{"id":3294,"pid":3287,"name":"麒麟区"},{"id":3295,"pid":3287,"name":"师宗县"},{"id":3296,"pid":3287,"name":"富源县"},{"id":3297,"pid":3248,"name":"文山壮族苗族自治州"},{"id":3298,"pid":3297,"name":"文山市"},{"id":3299,"pid":3297,"name":"麻栗坡县"},{"id":3300,"pid":3297,"name":"马关县"},{"id":3301,"pid":3297,"name":"砚山县"},{"id":3302,"pid":3297,"name":"西畴县"},{"id":3303,"pid":3297,"name":"广南县"},{"id":3304,"pid":3297,"name":"富宁县"},{"id":3305,"pid":3297,"name":"丘北县"},{"id":3306,"pid":3248,"name":"昆明市"},{"id":3307,"pid":3306,"name":"晋宁县"},{"id":3308,"pid":3306,"name":"宜良县"},{"id":3309,"pid":3306,"name":"石林彝族自治县"},{"id":3310,"pid":3306,"name":"禄劝彝族苗族自治县"},{"id":3311,"pid":3306,"name":"西山区"},{"id":3312,"pid":3306,"name":"盘龙区"},{"id":3313,"pid":3306,"name":"东川区"},{"id":3314,"pid":3306,"name":"安宁市"},{"id":3315,"pid":3306,"name":"寻甸回族彝族自治县"},{"id":3316,"pid":3306,"name":"呈贡区"},{"id":3317,"pid":3306,"name":"五华区"},{"id":3318,"pid":3306,"name":"嵩明县"},{"id":3319,"pid":3306,"name":"官渡区"},{"id":3320,"pid":3306,"name":"富民县"},{"id":3321,"pid":3248,"name":"红河哈尼族彝族自治州"},{"id":3322,"pid":3321,"name":"红河县"},{"id":3323,"pid":3321,"name":"屏边苗族自治县"},{"id":3324,"pid":3321,"name":"元阳县"},{"id":3325,"pid":3321,"name":"石屏县"},{"id":3326,"pid":3321,"name":"蒙自市"},{"id":3327,"pid":3321,"name":"开远市"},{"id":3328,"pid":3321,"name":"绿春县"},{"id":3329,"pid":3321,"name":"河口瑶族自治县"},{"id":3330,"pid":3321,"name":"泸西县"},{"id":3331,"pid":3321,"name":"建水县"},{"id":3332,"pid":3321,"name":"个旧市"},{"id":3333,"pid":3321,"name":"弥勒市"},{"id":3334,"pid":3321,"name":"金平苗族瑶族傣族自治县"},{"id":3335,"pid":3248,"name":"普洱市"},{"id":3336,"pid":3335,"name":"江城哈尼族彝族自治县"},{"id":3337,"pid":3335,"name":"宁洱哈尼族彝族自治县"},{"id":3338,"pid":3335,"name":"墨江哈尼族自治县"},{"id":3339,"pid":3335,"name":"景东彝族自治县"},{"id":3340,"pid":3335,"name":"镇沅彝族哈尼族拉祜族自治县"},{"id":3341,"pid":3335,"name":"思茅区"},{"id":3342,"pid":3335,"name":"景谷傣族彝族自治县"},{"id":3343,"pid":3335,"name":"孟连傣族拉祜族佤族自治县"},{"id":3344,"pid":3335,"name":"澜沧拉祜族自治县"},{"id":3345,"pid":3335,"name":"西盟佤族自治县"},{"id":3346,"pid":3248,"name":"丽江市"},{"id":3347,"pid":3346,"name":"华坪县"},{"id":3348,"pid":3346,"name":"宁蒗彝族自治县"},{"id":3349,"pid":3346,"name":"古城区"},{"id":3350,"pid":3346,"name":"玉龙纳西族自治县"},{"id":3351,"pid":3346,"name":"永胜县"},{"id":3352,"pid":3248,"name":"西双版纳傣族自治州"},{"id":3353,"pid":3352,"name":"勐腊县"},{"id":3354,"pid":3352,"name":"景洪市"},{"id":3355,"pid":3352,"name":"勐海县"},{"id":3356,"pid":3248,"name":"保山市"},{"id":3357,"pid":3356,"name":"昌宁县"},{"id":3358,"pid":3356,"name":"施甸县"},{"id":3359,"pid":3356,"name":"隆阳区"},{"id":3360,"pid":3356,"name":"龙陵县"},{"id":3361,"pid":3356,"name":"腾冲市"},{"id":3362,"pid":3248,"name":"大理白族自治州"},{"id":3363,"pid":3362,"name":"弥渡县"},{"id":3364,"pid":3362,"name":"南涧彝族自治县"},{"id":3365,"pid":3362,"name":"祥云县"},{"id":3366,"pid":3362,"name":"剑川县"},{"id":3367,"pid":3362,"name":"鹤庆县"},{"id":3368,"pid":3362,"name":"宾川县"},{"id":3369,"pid":3362,"name":"漾濞彝族自治县"},{"id":3370,"pid":3362,"name":"巍山彝族回族自治县"},{"id":3371,"pid":3362,"name":"永平县"},{"id":3372,"pid":3362,"name":"洱源县"},{"id":3373,"pid":3362,"name":"云龙县"},{"id":3374,"pid":3362,"name":"大理市"},{"id":3375,"pid":3248,"name":"临沧市"},{"id":3376,"pid":3375,"name":"凤庆县"},{"id":3377,"pid":3375,"name":"永德县"},{"id":3378,"pid":3375,"name":"镇康县"},{"id":3379,"pid":3375,"name":"沧源佤族自治县"},{"id":3380,"pid":3375,"name":"云县"},{"id":3381,"pid":3375,"name":"耿马傣族佤族自治县"},{"id":3382,"pid":3375,"name":"双江拉祜族佤族布朗族傣族自治县"},{"id":3383,"pid":3375,"name":"临翔区"},{"id":3384,"pid":3248,"name":"玉溪市"},{"id":3385,"pid":3384,"name":"峨山彝族自治县"},{"id":3386,"pid":3384,"name":"澄江县"},{"id":3387,"pid":3384,"name":"新平彝族傣族自治县"},{"id":3388,"pid":3384,"name":"通海县"},{"id":3389,"pid":3384,"name":"华宁县"},{"id":3390,"pid":3384,"name":"易门县"},{"id":3391,"pid":3384,"name":"元江哈尼族彝族傣族自治县"},{"id":3392,"pid":3384,"name":"红塔区"},{"id":3393,"pid":3384,"name":"江川区"},{"id":3394,"pid":1,"name":"内蒙古"},{"id":3395,"pid":3394,"name":"呼伦贝尔市"},{"id":3396,"pid":3395,"name":"额尔古纳市"},{"id":3397,"pid":3395,"name":"新巴尔虎右旗"},{"id":3398,"pid":3395,"name":"莫力达瓦达斡尔族自治旗"},{"id":3399,"pid":3395,"name":"陈巴尔虎旗"},{"id":3400,"pid":3395,"name":"新巴尔虎左旗"},{"id":3401,"pid":3395,"name":"鄂温克族自治旗"},{"id":3402,"pid":3395,"name":"鄂伦春自治旗"},{"id":3403,"pid":3395,"name":"满洲里市"},{"id":3404,"pid":3395,"name":"阿荣旗"},{"id":3405,"pid":3395,"name":"海拉尔区"},{"id":3406,"pid":3395,"name":"扎兰屯市"},{"id":3407,"pid":3395,"name":"扎赉诺尔区"},{"id":3408,"pid":3395,"name":"牙克石市"},{"id":3409,"pid":3395,"name":"根河市"},{"id":3410,"pid":3394,"name":"包头市"},{"id":3411,"pid":3410,"name":"东河区"},{"id":3412,"pid":3410,"name":"石拐区"},{"id":3413,"pid":3410,"name":"青山区"},{"id":3414,"pid":3410,"name":"九原区"},{"id":3415,"pid":3410,"name":"白云鄂博矿区"},{"id":3416,"pid":3410,"name":"昆都仑区"},{"id":3417,"pid":3410,"name":"土默特右旗"},{"id":3418,"pid":3410,"name":"达尔罕茂明安联合旗"},{"id":3419,"pid":3410,"name":"固阳县"},{"id":3420,"pid":3394,"name":"通辽市"},{"id":3421,"pid":3420,"name":"科尔沁左翼中旗"},{"id":3422,"pid":3420,"name":"霍林郭勒市"},{"id":3423,"pid":3420,"name":"扎鲁特旗"},{"id":3424,"pid":3420,"name":"开鲁县"},{"id":3425,"pid":3420,"name":"库伦旗"},{"id":3426,"pid":3420,"name":"科尔沁区"},{"id":3427,"pid":3420,"name":"科尔沁左翼后旗"},{"id":3428,"pid":3420,"name":"奈曼旗"},{"id":3429,"pid":3394,"name":"呼和浩特市"},{"id":3430,"pid":3429,"name":"赛罕区"},{"id":3431,"pid":3429,"name":"新城区"},{"id":3432,"pid":3429,"name":"回民区"},{"id":3433,"pid":3429,"name":"玉泉区"},{"id":3434,"pid":3429,"name":"武川县"},{"id":3435,"pid":3429,"name":"和林格尔县"},{"id":3436,"pid":3429,"name":"托克托县"},{"id":3437,"pid":3429,"name":"清水河县"},{"id":3438,"pid":3429,"name":"土默特左旗"},{"id":3439,"pid":3394,"name":"乌海市"},{"id":3440,"pid":3439,"name":"海勃湾区"},{"id":3441,"pid":3439,"name":"海南区"},{"id":3442,"pid":3439,"name":"乌达区"},{"id":3443,"pid":3394,"name":"锡林郭勒盟"},{"id":3444,"pid":3443,"name":"锡林浩特市"},{"id":3445,"pid":3443,"name":"太仆寺旗"},{"id":3446,"pid":3443,"name":"苏尼特左旗"},{"id":3447,"pid":3443,"name":"西乌珠穆沁旗"},{"id":3448,"pid":3443,"name":"阿巴嘎旗"},{"id":3449,"pid":3443,"name":"东乌珠穆沁旗"},{"id":3450,"pid":3443,"name":"苏尼特右旗"},{"id":3451,"pid":3443,"name":"多伦县"},{"id":3452,"pid":3443,"name":"二连浩特市"},{"id":3453,"pid":3443,"name":"镶黄旗"},{"id":3454,"pid":3443,"name":"正镶白旗"},{"id":3455,"pid":3443,"name":"正蓝旗"},{"id":3456,"pid":3394,"name":"兴安盟"},{"id":3457,"pid":3456,"name":"阿尔山市"},{"id":3458,"pid":3456,"name":"乌兰浩特市"},{"id":3459,"pid":3456,"name":"科尔沁右翼中旗"},{"id":3460,"pid":3456,"name":"扎赉特旗"},{"id":3461,"pid":3456,"name":"科尔沁右翼前旗"},{"id":3462,"pid":3456,"name":"突泉县"},{"id":3463,"pid":3394,"name":"赤峰市"},{"id":3464,"pid":3463,"name":"元宝山区"},{"id":3465,"pid":3463,"name":"宁城县"},{"id":3466,"pid":3463,"name":"克什克腾旗"},{"id":3467,"pid":3463,"name":"喀喇沁旗"},{"id":3468,"pid":3463,"name":"林西县"},{"id":3469,"pid":3463,"name":"巴林左旗"},{"id":3470,"pid":3463,"name":"巴林右旗"},{"id":3471,"pid":3463,"name":"翁牛特旗"},{"id":3472,"pid":3463,"name":"松山区"},{"id":3473,"pid":3463,"name":"阿鲁科尔沁旗"},{"id":3474,"pid":3463,"name":"红山区"},{"id":3475,"pid":3463,"name":"敖汉旗"},{"id":3476,"pid":3394,"name":"鄂尔多斯市"},{"id":3477,"pid":3476,"name":"达拉特旗"},{"id":3478,"pid":3476,"name":"鄂托克前旗"},{"id":3479,"pid":3476,"name":"乌审旗"},{"id":3480,"pid":3476,"name":"鄂托克旗"},{"id":3481,"pid":3476,"name":"准格尔旗"},{"id":3482,"pid":3476,"name":"杭锦旗"},{"id":3483,"pid":3476,"name":"伊金霍洛旗"},{"id":3484,"pid":3476,"name":"东胜区"},{"id":3485,"pid":3394,"name":"乌兰察布市"},{"id":3486,"pid":3485,"name":"四子王旗"},{"id":3487,"pid":3485,"name":"卓资县"},{"id":3488,"pid":3485,"name":"察哈尔右翼中旗"},{"id":3489,"pid":3485,"name":"察哈尔右翼前旗"},{"id":3490,"pid":3485,"name":"察哈尔右翼后旗"},{"id":3491,"pid":3485,"name":"凉城县"},{"id":3492,"pid":3485,"name":"商都县"},{"id":3493,"pid":3485,"name":"兴和县"},{"id":3494,"pid":3485,"name":"丰镇市"},{"id":3495,"pid":3485,"name":"化德县"},{"id":3496,"pid":3485,"name":"集宁区"},{"id":3497,"pid":3394,"name":"阿拉善盟"},{"id":3498,"pid":3497,"name":"阿拉善左旗"},{"id":3499,"pid":3497,"name":"额济纳旗"},{"id":3500,"pid":3497,"name":"阿拉善右旗"},{"id":3501,"pid":3394,"name":"巴彦淖尔市"},{"id":3502,"pid":3501,"name":"磴口县"},{"id":3503,"pid":3501,"name":"乌拉特中旗"},{"id":3504,"pid":3501,"name":"五原县"},{"id":3505,"pid":3501,"name":"临河区"},{"id":3506,"pid":3501,"name":"杭锦后旗"},{"id":3507,"pid":3501,"name":"乌拉特后旗"},{"id":3508,"pid":3501,"name":"乌拉特前旗"},{"id":3509,"pid":1,"name":"辽宁"},{"id":3510,"pid":3509,"name":"辽阳市"},{"id":3511,"pid":3510,"name":"太子河区"},{"id":3512,"pid":3510,"name":"白塔区"},{"id":3513,"pid":3510,"name":"文圣区"},{"id":3514,"pid":3510,"name":"辽阳县"},{"id":3515,"pid":3510,"name":"宏伟区"},{"id":3516,"pid":3510,"name":"灯塔市"},{"id":3517,"pid":3510,"name":"弓长岭区"},{"id":3518,"pid":3509,"name":"盘锦市"},{"id":3519,"pid":3518,"name":"双台子区"},{"id":3520,"pid":3518,"name":"大洼县"},{"id":3521,"pid":3518,"name":"兴隆台区"},{"id":3522,"pid":3518,"name":"盘山县"},{"id":3523,"pid":3509,"name":"葫芦岛市"},{"id":3524,"pid":3523,"name":"龙港区"},{"id":3525,"pid":3523,"name":"连山区"},{"id":3526,"pid":3523,"name":"绥中县"},{"id":3527,"pid":3523,"name":"兴城市"},{"id":3528,"pid":3523,"name":"建昌县"},{"id":3529,"pid":3523,"name":"南票区"},{"id":3530,"pid":3509,"name":"抚顺市"},{"id":3531,"pid":3530,"name":"顺城区"},{"id":3532,"pid":3530,"name":"东洲区"},{"id":3533,"pid":3530,"name":"望花区"},{"id":3534,"pid":3530,"name":"新抚区"},{"id":3535,"pid":3530,"name":"新宾满族自治县"},{"id":3536,"pid":3530,"name":"清原满族自治县"},{"id":3537,"pid":3530,"name":"抚顺县"},{"id":3538,"pid":3509,"name":"大连市"},{"id":3539,"pid":3538,"name":"沙河口区"},{"id":3540,"pid":3538,"name":"金州区"},{"id":3541,"pid":3538,"name":"庄河市"},{"id":3542,"pid":3538,"name":"瓦房店市"},{"id":3543,"pid":3538,"name":"旅顺口区"},{"id":3544,"pid":3538,"name":"中山区"},{"id":3545,"pid":3538,"name":"普兰店区"},{"id":3546,"pid":3538,"name":"长海县"},{"id":3547,"pid":3538,"name":"甘井子区"},{"id":3548,"pid":3538,"name":"西岗区"},{"id":3549,"pid":3509,"name":"阜新市"},{"id":3550,"pid":3549,"name":"细河区"},{"id":3551,"pid":3549,"name":"海州区"},{"id":3552,"pid":3549,"name":"新邱区"},{"id":3553,"pid":3549,"name":"彰武县"},{"id":3554,"pid":3549,"name":"阜新蒙古族自治县"},{"id":3555,"pid":3549,"name":"太平区"},{"id":3556,"pid":3549,"name":"清河门区"},{"id":3557,"pid":3509,"name":"铁岭市"},{"id":3558,"pid":3557,"name":"调兵山市"},{"id":3559,"pid":3557,"name":"西丰县"},{"id":3560,"pid":3557,"name":"昌图县"},{"id":3561,"pid":3557,"name":"清河区"},{"id":3562,"pid":3557,"name":"银州区"},{"id":3563,"pid":3557,"name":"铁岭县"},{"id":3564,"pid":3557,"name":"开原市"},{"id":3565,"pid":3509,"name":"丹东市"},{"id":3566,"pid":3565,"name":"凤城市"},{"id":3567,"pid":3565,"name":"宽甸满族自治县"},{"id":3568,"pid":3565,"name":"振兴区"},{"id":3569,"pid":3565,"name":"元宝区"},{"id":3570,"pid":3565,"name":"东港市"},{"id":3571,"pid":3565,"name":"振安区"},{"id":3572,"pid":3509,"name":"锦州市"},{"id":3573,"pid":3572,"name":"黑山县"},{"id":3574,"pid":3572,"name":"太和区"},{"id":3575,"pid":3572,"name":"凌河区"},{"id":3576,"pid":3572,"name":"凌海市"},{"id":3577,"pid":3572,"name":"北镇市"},{"id":3578,"pid":3572,"name":"古塔区"},{"id":3579,"pid":3572,"name":"义县"},{"id":3580,"pid":3509,"name":"本溪市"},{"id":3581,"pid":3580,"name":"平山区"},{"id":3582,"pid":3580,"name":"溪湖区"},{"id":3583,"pid":3580,"name":"桓仁满族自治县"},{"id":3584,"pid":3580,"name":"本溪满族自治县"},{"id":3585,"pid":3580,"name":"明山区"},{"id":3586,"pid":3580,"name":"南芬区"},{"id":3587,"pid":3509,"name":"朝阳市"},{"id":3588,"pid":3587,"name":"建平县"},{"id":3589,"pid":3587,"name":"双塔区"},{"id":3590,"pid":3587,"name":"龙城区"},{"id":3591,"pid":3587,"name":"北票市"},{"id":3592,"pid":3587,"name":"喀喇沁左翼蒙古族自治县"},{"id":3593,"pid":3587,"name":"朝阳县"},{"id":3594,"pid":3587,"name":"凌源市"},{"id":3595,"pid":3509,"name":"鞍山市"},{"id":3596,"pid":3595,"name":"台安县"},{"id":3597,"pid":3595,"name":"铁西区"},{"id":3598,"pid":3595,"name":"铁东区"},{"id":3599,"pid":3595,"name":"千山区"},{"id":3600,"pid":3595,"name":"岫岩满族自治县"},{"id":3601,"pid":3595,"name":"立山区"},{"id":3602,"pid":3595,"name":"海城市"},{"id":3603,"pid":3509,"name":"沈阳市"},{"id":3604,"pid":3603,"name":"铁西区"},{"id":3605,"pid":3603,"name":"沈北新区"},{"id":3606,"pid":3603,"name":"法库县"},{"id":3607,"pid":3603,"name":"苏家屯区"},{"id":3608,"pid":3603,"name":"于洪区"},{"id":3609,"pid":3603,"name":"新民市"},{"id":3610,"pid":3603,"name":"辽中县"},{"id":3611,"pid":3603,"name":"沈河区"},{"id":3612,"pid":3603,"name":"康平县"},{"id":3613,"pid":3603,"name":"浑南区"},{"id":3614,"pid":3603,"name":"皇姑区"},{"id":3615,"pid":3603,"name":"和平区"},{"id":3616,"pid":3603,"name":"大东区"},{"id":3617,"pid":3509,"name":"营口市"},{"id":3618,"pid":3617,"name":"老边区"},{"id":3619,"pid":3617,"name":"站前区"},{"id":3620,"pid":3617,"name":"盖州市"},{"id":3621,"pid":3617,"name":"鲅鱼圈区"},{"id":3622,"pid":3617,"name":"西市区"},{"id":3623,"pid":3617,"name":"大石桥市"},{"id":3624,"pid":1,"name":"广东"},{"id":3625,"pid":3624,"name":"河源市"},{"id":3626,"pid":3625,"name":"和平县"},{"id":3627,"pid":3625,"name":"源城区"},{"id":3628,"pid":3625,"name":"东源县"},{"id":3629,"pid":3625,"name":"龙川县"},{"id":3630,"pid":3625,"name":"连平县"},{"id":3631,"pid":3625,"name":"紫金县"},{"id":3632,"pid":3624,"name":"韶关市"},{"id":3633,"pid":3632,"name":"武江区"},{"id":3634,"pid":3632,"name":"曲江区"},{"id":3635,"pid":3632,"name":"乳源瑶族自治县"},{"id":3636,"pid":3632,"name":"浈江区"},{"id":3637,"pid":3632,"name":"乐昌市"},{"id":3638,"pid":3632,"name":"仁化县"},{"id":3639,"pid":3632,"name":"新丰县"},{"id":3640,"pid":3632,"name":"始兴县"},{"id":3641,"pid":3632,"name":"翁源县"},{"id":3642,"pid":3632,"name":"南雄市"},{"id":3643,"pid":3624,"name":"茂名市"},{"id":3644,"pid":3643,"name":"信宜市"},{"id":3645,"pid":3643,"name":"茂南区"},{"id":3646,"pid":3643,"name":"电白区"},{"id":3647,"pid":3643,"name":"化州市"},{"id":3648,"pid":3643,"name":"高州市"},{"id":3649,"pid":3624,"name":"汕头市"},{"id":3650,"pid":3649,"name":"潮阳区"},{"id":3651,"pid":3649,"name":"南澳县"},{"id":3652,"pid":3649,"name":"金平区"},{"id":3653,"pid":3649,"name":"澄海区"},{"id":3654,"pid":3649,"name":"龙湖区"},{"id":3655,"pid":3649,"name":"濠江区"},{"id":3656,"pid":3649,"name":"潮南区"},{"id":3657,"pid":3624,"name":"清远市"},{"id":3658,"pid":3657,"name":"连州市"},{"id":3659,"pid":3657,"name":"清城区"},{"id":3660,"pid":3657,"name":"清新区"},{"id":3661,"pid":3657,"name":"佛冈县"},{"id":3662,"pid":3657,"name":"英德市"},{"id":3663,"pid":3657,"name":"连山壮族瑶族自治县"},{"id":3664,"pid":3657,"name":"阳山县"},{"id":3665,"pid":3657,"name":"连南瑶族自治县"},{"id":3666,"pid":3624,"name":"深圳市"},{"id":3667,"pid":3666,"name":"罗湖区"},{"id":3668,"pid":3666,"name":"南山区"},{"id":3669,"pid":3666,"name":"盐田区"},{"id":3670,"pid":3666,"name":"宝安区"},{"id":3671,"pid":3666,"name":"龙岗区"},{"id":3672,"pid":3666,"name":"福田区"},{"id":3673,"pid":3624,"name":"珠海市"},{"id":3674,"pid":3673,"name":"斗门区"},{"id":3675,"pid":3673,"name":"金湾区"},{"id":3676,"pid":3673,"name":"香洲区"},{"id":3677,"pid":3624,"name":"广州市"},{"id":3678,"pid":3677,"name":"白云区"},{"id":3679,"pid":3677,"name":"从化区"},{"id":3680,"pid":3677,"name":"花都区"},{"id":3681,"pid":3677,"name":"黄埔区"},{"id":3682,"pid":3677,"name":"越秀区"},{"id":3683,"pid":3677,"name":"海珠区"},{"id":3684,"pid":3677,"name":"荔湾区"},{"id":3685,"pid":3677,"name":"天河区"},{"id":3686,"pid":3677,"name":"番禺区"},{"id":3687,"pid":3677,"name":"增城区"},{"id":3688,"pid":3677,"name":"南沙区"},{"id":3689,"pid":3624,"name":"肇庆市"},{"id":3690,"pid":3689,"name":"鼎湖区"},{"id":3691,"pid":3689,"name":"端州区"},{"id":3692,"pid":3689,"name":"德庆县"},{"id":3693,"pid":3689,"name":"广宁县"},{"id":3694,"pid":3689,"name":"怀集县"},{"id":3695,"pid":3689,"name":"封开县"},{"id":3696,"pid":3689,"name":"高要区"},{"id":3697,"pid":3689,"name":"四会市"},{"id":3698,"pid":3624,"name":"中山市"},{"id":3699,"pid":3698,"name":"五桂山街道"},{"id":3700,"pid":3698,"name":"三乡镇"},{"id":3701,"pid":3698,"name":"南朗镇"},{"id":3702,"pid":3698,"name":"三角镇"},{"id":3703,"pid":3698,"name":"古镇镇"},{"id":3704,"pid":3698,"name":"阜沙镇"},{"id":3705,"pid":3698,"name":"坦洲镇"},{"id":3706,"pid":3698,"name":"南头镇"},{"id":3707,"pid":3698,"name":"中山港街道"},{"id":3708,"pid":3698,"name":"东凤镇"},{"id":3709,"pid":3698,"name":"东区街道"},{"id":3710,"pid":3698,"name":"神湾镇"},{"id":3711,"pid":3698,"name":"石岐区街道"},{"id":3712,"pid":3698,"name":"东升镇"},{"id":3713,"pid":3698,"name":"沙溪镇"},{"id":3714,"pid":3698,"name":"南区街道"},{"id":3715,"pid":3698,"name":"小榄镇"},{"id":3716,"pid":3698,"name":"黄圃镇"},{"id":3717,"pid":3698,"name":"横栏镇"},{"id":3718,"pid":3698,"name":"板芙镇"},{"id":3719,"pid":3698,"name":"港口镇"},{"id":3720,"pid":3698,"name":"西区街道"},{"id":3721,"pid":3698,"name":"民众镇"},{"id":3722,"pid":3698,"name":"大涌镇"},{"id":3723,"pid":3624,"name":"江门市"},{"id":3724,"pid":3723,"name":"江海区"},{"id":3725,"pid":3723,"name":"蓬江区"},{"id":3726,"pid":3723,"name":"新会区"},{"id":3727,"pid":3723,"name":"台山市"},{"id":3728,"pid":3723,"name":"鹤山市"},{"id":3729,"pid":3723,"name":"恩平市"},{"id":3730,"pid":3723,"name":"开平市"},{"id":3731,"pid":3624,"name":"云浮市"},{"id":3732,"pid":3731,"name":"云安区"},{"id":3733,"pid":3731,"name":"郁南县"},{"id":3734,"pid":3731,"name":"罗定市"},{"id":3735,"pid":3731,"name":"云城区"},{"id":3736,"pid":3731,"name":"新兴县"},{"id":3737,"pid":3624,"name":"惠州市"},{"id":3738,"pid":3737,"name":"惠东县"},{"id":3739,"pid":3737,"name":"惠阳区"},{"id":3740,"pid":3737,"name":"龙门县"},{"id":3741,"pid":3737,"name":"惠城区"},{"id":3742,"pid":3737,"name":"博罗县"},{"id":3743,"pid":3624,"name":"揭阳市"},{"id":3744,"pid":3743,"name":"惠来县"},{"id":3745,"pid":3743,"name":"普宁市"},{"id":3746,"pid":3743,"name":"揭西县"},{"id":3747,"pid":3743,"name":"榕城区"},{"id":3748,"pid":3743,"name":"揭东区"},{"id":3749,"pid":3624,"name":"东莞市"},{"id":3750,"pid":3749,"name":"常平镇"},{"id":3751,"pid":3749,"name":"企石镇"},{"id":3752,"pid":3749,"name":"东坑镇"},{"id":3753,"pid":3749,"name":"中堂镇"},{"id":3754,"pid":3749,"name":"清溪镇"},{"id":3755,"pid":3749,"name":"望牛墩镇"},{"id":3756,"pid":3749,"name":"凤岗镇"},{"id":3757,"pid":3749,"name":"南城街道"},{"id":3758,"pid":3749,"name":"东城街道"},{"id":3759,"pid":3749,"name":"茶山镇"},{"id":3760,"pid":3749,"name":"沙田镇"},{"id":3761,"pid":3749,"name":"寮步镇"},{"id":3762,"pid":3749,"name":"石龙镇"},{"id":3763,"pid":3749,"name":"麻涌镇"},{"id":3764,"pid":3749,"name":"厚街镇"},{"id":3765,"pid":3749,"name":"长安镇"},{"id":3766,"pid":3749,"name":"莞城街道"},{"id":3767,"pid":3749,"name":"石排镇"},{"id":3768,"pid":3749,"name":"石碣镇"},{"id":3769,"pid":3749,"name":"虎门镇"},{"id":3770,"pid":3749,"name":"道滘镇"},{"id":3771,"pid":3749,"name":"桥头镇"},{"id":3772,"pid":3749,"name":"谢岗镇"},{"id":3773,"pid":3749,"name":"洪梅镇"},{"id":3774,"pid":3749,"name":"大朗镇"},{"id":3775,"pid":3749,"name":"黄江镇"},{"id":3776,"pid":3749,"name":"塘厦镇"},{"id":3777,"pid":3749,"name":"横沥镇"},{"id":3778,"pid":3749,"name":"樟木头镇"},{"id":3779,"pid":3749,"name":"大岭山镇"},{"id":3780,"pid":3749,"name":"万江街道"},{"id":3781,"pid":3749,"name":"高埗镇"},{"id":3782,"pid":3624,"name":"湛江市"},{"id":3783,"pid":3782,"name":"坡头区"},{"id":3784,"pid":3782,"name":"霞山区"},{"id":3785,"pid":3782,"name":"麻章区"},{"id":3786,"pid":3782,"name":"雷州市"},{"id":3787,"pid":3782,"name":"遂溪县"},{"id":3788,"pid":3782,"name":"赤坎区"},{"id":3789,"pid":3782,"name":"廉江市"},{"id":3790,"pid":3782,"name":"徐闻县"},{"id":3791,"pid":3782,"name":"吴川市"},{"id":3792,"pid":3624,"name":"阳江市"},{"id":3793,"pid":3792,"name":"阳春市"},{"id":3794,"pid":3792,"name":"阳西县"},{"id":3795,"pid":3792,"name":"江城区"},{"id":3796,"pid":3792,"name":"阳东区"},{"id":3797,"pid":3624,"name":"佛山市"},{"id":3798,"pid":3797,"name":"禅城区"},{"id":3799,"pid":3797,"name":"顺德区"},{"id":3800,"pid":3797,"name":"高明区"},{"id":3801,"pid":3797,"name":"南海区"},{"id":3802,"pid":3797,"name":"三水区"},{"id":3803,"pid":3624,"name":"汕尾市"},{"id":3804,"pid":3803,"name":"海丰县"},{"id":3805,"pid":3803,"name":"陆河县"},{"id":3806,"pid":3803,"name":"陆丰市"},{"id":3807,"pid":3803,"name":"城区"},{"id":3808,"pid":3624,"name":"潮州市"},{"id":3809,"pid":3808,"name":"潮安区"},{"id":3810,"pid":3808,"name":"湘桥区"},{"id":3811,"pid":3808,"name":"饶平县"},{"id":3812,"pid":3624,"name":"梅州市"},{"id":3813,"pid":3812,"name":"梅县区"},{"id":3814,"pid":3812,"name":"平远县"},{"id":3815,"pid":3812,"name":"蕉岭县"},{"id":3816,"pid":3812,"name":"五华县"},{"id":3817,"pid":3812,"name":"梅江区"},{"id":3818,"pid":3812,"name":"兴宁市"},{"id":3819,"pid":3812,"name":"大埔县"},{"id":3820,"pid":3812,"name":"丰顺县"},{"id":3821,"pid":1,"name":"青海"},{"id":3822,"pid":3821,"name":"海南藏族自治州"},{"id":3823,"pid":3822,"name":"贵德县"},{"id":3824,"pid":3822,"name":"贵南县"},{"id":3825,"pid":3822,"name":"同德县"},{"id":3826,"pid":3822,"name":"兴海县"},{"id":3827,"pid":3822,"name":"共和县"},{"id":3828,"pid":3821,"name":"果洛藏族自治州"},{"id":3829,"pid":3828,"name":"班玛县"},{"id":3830,"pid":3828,"name":"达日县"},{"id":3831,"pid":3828,"name":"甘德县"},{"id":3832,"pid":3828,"name":"玛沁县"},{"id":3833,"pid":3828,"name":"久治县"},{"id":3834,"pid":3828,"name":"玛多县"},{"id":3835,"pid":3821,"name":"海东市"},{"id":3836,"pid":3835,"name":"互助土族自治县"},{"id":3837,"pid":3835,"name":"平安区"},{"id":3838,"pid":3835,"name":"循化撒拉族自治县"},{"id":3839,"pid":3835,"name":"乐都区"},{"id":3840,"pid":3835,"name":"化隆回族自治县"},{"id":3841,"pid":3835,"name":"民和回族土族自治县"},{"id":3842,"pid":3821,"name":"黄南藏族自治州"},{"id":3843,"pid":3842,"name":"尖扎县"},{"id":3844,"pid":3842,"name":"河南蒙古族自治县"},{"id":3845,"pid":3842,"name":"泽库县"},{"id":3846,"pid":3842,"name":"同仁县"},{"id":3847,"pid":3821,"name":"海西蒙古族藏族自治州"},{"id":3848,"pid":3847,"name":"德令哈市"},{"id":3849,"pid":3847,"name":"都兰县"},{"id":3850,"pid":3847,"name":"天峻县"},{"id":3851,"pid":3847,"name":"格尔木市"},{"id":3852,"pid":3847,"name":"乌兰县"},{"id":3853,"pid":3821,"name":"玉树藏族自治州"},{"id":3854,"pid":3853,"name":"称多县"},{"id":3855,"pid":3853,"name":"治多县"},{"id":3856,"pid":3853,"name":"玉树市"},{"id":3857,"pid":3853,"name":"囊谦县"},{"id":3858,"pid":3853,"name":"曲麻莱县"},{"id":3859,"pid":3853,"name":"杂多县"},{"id":3860,"pid":3821,"name":"海北藏族自治州"},{"id":3861,"pid":3860,"name":"海晏县"},{"id":3862,"pid":3860,"name":"刚察县"},{"id":3863,"pid":3860,"name":"祁连县"},{"id":3864,"pid":3860,"name":"门源回族自治县"},{"id":3865,"pid":3821,"name":"西宁市"},{"id":3866,"pid":3865,"name":"城北区"},{"id":3867,"pid":3865,"name":"湟源县"},{"id":3868,"pid":3865,"name":"城西区"},{"id":3869,"pid":3865,"name":"大通回族土族自治县"},{"id":3870,"pid":3865,"name":"城中区"},{"id":3871,"pid":3865,"name":"湟中县"},{"id":3872,"pid":3865,"name":"城东区"},{"id":3873,"pid":1,"name":"北京"},{"id":3874,"pid":3873,"name":"北京市"},{"id":3875,"pid":3874,"name":"西城区"},{"id":3876,"pid":3874,"name":"平谷区"},{"id":3877,"pid":3874,"name":"门头沟区"},{"id":3878,"pid":3874,"name":"顺义区"},{"id":3879,"pid":3874,"name":"朝阳区"},{"id":3880,"pid":3874,"name":"怀柔区"},{"id":3881,"pid":3874,"name":"房山区"},{"id":3882,"pid":3874,"name":"丰台区"},{"id":3883,"pid":3874,"name":"大兴区"},{"id":3884,"pid":3874,"name":"密云县"},{"id":3885,"pid":3874,"name":"石景山区"},{"id":3886,"pid":3874,"name":"东城区"},{"id":3887,"pid":3874,"name":"海淀区"},{"id":3888,"pid":3874,"name":"昌平区"},{"id":3889,"pid":3874,"name":"通州区"},{"id":3890,"pid":3874,"name":"延庆县"}]

/***/ }),

/***/ "AEoA":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".page.uploadIdPhotoThree .van-picker{position:fixed;width:100%;bottom:0;z-index:100}.page.uploadIdPhotoThree .van-step--horizontal.van-step--finish .van-step__circle,.page.uploadIdPhotoThree .van-step--horizontal.van-step--finish .van-step__line{background-color:#ffe44d}.page.uploadIdPhotoThree .van-step__title{color:#ffe44d}.page.uploadIdPhotoThree .van-cell--required:before{left:-.3rem;bottom:.3rem;font-size:36px;color:#ffe44d}.page.uploadIdPhotoThree .van-cell{margin:0 auto 0 3%;border-bottom:1px solid #e8e8e8;width:97%}.page.uploadIdPhotoThree .van-button--bottom-action.van-button--primary{background-color:#ffe44d;position:fixed;bottom:0}.page.uploadIdPhotoThree .imgSize.headPortrait.van-uploader{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}", ""]);

// exports


/***/ }),

/***/ "CMvz":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "DW+B":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("+mpJ");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("7b6a0840", content, true, {});

/***/ }),

/***/ "F3Vo":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageService", function() { return PageService; });
var PageService = /** @class */function () {
    function PageService() {
        this.total = 0;
        this.pageIndex = 1;
        this.pageSize = 30;
        this.loading = false;
        this.pageSizeOpts = [10, 30, 50];
        this.layout = 'total, sizes, prev, pager, next, jumper';
    }
    /**
     * 获取分页配置信息
     */
    PageService.prototype.getConfig = function () {
        return {
            page: this.pageIndex,
            size: this.pageSize
        };
    };
    /**
     * 更新分页配置信息
     * @param param
     */
    PageService.prototype.update = function (_a) {
        var total = _a.total,
            pages = _a.pages;
        this.total = parseInt(total);
        this.totalPage = parseInt(pages);
    };
    /**
     * 重置分页数据
     */
    PageService.prototype.reset = function () {
        this.total = 0;
        this.pageIndex = 1;
        this.loading = false;
    };
    return PageService;
}();


/***/ }),

/***/ "GCoC":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".page.details .carImgs[data-v-cb370714]{height:100%;-webkit-box-sizing:border-box;box-sizing:border-box}.page.details .car-main-img[data-v-cb370714],.page.details .textCenter[data-v-cb370714]{text-align:center}.page.details .carDetails[data-v-cb370714]{border-bottom:1px solid #a9a9a9;padding:10px;font-size:12px}.page.details .carDetails .detailsOne[data-v-cb370714]{color:gray}.page.details .textDescription[data-v-cb370714]{padding:5px;border-bottom:1px solid #a9a9a9}.page.details .textDescription span[data-v-cb370714]{height:25px;line-height:25px}.page.details .textDescription .price[data-v-cb370714]{font-size:12px}.page.details .guarantee[data-v-cb370714]{font-size:13px;font-weight:600;height:25px;line-height:25px;border-bottom:1px solid #a9a9a9;color:#789;padding-left:5px}", ""]);

// exports


/***/ }),

/***/ "GDWw":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".van-picker[data-v-63c9560a]{position:fixed;width:100%;bottom:0;z-index:100}.base-info-title[data-v-63c9560a]{color:gray;padding:12px;font-size:.8rem;border-bottom:1px solid #e8e8e8}.van-cell--required[data-v-63c9560a]:before{left:-.3rem;bottom:.3rem;font-size:36px;color:#ffe44d}.van-cell[data-v-63c9560a]{margin:0 auto 0 3%;border-bottom:1px solid #e8e8e8;width:97%}.van-button--bottom-action.van-button--primary[data-v-63c9560a]{background-color:#ffe44d;position:fixed;bottom:0}", ""]);

// exports


/***/ }),

/***/ "GN+L":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("0NAA");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("45abad1c", content, true, {});

/***/ }),

/***/ "Iurx":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("8rjq");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("98f98c0c", content, true, {});

/***/ }),

/***/ "KBJM":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/vue/dist/vue.esm.js
var vue_esm = __webpack_require__("7+uW");

// EXTERNAL MODULE: ./node_modules/vue-class-component/dist/vue-class-component.common.js
var vue_class_component_common = __webpack_require__("c+8m");
var vue_class_component_common_default = /*#__PURE__*/__webpack_require__.n(vue_class_component_common);

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/object/define-property.js
var define_property = __webpack_require__("C4MV");
var define_property_default = /*#__PURE__*/__webpack_require__.n(define_property);

// EXTERNAL MODULE: ./node_modules/babel-runtime/helpers/typeof.js
var helpers_typeof = __webpack_require__("pFYg");
var typeof_default = /*#__PURE__*/__webpack_require__.n(helpers_typeof);

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/object/get-own-property-descriptor.js
var get_own_property_descriptor = __webpack_require__("K6ED");
var get_own_property_descriptor_default = /*#__PURE__*/__webpack_require__.n(get_own_property_descriptor);

// EXTERNAL MODULE: ./src/utils/net.service.ts + 7 modules
var net_service = __webpack_require__("1pVc");

// EXTERNAL MODULE: ./src/core/decorator.ts
var decorator = __webpack_require__("f3r7");

// EXTERNAL MODULE: ./src/config/server/manage-service/index.ts + 9 modules
var manage_service = __webpack_require__("afVn");

// CONCATENATED MODULE: ./src/services/manage-service/car-management.service.ts



var __decorate = this && this.__decorate || function (decorators, target, key, desc) {
    var c = arguments.length,
        r = c < 3 ? target : desc === null ? desc = get_own_property_descriptor_default()(target, key) : desc,
        d;
    if ((typeof Reflect === "undefined" ? "undefined" : typeof_default()(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
        if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    }return c > 3 && r && define_property_default()(target, key, r), r;
};



var car_management_service_carManagementService = /** @class */function () {
    function carManagementService() {}
    /**
     * 根据车辆id查询车辆属性列表
     */
    carManagementService.prototype.getCarParamList = function (carId) {
        return this.netService.send({
            server: manage_service["a" /* manageService */].carManagementController.getCarParamList,
            data: {
                carId: carId
            }
        });
    };
    /**
     * 获取车辆信息
     */
    carManagementService.prototype.getCarDetail = function (carId) {
        return this.netService.send({
            server: manage_service["a" /* manageService */].carManagementController.getCarDetail,
            data: {
                carId: carId
            }
        });
    };
    /**
     * 通过carId查找出栏目信息
     */
    carManagementService.prototype.getCarColumnCollectModel = function (carId) {
        return this.netService.send({
            server: manage_service["a" /* manageService */].carManagementController.getCarColumnCollectModel,
            data: {
                carId: carId
            }
        });
    };
    /**
     * 获取车辆详情首页图片
     */
    carManagementService.prototype.getCarPictureList = function (carId) {
        return this.netService.send({
            server: manage_service["a" /* manageService */].carManagementController.getCarPictureList,
            data: {
                carId: carId
            }
        });
    };
    __decorate([Object(decorator["c" /* Inject */])(net_service["NetService"])], carManagementService.prototype, "netService", void 0);
    __decorate([Object(decorator["a" /* Debounce */])()], carManagementService.prototype, "getCarParamList", null);
    __decorate([Object(decorator["a" /* Debounce */])()], carManagementService.prototype, "getCarDetail", null);
    __decorate([Object(decorator["a" /* Debounce */])()], carManagementService.prototype, "getCarColumnCollectModel", null);
    __decorate([Object(decorator["a" /* Debounce */])()], carManagementService.prototype, "getCarPictureList", null);
    return carManagementService;
}();

// CONCATENATED MODULE: ./src/services/manage-service/product.service.ts



var product_service___decorate = this && this.__decorate || function (decorators, target, key, desc) {
    var c = arguments.length,
        r = c < 3 ? target : desc === null ? desc = get_own_property_descriptor_default()(target, key) : desc,
        d;
    if ((typeof Reflect === "undefined" ? "undefined" : typeof_default()(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
        if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    }return c > 3 && r && define_property_default()(target, key, r), r;
};



var product_service_ProductService = /** @class */function () {
    function ProductService() {}
    /**
     *
     * 查询车辆信息首付月供
     */
    ProductService.prototype.getCarProductResultModelList = function (data) {
        return this.netService.send({
            server: manage_service["a" /* manageService */].productController.getCarProductResultModelList,
            data: data
        });
    };
    product_service___decorate([Object(decorator["c" /* Inject */])(net_service["NetService"])], ProductService.prototype, "netService", void 0);
    return ProductService;
}();

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.umd.js
var vue_property_decorator_umd = __webpack_require__("EOM2");
var vue_property_decorator_umd_default = /*#__PURE__*/__webpack_require__.n(vue_property_decorator_umd);

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("ipus");

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/detail/car-img-show.vue
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var car_img_show___decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var car_img_show_carImgShow = /** @class */ (function (_super) {
    __extends(carImgShow, _super);
    function carImgShow() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Object.defineProperty(carImgShow.prototype, "imageList", {
        get: function () {
            return this.carColumn.materialList || [];
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(carImgShow.prototype, "bigImg", {
        /**
         * 获取第一个Image 大图显示
         */
        get: function () {
            var result = {};
            if (this.imageList.length % 2 === 1) {
                result = this.imageList[0];
            }
            return result;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(carImgShow.prototype, "doubleColShowImages", {
        /**
         * 获取双列显示图片
         */
        get: function () {
            var result = this.imageList;
            if (this.imageList.length % 2 === 1) {
                result = this.imageList.splice(1);
            }
            return result;
        },
        enumerable: true,
        configurable: true
    });
    car_img_show___decorate([
        Object(vue_property_decorator_umd["Prop"])()
    ], carImgShow.prototype, "carColumn", void 0);
    carImgShow = car_img_show___decorate([
        vue_class_component_common_default()({
            components: {}
        })
    ], carImgShow);
    return carImgShow;
}(vue_esm["default"]));
/* harmony default export */ var car_img_show = (car_img_show_carImgShow);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-b045c3ac","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/detail/car-img-show.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component car-img-show"},[_c('div',{staticClass:"img-center"},[_c('div',{staticClass:"ex-large"},[_vm._v(_vm._s(_vm.carColumn.name))]),_vm._v(" "),_c('van-row',[_c('van-col',{directives:[{name:"show",rawName:"v-show",value:(_vm.bigImg),expression:"bigImg"}],attrs:{"span":24}},[_c('img',{attrs:{"src":_vm.bigImg.url,"alt":_vm.bigImg.name,"height":"100%"}})]),_vm._v(" "),_vm._l((_vm.doubleColShowImages),function(item,index){return _c('van-col',{key:index,attrs:{"span":12}},[_c('img',{attrs:{"src":item.url,"alt":item.name,"width":"100%"}})])})],2),_vm._v(" "),_c('div',{staticClass:"small"},[_vm._v(_vm._s(_vm.carColumn.introduce))])],1)])}
var staticRenderFns = []

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/component-normalizer.js
var component_normalizer = __webpack_require__("XyMi");

// CONCATENATED MODULE: ./src/components/detail/car-img-show.vue
function injectStyle (context) {
  __webpack_require__("MTzR")
  __webpack_require__("+Z++")
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-b045c3ac"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(component_normalizer["a" /* default */])(
  car_img_show,
  render,
  staticRenderFns,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var detail_car_img_show = (Component.exports);

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/detail/details-scheme.vue
var details_scheme___extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var details_scheme___decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};








var details_scheme_detailsScheme = /** @class */ (function (_super) {
    details_scheme___extends(detailsScheme, _super);
    function detailsScheme() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.showDetails = false;
        _this.activeNames = ['1'];
        _this.paramList = []; // 车辆详情配置
        _this.basicEquipment = []; // 车辆基本配置
        _this.carImg = []; // 车辆图片
        _this.carName = [];
        _this.carInfo = []; // 汽车详情
        _this.carPeriodsOne = []; // 还款期数1
        _this.carPeriodsTwo = []; //还款期数2、
        _this.carPeriodsThree = []; // 还款期数3
        _this.carIntoA = {}; // 进件需要用的数据
        _this.checkindex = null; // 首付点击获取calss 
        _this.checkindexTwo = null; // 期数点击当前获取class
        _this.aaaList = ['/static/images/common/car.png', '/static/images/common/car.png', '/static/images/common/car.png', '/static/images/common/car.png', '/static/images/common/car.png', '/static/images/common/car.png', '/static/images/common/car.png', '/static/images/common/car.png'];
        _this.images = '/static/images/common/headerLabel.png';
        _this.carColumns = [];
        return _this;
    }
    /**
     * 获取车辆详细配置
     */
    detailsScheme.prototype.getCarDetails = function () {
        var _this = this;
        this.carManagementService.getCarParamList(this.carId).subscribe(function (data) {
            _this.paramList = data;
        }, function (err) { return _this.$toast(err.msg); });
    };
    /**
    * 获取车辆基本配置
    */
    detailsScheme.prototype.getBasicEquipment = function () {
        var _this = this;
        this.carManagementService.getCarDetail(this.carId).subscribe(function (data) {
            _this.basicEquipment = data;
            _this.carInfo = {
                brandName: data.brandName,
                interiorColor: data.interiorColor,
                modelName: data.modelName,
                seriesName: data.seriesName,
                vehicleColor: data.carColour,
            };
        }, function (err) { return _this.$toast(err.msg); });
    };
    /**
    * 获取车辆图片 （栏目信息）
    */
    detailsScheme.prototype.getCarColumnImg = function () {
        var _this = this;
        this.carManagementService.getCarColumnCollectModel(this.carId).subscribe(function (data) { return _this.carColumns = data.columnList; }, function (err) { return _this.$toast(err.msg); });
    };
    /**
    * 获取车辆首付 期数1
    */
    detailsScheme.prototype.getCarPeriods = function () {
        var _this = this;
        this.productService.getCarProductResultModelList({ carId: this.carId }).subscribe(function (data) {
            _this.carPeriodsOne = data;
        }, function (err) { return _this.$toast(err.msg); });
    };
    /***
     * 还款期数 期数2
     */
    detailsScheme.prototype.paymentOne = function (val, index) {
        var _this = this;
        this.checkindex = index;
        var a = {
            carId: this.carId,
            firstPayment: val
        };
        this.productService.getCarProductResultModelList(a).subscribe(function (data) {
            _this.carPeriodsTwo = data;
        }, function (err) { return _this.$toast(err.msg); });
    };
    /**
     * 点击期数 期数3
     */
    detailsScheme.prototype.paymentTwo = function (val, index) {
        var _this = this;
        this.checkindexTwo = index;
        var a = {
            carId: this.carId,
            planType: val
        };
        this.productService.getCarProductResultModelList(a).subscribe(function (data) {
            _this.carPeriodsThree = data;
            _this.carIntoA = {
                productResultId: data[0].resultId,
                productId: data[0].relationId,
                initialPayment: data[0].firstPayment,
                finalCash: data[0].endPayment,
                financingAmount: data[0].firstYearPrincipal,
                monthlySupply: data[0].firstYearMonthrent,
                periods: data[0].planType,
            };
            console.log(data, '进件需要用的');
        }, function (err) { return _this.$toast(err.msg); });
    };
    /***
      * 点击下一步
      */
    detailsScheme.prototype.skipNextStep = function () {
        if (!!this.carIntoA.productResultId) {
            this.carDetails(this.carInfo);
            this.carDetailTwo(this.carIntoA);
            this.$router.push('/upload-id-photo-first');
        }
        else {
            this.$toast('请先选择车辆首付、期数');
        }
    };
    detailsScheme.prototype.mounted = function () {
        this.getCarDetails();
        this.getBasicEquipment();
        this.getCarColumnImg();
        this.getCarPeriods();
    };
    details_scheme___decorate([
        Object(decorator["b" /* Dependencies */])(car_management_service_carManagementService)
    ], detailsScheme.prototype, "carManagementService", void 0);
    details_scheme___decorate([
        Object(decorator["b" /* Dependencies */])(product_service_ProductService)
    ], detailsScheme.prototype, "productService", void 0);
    details_scheme___decorate([
        Object(vue_property_decorator_umd["Prop"])({
            required: true,
        })
    ], detailsScheme.prototype, "carId", void 0);
    details_scheme___decorate([
        lib["c" /* Mutation */]
    ], detailsScheme.prototype, "carDetailTwo", void 0);
    details_scheme___decorate([
        lib["c" /* Mutation */]
    ], detailsScheme.prototype, "carDetails", void 0);
    detailsScheme = details_scheme___decorate([
        vue_class_component_common_default()({
            components: {
                carImgShow: detail_car_img_show
            }
        })
    ], detailsScheme);
    return detailsScheme;
}(vue_esm["default"]));
/* harmony default export */ var details_scheme = (details_scheme_detailsScheme);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-46f55bf7","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/detail/details-scheme.vue
var details_scheme_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"page details-scheme"},[_c('van-cell-group',[_c('van-cell',[_c('template',{slot:"title"},[_c('img',{staticClass:"someIcon",attrs:{"height":"17px","src":_vm.images,"alt":""}}),_vm._v(" "),_c('span',{staticClass:"van-cell-text basicParameter"},[_vm._v("分期方案")])])],2)],1),_vm._v(" "),_c('div',{staticClass:"area"},[_c('van-row',[_c('van-col',{staticClass:"payment"},[_vm._v("首付")])],1),_vm._v(" "),_c('van-row',{staticClass:"downPaymentRow small"},_vm._l((_vm.carPeriodsOne),function(item,index){return _c('van-col',{key:index},[_c('span',{staticClass:"downPayment",class:{'active':index ==_vm.checkindex },on:{"click":function($event){_vm.paymentOne(item.firstPayment,index)}}},[_vm._v(_vm._s(item.firstPayment))])])})),_vm._v(" "),_c('van-row',[_c('van-col',{staticClass:"payment"},[_vm._v("期数")])],1),_vm._v(" "),_c('van-row',{staticClass:"periodsRow small"},_vm._l((_vm.carPeriodsTwo),function(item,index){return _c('van-col',{key:index},[_c('span',{staticClass:"downPayment",class:{'active':index ==_vm.checkindexTwo },on:{"click":function($event){_vm.paymentTwo(item.planType,index)}}},[_vm._v(_vm._s(_vm.$dict.getDictName(item.planType)))])])})),_vm._v(" "),_c('van-row',[_c('van-col',{staticClass:"payment"},[_vm._v("月供详情")])],1),_vm._v(" "),_c('van-row',{directives:[{name:"show",rawName:"v-show",value:(_vm.carPeriodsThree.length > 0),expression:"carPeriodsThree.length > 0"}],staticClass:"monthly"},[_c('van-col',{directives:[{name:"show",rawName:"v-show",value:(_vm.carPeriodsThree.length > 0 ? _vm.carPeriodsThree[0].firstYearMonthrent:null),expression:"carPeriodsThree.length > 0 ? carPeriodsThree[0].firstYearMonthrent:null"}],attrs:{"span":"12"}},[_vm._v("\n        第一年月供:\n        "),_c('span',{staticClass:"colred"},[_vm._v(_vm._s(_vm.carPeriodsThree.length > 0 ? _vm.carPeriodsThree[0].firstYearMonthrent:null))]),_vm._v("元\n      ")]),_vm._v(" "),_c('van-col',{directives:[{name:"show",rawName:"v-show",value:(_vm.carPeriodsThree.length > 0?_vm.carPeriodsThree[0].secondYearMonthrent:null),expression:"carPeriodsThree.length > 0?carPeriodsThree[0].secondYearMonthrent:null"}],attrs:{"span":"12"}},[_vm._v("\n        第二年月供:\n        "),_c('span',{staticClass:"colred"},[_vm._v(_vm._s(_vm.carPeriodsThree.length > 0?_vm.carPeriodsThree[0].secondYearMonthrent:null))]),_vm._v("元\n      ")]),_vm._v(" "),_c('van-col',{directives:[{name:"show",rawName:"v-show",value:(_vm.carPeriodsThree.length > 0 ? _vm.carPeriodsThree[0].thirdYearMonthrent:null),expression:"carPeriodsThree.length > 0 ? carPeriodsThree[0].thirdYearMonthrent:null"}],attrs:{"span":"12"}},[_vm._v("\n        第三年月供:\n        "),_c('span',{staticClass:"colred"},[_vm._v(_vm._s(_vm.carPeriodsThree.length > 0 ? _vm.carPeriodsThree[0].thirdYearMonthrent:null))]),_vm._v("元\n      ")]),_vm._v(" "),_c('van-col',{directives:[{name:"show",rawName:"v-show",value:(_vm.carPeriodsThree.length > 0? _vm.carPeriodsThree[0].fourthYearMonthrent:null),expression:"carPeriodsThree.length > 0? carPeriodsThree[0].fourthYearMonthrent:null"}],attrs:{"span":"12"}},[_vm._v("\n        第四年月供:\n        "),_c('span',{staticClass:"colred"},[_vm._v(_vm._s(_vm.carPeriodsThree.length > 0? _vm.carPeriodsThree[0].fourthYearMonthrent:null))]),_vm._v("元\n      ")]),_vm._v(" "),_c('van-col',{directives:[{name:"show",rawName:"v-show",value:(_vm.carPeriodsThree.length > 0? _vm.carPeriodsThree[0].fifthYearMonthrent:null),expression:"carPeriodsThree.length > 0? carPeriodsThree[0].fifthYearMonthrent:null"}],attrs:{"span":"12"}},[_vm._v("\n        第五年月供:\n        "),_c('span',{staticClass:"colred"},[_vm._v(_vm._s(_vm.carPeriodsThree.length > 0? _vm.carPeriodsThree[0].fifthYearMonthrent:null))]),_vm._v("元\n      ")])],1)],1),_vm._v(" "),_c('van-collapse',{model:{value:(_vm.activeNames),callback:function ($$v) {_vm.activeNames=$$v},expression:"activeNames"}},[_c('van-collapse-item',{attrs:{"name":"2"}},[_c('div',{attrs:{"slot":"title"},slot:"title"},[_vm._v("基本参数\n        "),_c('span',{staticStyle:{"float":"right"}},[_vm._v("详细配置")])]),_vm._v(" "),_vm._l((_vm.paramList),function(item,index){return _c('van-cell-group',{key:index,staticClass:"dropDown"},[_c('van-cell',{attrs:{"title":item.name,"value":item.value}})],1)})],2)],1),_vm._v(" "),_c('div',{staticClass:"carDetails"},[_c('van-cell-group',[_c('van-cell',{attrs:{"title":"车身结构","value":_vm.basicEquipment.carStructure}}),_vm._v(" "),_c('van-cell',{attrs:{"title":"上/宽/高(mm)","value":_vm.basicEquipment.carSize}}),_vm._v(" "),_c('van-cell',{attrs:{"title":"发动机","value":_vm.basicEquipment.carEmissions}}),_vm._v(" "),_c('van-cell',{attrs:{"title":"驱动方式","value":_vm.basicEquipment.drivingMode}}),_vm._v(" "),_c('van-cell',{attrs:{"title":"燃料形式","value":_vm.basicEquipment.fuel}}),_vm._v(" "),_c('van-cell',{attrs:{"title":"综合油耗(L/100km)","value":_vm.basicEquipment.fuelConsumption}}),_vm._v(" "),_c('van-cell',{attrs:{"title":"车辆配色","value":_vm.basicEquipment.carColour}})],1)],1),_vm._v(" "),_c('div',{staticClass:"break-line"}),_vm._v(" "),_c('van-cell-group',{staticClass:"magin10"},[_c('van-cell',[_c('template',{slot:"title"},[_c('img',{staticClass:"someIcon",attrs:{"height":"17px","src":_vm.images,"alt":""}}),_vm._v(" "),_c('span',{staticClass:"van-cell-text basicParameter"},[_vm._v("车型亮点")])])],2)],1),_vm._v(" "),_c('van-row',_vm._l((_vm.carColumns),function(item,index){return _c('carImgShow',{key:index,attrs:{"carColumn":item}})})),_vm._v(" "),_c('div',{staticClass:"carGoHome"},[_c('van-cell-group',{staticClass:"magin10"},[_c('van-cell',[_c('template',{slot:"title"},[_c('img',{staticClass:"someIcon",attrs:{"height":"15px","src":_vm.images,"alt":""}}),_vm._v(" "),_c('span',{staticClass:"van-cell-text basicParameter"},[_vm._v("四步提车回家")])])],2)],1),_vm._v(" "),_c('van-row',[_c('div',{staticClass:"appointmentImmediately"},[_c('img',{attrs:{"height":"65px","src":"/static/images/common/phone.png","alt":""}}),_vm._v(" "),_c('div',{staticClass:"appointmentDescribe"},[_c('div',{staticClass:"appointmentHend"},[_vm._v("立即预约")]),_vm._v(" "),_c('span',{staticClass:"appointmentSpan"},[_vm._v("选好意向车型后,洋葱好车直营店客户经理将在24小时之内为你提供1对1服务")])])])]),_vm._v(" "),_c('van-row',[_c('div',{staticClass:"appointmentImmediately"},[_c('img',{attrs:{"height":"65px","src":"/static/images/common/agreement.png","alt":""}}),_vm._v(" "),_c('div',{staticClass:"appointmentDescribe"},[_c('div',{staticClass:"appointmentHend"},[_vm._v("签订协议")]),_vm._v(" "),_c('span',{staticClass:"appointmentSpan"},[_vm._v("选择合适的购车方案,通过征信审核后签订购车协议")])])])]),_vm._v(" "),_c('van-row',[_c('div',{staticClass:"appointmentImmediately"},[_c('img',{attrs:{"height":"65px","src":"/static/images/common/cost.png","alt":""}}),_vm._v(" "),_c('div',{staticClass:"appointmentDescribe"},[_c('div',{staticClass:"appointmentHend"},[_vm._v("支付费用")]),_vm._v(" "),_c('span',{staticClass:"appointmentSpan"},[_vm._v("支付首付,第一期月供,违章保证金")])])])]),_vm._v(" "),_c('van-row',[_c('div',{staticClass:"appointmentImmediately"},[_c('img',{attrs:{"height":"65px","src":"/static/images/common/vehicle.png","alt":""}}),_vm._v(" "),_c('div',{staticClass:"appointmentDescribe"},[_c('div',{staticClass:"appointmentHend"},[_vm._v("到店提车")]),_vm._v(" "),_c('span',{staticClass:"appointmentSpan"},[_vm._v("免费办理保险与上牌手续后,客户经理将联系您到附近直营店提车")])])])]),_vm._v(" "),_c('div',{staticClass:"break-line"}),_vm._v(" "),_c('van-cell-group',{staticClass:"magin10"},[_c('van-cell',[_c('template',{slot:"title"},[_c('img',{staticClass:"someIcon",attrs:{"height":"15px","src":_vm.images,"alt":""}}),_vm._v(" "),_c('span',{staticClass:"van-cell-text basicParameter"},[_vm._v("购买须知")])])],2)],1),_vm._v(" "),_c('van-row',{staticClass:"purchaseNotes"},[_c('van-col',{staticClass:"noticeHeand",attrs:{"span":"8"}},[_vm._v("购车资料")]),_vm._v(" "),_c('van-col',{staticClass:"noticeEnd",attrs:{"span":"16"}},[_vm._v("洋葱汽车由各大汽车品牌厂商供应,车源品质有保障")])],1),_vm._v(" "),_c('van-row',{staticClass:"purchaseNotes"},[_c('van-col',{staticClass:"noticeHeand",attrs:{"span":"8"}},[_vm._v("车源保障")]),_vm._v(" "),_c('van-col',{staticClass:"noticeEnd",attrs:{"span":"16"}},[_vm._v("二代身份证、驾驶证、征信报告")])],1),_vm._v(" "),_c('van-row',{staticClass:"purchaseNotes"},[_c('van-col',{staticClass:"noticeHeand",attrs:{"span":"8"}},[_vm._v("车辆归属")]),_vm._v(" "),_c('van-col',{staticClass:"noticeEnd",attrs:{"span":"16"}},[_vm._v("用车期间,车辆以及车牌所有权归属洋葱汽车;结清全部费用后即办理车辆过户")])],1),_vm._v(" "),_c('van-row',{staticClass:"purchaseNotes"},[_c('van-col',{staticClass:"noticeHeand",attrs:{"span":"8"}},[_vm._v("额外费用")]),_vm._v(" "),_c('van-col',{staticClass:"noticeEnd",attrs:{"span":"16"}},[_vm._v("除违章保证金无需支付额外费用")])],1),_vm._v(" "),_c('van-row',{staticClass:"purchaseNotes"},[_c('van-col',{staticClass:"noticeHeand",attrs:{"span":"8"}},[_vm._v("随车保险")]),_vm._v(" "),_c('van-col',{staticClass:"noticeEnd",attrs:{"span":"16"}},[_vm._v("洋葱汽车帮您办理好保险")])],1),_vm._v(" "),_c('van-row',{staticClass:"purchaseNotes"},[_c('van-col',{staticClass:"noticeHeand",attrs:{"span":"8"}},[_vm._v("上牌")]),_vm._v(" "),_c('van-col',{staticClass:"noticeEnd",attrs:{"span":"16"}},[_vm._v("洋葱汽车负责办理车辆上牌,您无需到场,无需支付额外费用")])],1),_vm._v(" "),_c('van-row',{staticClass:"purchaseNotes"},[_c('van-col',{staticClass:"noticeHeand",attrs:{"span":"8"}},[_vm._v("还款")]),_vm._v(" "),_c('van-col',{staticClass:"noticeEnd",attrs:{"span":"16"}},[_vm._v("购车后通过绑定的银行卡按时还款")])],1),_vm._v(" "),_c('div',{staticClass:"break-line"}),_vm._v(" "),_c('div',[_c('van-button',{attrs:{"size":"large"},on:{"click":_vm.skipNextStep}},[_vm._v("下一步")])],1)],1)],1)}
var details_scheme_staticRenderFns = []

// CONCATENATED MODULE: ./src/components/detail/details-scheme.vue
function details_scheme_injectStyle (context) {
  __webpack_require__("GN+L")
  __webpack_require__("q2p1")
}
/* script */


/* template */

/* template functional */
var details_scheme___vue_template_functional__ = false
/* styles */
var details_scheme___vue_styles__ = details_scheme_injectStyle
/* scopeId */
var details_scheme___vue_scopeId__ = "data-v-46f55bf7"
/* moduleIdentifier (server only) */
var details_scheme___vue_module_identifier__ = null

var details_scheme_Component = Object(component_normalizer["a" /* default */])(
  details_scheme,
  details_scheme_render,
  details_scheme_staticRenderFns,
  details_scheme___vue_template_functional__,
  details_scheme___vue_styles__,
  details_scheme___vue_scopeId__,
  details_scheme___vue_module_identifier__
)

/* harmony default export */ var detail_details_scheme = (details_scheme_Component.exports);

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/pages/details.vue
var details___extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var details___decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var details_Details = /** @class */ (function (_super) {
    details___extends(Details, _super);
    function Details() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.carList = [];
        _this.images = [];
        return _this;
    }
    Details.prototype.BackTop = function () {
        document.documentElement.scrollTop = 0;
        window.scrollTo(0, 0);
    };
    /**
     * 获取车辆基本配置
     */
    Details.prototype.getBasicEquipment = function () {
        var _this = this;
        this.carManagementService.getCarDetail(this.carId).subscribe(function (data) {
            _this.carList = data;
        }, function (err) { return _this.$toast(err.msg); });
    };
    /**
    * 获取车辆首页图片
    */
    Details.prototype.getCarPictureFun = function () {
        var _this = this;
        this.carManagementService.getCarPictureList(this.carId).subscribe(function (data) { return _this.images = data; }, function (err) { return _this.$toast(err.msg); });
    };
    Details.prototype.mounted = function () {
        this.BackTop();
        this.getBasicEquipment();
        this.getCarPictureFun();
    };
    details___decorate([
        Object(decorator["b" /* Dependencies */])(car_management_service_carManagementService)
    ], Details.prototype, "carManagementService", void 0);
    details___decorate([
        Object(vue_property_decorator_umd["Prop"])()
    ], Details.prototype, "carId", void 0);
    Details = details___decorate([
        vue_class_component_common_default()({
            components: {
                DetailsScheme: detail_details_scheme,
            }
        })
    ], Details);
    return Details;
}(vue_esm["default"]));
/* harmony default export */ var details = (details_Details);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-cb370714","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/pages/details.vue
var details_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"page details"},[_c('van-row',[_c('van-swipe',{attrs:{"autoplay":3000}},_vm._l((_vm.images),function(image,index){return _c('van-swipe-item',{key:index},[_c('div',{staticClass:"car-main-img"},[_c('img',{attrs:{"src":image.url,"alt":image.introduce,"height":"250px"}})])])}))],1),_vm._v(" "),_c('van-row',{staticClass:"carDetails"},[_c('van-col',{staticClass:"detailsOne",attrs:{"span":"20"}},[_vm._v("车辆照片仅供参考,已配置描述为准")]),_vm._v(" "),_c('van-col',{attrs:{"span":"4"}})],1),_vm._v(" "),_c('van-row',{staticClass:"textDescription"},[_c('van-col',{attrs:{"span":"24"}},[_vm._v(_vm._s(_vm.carList.modelName))])],1),_vm._v(" "),_c('van-row',{staticClass:"guarantee"},[_c('van-col',{staticClass:"textCenter",attrs:{"span":"8"}},[_c('van-icon',{attrs:{"name":"certificate"}}),_vm._v(" "),_c('span',[_vm._v(" 包购置税")])],1),_vm._v(" "),_c('van-col',{staticClass:"textCenter",attrs:{"span":"8"}},[_c('van-icon',{attrs:{"name":"certificate"}}),_vm._v(" "),_c('span',[_vm._v(" 送一年保险")])],1),_vm._v(" "),_c('van-col',{staticClass:"textCenter",attrs:{"span":"8"}},[_c('van-icon',{attrs:{"name":"certificate"}}),_vm._v(" "),_c('span',[_vm._v(" 全国联保")])],1)],1),_vm._v(" "),_c('van-row',[_c('DetailsScheme',{attrs:{"carId":_vm.carId}})],1)],1)}
var details_staticRenderFns = []

// CONCATENATED MODULE: ./src/pages/details.vue
function details_injectStyle (context) {
  __webpack_require__("oD+8")
  __webpack_require__("Pvl5")
}
/* script */


/* template */

/* template functional */
var details___vue_template_functional__ = false
/* styles */
var details___vue_styles__ = details_injectStyle
/* scopeId */
var details___vue_scopeId__ = "data-v-cb370714"
/* moduleIdentifier (server only) */
var details___vue_module_identifier__ = null

var details_Component = Object(component_normalizer["a" /* default */])(
  details,
  details_render,
  details_staticRenderFns,
  details___vue_template_functional__,
  details___vue_styles__,
  details___vue_scopeId__,
  details___vue_module_identifier__
)

/* harmony default export */ var pages_details = __webpack_exports__["default"] = (details_Component.exports);


/***/ }),

/***/ "MTzR":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("vSrd");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("52b03de4", content, true, {});

/***/ }),

/***/ "N5a5":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("Q+vp");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("9b61c5a0", content, true, {});

/***/ }),

/***/ "OBem":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("qesE");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("5f60ce94", content, true, {});

/***/ }),

/***/ "PLP8":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/vue/dist/vue.esm.js
var vue_esm = __webpack_require__("7+uW");

// EXTERNAL MODULE: ./node_modules/vue-class-component/dist/vue-class-component.common.js
var vue_class_component_common = __webpack_require__("c+8m");
var vue_class_component_common_default = /*#__PURE__*/__webpack_require__.n(vue_class_component_common);

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/pages/know-onion-car.vue
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


var know_onion_car_MyOrder = /** @class */ (function (_super) {
    __extends(MyOrder, _super);
    function MyOrder() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.carImg = ['/static/images/common/onionCar.png', '/static/images/common/onionCar1.png', '/static/images/common/onionCar2.png', '/static/images/common/onionCar3.png', '/static/images/common/onionCar4.png', '/static/images/common/onionCar5.png'];
        return _this;
    }
    MyOrder = __decorate([
        vue_class_component_common_default()({
            components: {}
        })
    ], MyOrder);
    return MyOrder;
}(vue_esm["default"]));
/* harmony default export */ var know_onion_car = (know_onion_car_MyOrder);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-1a7de013","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/pages/know-onion-car.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"page know-onion-car"},_vm._l((_vm.carImg),function(item,index){return _c('van-row',{key:index},[_c('van-col',{staticClass:"backgroundColor",attrs:{"span":"24"}},[_c('img',{attrs:{"width":"100%","src":item,"alt":""}})])],1)}))}
var staticRenderFns = []

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/component-normalizer.js
var component_normalizer = __webpack_require__("XyMi");

// CONCATENATED MODULE: ./src/pages/know-onion-car.vue
function injectStyle (context) {
  __webpack_require__("bMu+")
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-1a7de013"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(component_normalizer["a" /* default */])(
  know_onion_car,
  render,
  staticRenderFns,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var pages_know_onion_car = __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "Pvl5":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("uZqz");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("647d4085", content, true, {});

/***/ }),

/***/ "Q+vp":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".component.loading .ivu-modal-wrap{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}.component.loading .ivu-modal-wrap .ivu-modal{top:0}.component.loading .ivu-modal-wrap .ivu-modal .ivu-modal-content{position:relative;background-color:transparent}.component.loading .ivu-modal-wrap .ivu-modal .ivu-modal-content .ivu-modal-close,.component.loading .ivu-modal-wrap .ivu-modal .ivu-modal-content .ivu-modal-footer,.component.loading .ivu-modal-wrap .ivu-modal .ivu-modal-content .ivu-modal-header{display:none}", ""]);

// exports


/***/ }),

/***/ "Q2H+":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("tRa9");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("76d9db50", content, true, {});

/***/ }),

/***/ "Qo2O":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, "/*! normalize.css v2.1.3 | MIT License | git.io/normalize */article,aside,details,figcaption,figure,footer,header,hgroup,main,nav,section,summary{display:block}audio,canvas,video{display:inline-block}audio:not([controls]){display:none;height:0}[hidden],template{display:none}html{font-family:sans-serif;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}body{margin:0}a{background:transparent}a:focus{outline:thin dotted}a:active,a:hover{outline:0}h1{font-size:2em;margin:.67em 0}abbr[title]{border-bottom:1px dotted}b,strong{font-weight:700}dfn{font-style:italic}hr{-webkit-box-sizing:content-box;box-sizing:content-box;height:0}mark{background:#ff0;color:#000}code,kbd,pre,samp{font-family:monospace,serif;font-size:1em}pre{white-space:pre-wrap}q{quotes:\"\\201C\" \"\\201D\" \"\\2018\" \"\\2019\"}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sup{top:-.5em}sub{bottom:-.25em}img{border:0}svg:not(:root){overflow:hidden}figure{margin:0}fieldset{border:1px solid silver;margin:0 2px;padding:.35em .625em .75em}legend{border:0;padding:0}button,input,select,textarea{font-family:inherit;font-size:100%;margin:0}button,input{line-height:normal}button,select{text-transform:none}button,html input[type=button],input[type=reset],input[type=submit]{-webkit-appearance:button;cursor:pointer}button[disabled],html input[disabled]{cursor:default}input[type=checkbox],input[type=radio]{-webkit-box-sizing:border-box;box-sizing:border-box;padding:0}input[type=search]{-webkit-appearance:textfield;-webkit-box-sizing:content-box;box-sizing:content-box}input[type=search]::-webkit-search-cancel-button,input[type=search]::-webkit-search-decoration{-webkit-appearance:none}button::-moz-focus-inner,input::-moz-focus-inner{border:0;padding:0}textarea{overflow:auto;vertical-align:top}table{border-collapse:collapse;border-spacing:0}.flex-nowrap{-ms-flex-wrap:nowrap!important;flex-wrap:nowrap!important}.col>.col,.col>.row,.row>.col{margin:0;padding:0}.container-fluid{margin-right:auto;margin-left:auto;padding-right:2rem;padding-left:2rem}.row{-ms-flex:0 1 auto;flex:0 1 auto;-ms-flex-direction:row;-webkit-box-orient:horizontal;-webkit-box-direction:normal;flex-direction:row;-ms-flex-wrap:wrap;flex-wrap:wrap}.col,.row{-webkit-box-sizing:border-box;box-sizing:border-box;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-flex:0;-webkit-box-lines:single}.col{-ms-flex:0 1 auto;flex:0 1 auto;-ms-flex-direction:column;flex-direction:column;-webkit-flex-wrap:wrap;-webkit-box-orient:vertical;-ms-flex-wrap:wrap;flex-wrap:wrap}.row.reverse{-ms-flex-direction:row-reverse;flex-direction:row-reverse}.col.reverse,.row.reverse{-webkit-box-direction:reverse}.col.reverse{-ms-flex-direction:column-reverse;flex-direction:column-reverse}.col-span,.col-span-1,.col-span-2,.col-span-3,.col-span-4,.col-span-5,.col-span-6,.col-span-7,.col-span-8,.col-span-9,.col-span-10,.col-span-11,.col-span-12,.col-span-offset-1,.col-span-offset-2,.col-span-offset-3,.col-span-offset-4,.col-span-offset-5,.col-span-offset-6,.col-span-offset-7,.col-span-offset-8,.col-span-offset-9,.col-span-offset-10,.col-span-offset-11,.col-span-offset-12{-webkit-box-sizing:border-box;box-sizing:border-box;-ms-flex:0 0 auto;-webkit-box-flex:0;flex:0 0 auto;padding-right:.5rem;padding-left:.5rem}.col-span{-ms-flex-positive:1;flex-grow:1;-webkit-box-flex:1;min-width:0;-ms-flex-preferred-size:0;flex-basis:0;max-width:100%}.col-span-1{-ms-flex-preferred-size:8.333%;flex-basis:8.333%;max-width:8.333%;min-width:8.333%}.col-span-2{-ms-flex-preferred-size:16.667%;flex-basis:16.667%;max-width:16.667%;min-width:16.667%}.col-span-3{-ms-flex-preferred-size:25%;flex-basis:25%;max-width:25%;min-width:25%}.col-span-4{-ms-flex-preferred-size:33.333%;flex-basis:33.333%;max-width:33.333%;min-width:33.333%}.col-span-5{-ms-flex-preferred-size:41.667%;flex-basis:41.667%;max-width:41.667%;min-width:41.667%}.col-span-6{-ms-flex-preferred-size:50%;flex-basis:50%;max-width:50%;min-width:50%}.col-span-7{-ms-flex-preferred-size:58.333%;flex-basis:58.333%;max-width:58.333%;min-width:58.333%}.col-span-8{-ms-flex-preferred-size:66.667%;flex-basis:66.667%;max-width:66.667%;min-width:66.667%}.col-span-9{-ms-flex-preferred-size:75%;flex-basis:75%;max-width:75%;min-width:75%}.col-span-10{-ms-flex-preferred-size:83.333%;flex-basis:83.333%;max-width:83.333%;min-width:83.333%}.col-span-11{-ms-flex-preferred-size:91.667%;flex-basis:91.667%;max-width:91.667%;min-width:91.667%}.col-span-12{-ms-flex-preferred-size:100%;flex-basis:100%;max-width:100%;min-width:100%}.col-span-offset-1{margin-left:8.333%}.col-span-offset-2{margin-left:16.667%}.col-span-offset-3{margin-left:25%}.col-span-offset-4{margin-left:33.333%}.col-span-offset-5{margin-left:41.667%}.col-span-offset-6{margin-left:50%}.col-span-offset-7{margin-left:58.333%}.col-span-offset-8{margin-left:66.667%}.col-span-offset-9{margin-left:75%}.col-span-offset-10{margin-left:83.333%}.col-span-offset-11{margin-left:91.667%}.row-span,.row-span-1,.row-span-2,.row-span-3,.row-span-4,.row-span-5,.row-span-6,.row-span-7,.row-span-8,.row-span-9,.row-span-10,.row-span-11,.row-span-12,.row-span-offset-1,.row-span-offset-2,.row-span-offset-3,.row-span-offset-4,.row-span-offset-5,.row-span-offset-6,.row-span-offset-7,.row-span-offset-8,.row-span-offset-9,.row-span-offset-10,.row-span-offset-11,.row-span-offset-12{-webkit-box-sizing:border-box;box-sizing:border-box;-ms-flex:0 0 auto;flex:0 0 auto;-webkit-box-flex:0;padding-top:.5rem;padding-bottom:.5rem}.row-span{-ms-flex-positive:1;-webkit-box-flex:1;flex-grow:1;-ms-flex-preferred-size:0;flex-basis:0;max-height:100%}.row-span-1{-ms-flex:1 1 auto;flex:1 1 auto;-webkit-box-flex:1}.row-span-2{-ms-flex:2 2 auto;flex:2 2 auto;-webkit-box-flex:2}.row-span-3{-ms-flex:3 3 auto;flex:3 3 auto;-webkit-box-flex:3}.row-span-4{-ms-flex:4 4 auto;flex:4 4 auto;-webkit-box-flex:4}.row-span-5{-ms-flex:5 5 auto;flex:5 5 auto;-webkit-box-flex:5}.row-span-6{-ms-flex:6 6 auto;flex:6 6 auto;-webkit-box-flex:5}.start-span{-ms-flex-pack:start;justify-content:flex-start;text-align:start;-webkit-box-pack:start}.center-span{-ms-flex-pack:center;justify-content:center;text-align:center;-webkit-box-pack:center}.end-span{-ms-flex-pack:end;justify-content:flex-end;text-align:end;-webkit-box-pack:end}.top-span{-ms-flex-align:start;align-items:flex-start;-webkit-box-align:start}.middle-span{-ms-flex-align:center;align-items:center;-webkit-box-align:center}.bottom-span{-ms-flex-align:end;align-items:flex-end;-webkit-box-align:end}.around-span{-ms-flex-pack:distribute;justify-content:space-around;-webkit-box-pack:justify}.between-span{-ms-flex-pack:justify;justify-content:space-between;-webkit-box-pack:justify}.first-span{-ms-flex-order:-1;-webkit-box-ordinal-group:0;order:-1}.last-span{-ms-flex-order:1;-webkit-box-ordinal-group:2;order:1}.hotpink{background:hotpink}.red{background:red}.blue{background:blue}.salmon{background:salmon}.chocolate{background:#d2691e}.yellow{background:#ff0}.row>.row{padding:0;text-align:center;margin:0}.content{text-align:left;word-break:break-word}.img{background-size:100% auto;width:100%;margin:auto}#app,body,html{min-height:100%;width:100%;overflow-y:auto;overflow-x:auto;padding:0;margin:0;font-family:Helvetica Neue,Helvetica,PingFang SC,Hiragino Sans GB,Microsoft YaHei,\\\\5FAE\\8F6F\\96C5\\9ED1,Arial,sans-serif}#app .page,body .page,html .page{min-width:100%;min-height:100%;background:#fff;overflow:auto;-webkit-box-sizing:border-box;box-sizing:border-box}#app .ex-large,body .ex-large,html .ex-large{font-size:24px}#app .large,body .large,html .large{font-size:18px}#app .normal,body .normal,html .normal{font-size:14px}#app .small,body .small,html .small{font-size:12px}#app .ex-small,body .ex-small,html .ex-small{font-size:10px}#app .van-button,body .van-button,html .van-button{color:#000;background:#fadc4b;border-color:#fadc4b}#app .van-button .primary,body .van-button .primary,html .van-button .primary{background:#fadc4b;border-color:#fadc4b}#app .van-button .primary-color,body .van-button .primary-color,html .van-button .primary-color{background:#fadc4b}#app .van-button.full-radius,body .van-button.full-radius,html .van-button.full-radius{width:85%;border-radius:25px}#app .van-button.small-radius,body .van-button.small-radius,html .van-button.small-radius{border-radius:5px}.full{width:100%}.full,.full-height{height:100%}.full-width{width:100%}.full-absolute{position:absolute;top:0;left:0;bottom:0;right:0}.text-left{text-align:left}.text-right{text-align:right}.form-title{font-size:16px;height:50px;line-height:50px;font-weight:700;margin-left:10px;padding-left:-10px}.break-line{background-color:#f2f2f2;height:10px}", ""]);

// exports


/***/ }),

/***/ "Srf9":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".nav-bar .van-modal{margin-top:46px}", ""]);

// exports


/***/ }),

/***/ "T47b":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/vue/dist/vue.esm.js
var vue_esm = __webpack_require__("7+uW");

// EXTERNAL MODULE: ./node_modules/vue-class-component/dist/vue-class-component.common.js
var vue_class_component_common = __webpack_require__("c+8m");
var vue_class_component_common_default = /*#__PURE__*/__webpack_require__.n(vue_class_component_common);

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.umd.js
var vue_property_decorator_umd = __webpack_require__("EOM2");
var vue_property_decorator_umd_default = /*#__PURE__*/__webpack_require__.n(vue_property_decorator_umd);

// EXTERNAL MODULE: ./src/utils/city.service.ts
var city_service = __webpack_require__("8eB/");

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/common/city-picker.vue
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var cityData = city_service["a" /* CityService */].getCityData();
var city_picker_CityPicker = /** @class */ (function (_super) {
    __extends(CityPicker, _super);
    function CityPicker() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.visible = false;
        _this.columns = [];
        return _this;
    }
    CityPicker.prototype.emitConfirm = function (currentCitys) { };
    CityPicker.prototype.emitCancel = function () { };
    CityPicker.prototype.onChange = function (picker, value, index) {
        for (var i = index + 1; i <= 2; i++) {
            var data = picker.getColumnValue(i - 1);
            picker.setColumnValues(i, data.children);
        }
    };
    CityPicker.prototype.onConfirm = function (data) {
        this.emitConfirm(data.map(function (x) { return x.value; }));
        this.visible = false;
    };
    CityPicker.prototype.onCancel = function () {
        this.reset();
        this.emitCancel();
        this.visible = false;
    };
    CityPicker.prototype.show = function () {
        this.visible = true;
    };
    CityPicker.prototype.mounted = function () {
        this.reset();
    };
    CityPicker.prototype.reset = function () {
        // 默认选择城市
        var currentProvince = cityData[0];
        var currentCity = currentProvince.children[0];
        var currentCounty = currentCity.children[0];
        this.columns = [
            {
                values: cityData
            },
            {
                values: currentProvince.children
            },
            {
                values: currentCity.children
            }
        ];
    };
    __decorate([
        Object(vue_property_decorator_umd["Emit"])("on-confirm")
    ], CityPicker.prototype, "emitConfirm", null);
    __decorate([
        Object(vue_property_decorator_umd["Emit"])("on-cancel")
    ], CityPicker.prototype, "emitCancel", null);
    CityPicker = __decorate([
        vue_class_component_common_default()({
            components: {}
        })
    ], CityPicker);
    return CityPicker;
}(vue_esm["default"]));
/* harmony default export */ var city_picker = (city_picker_CityPicker);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-735a4790","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/common/city-picker.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component city-picker"},[_c('van-popup',{attrs:{"position":"bottom","overlay":false},model:{value:(_vm.visible),callback:function ($$v) {_vm.visible=$$v},expression:"visible"}},[_c('van-picker',{attrs:{"value-key":"label","show-toolbar":"","columns":_vm.columns},on:{"cancel":_vm.onCancel,"confirm":_vm.onConfirm,"change":_vm.onChange}})],1)],1)}
var staticRenderFns = []

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/component-normalizer.js
var component_normalizer = __webpack_require__("XyMi");

// CONCATENATED MODULE: ./src/components/common/city-picker.vue
function injectStyle (context) {
  __webpack_require__("stHo")
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-735a4790"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(component_normalizer["a" /* default */])(
  city_picker,
  render,
  staticRenderFns,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var common_city_picker = __webpack_exports__["a"] = (Component.exports);


/***/ }),

/***/ "TvMv":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".nav-bar[data-v-543b8621]{text-align:left}.nav-bar .van-popup--right[data-v-543b8621]{height:100%;margin-top:45px;width:60%}", ""]);

// exports


/***/ }),

/***/ "WDiC":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".component.loading .sk-cube-grid[data-v-48967eba]{width:40px;height:40px;margin:100px auto}.component.loading .sk-cube-grid .sk-cube[data-v-48967eba]{width:33%;height:33%;background-color:#4b79bd;float:left;-webkit-animation:sk-cubeGridScaleDelay-data-v-48967eba 1.3s infinite ease-in-out;animation:sk-cubeGridScaleDelay-data-v-48967eba 1.3s infinite ease-in-out}.component.loading .sk-cube-grid .sk-cube1[data-v-48967eba]{-webkit-animation-delay:.2s;animation-delay:.2s}.component.loading .sk-cube-grid .sk-cube2[data-v-48967eba]{-webkit-animation-delay:.3s;animation-delay:.3s}.component.loading .sk-cube-grid .sk-cube3[data-v-48967eba]{-webkit-animation-delay:.4s;animation-delay:.4s}.component.loading .sk-cube-grid .sk-cube4[data-v-48967eba]{-webkit-animation-delay:.1s;animation-delay:.1s}.component.loading .sk-cube-grid .sk-cube5[data-v-48967eba]{-webkit-animation-delay:.2s;animation-delay:.2s}.component.loading .sk-cube-grid .sk-cube6[data-v-48967eba]{-webkit-animation-delay:.3s;animation-delay:.3s}.component.loading .sk-cube-grid .sk-cube7[data-v-48967eba]{-webkit-animation-delay:0s;animation-delay:0s}.component.loading .sk-cube-grid .sk-cube8[data-v-48967eba]{-webkit-animation-delay:.1s;animation-delay:.1s}.component.loading .sk-cube-grid .sk-cube9[data-v-48967eba]{-webkit-animation-delay:.2s;animation-delay:.2s}@-webkit-keyframes sk-cubeGridScaleDelay-data-v-48967eba{0%,70%,to{-webkit-transform:scale3D(1,1,1);transform:scale3D(1,1,1)}35%{-webkit-transform:scale3D(0,0,1);transform:scale3D(0,0,1)}}@keyframes sk-cubeGridScaleDelay-data-v-48967eba{0%,70%,to{-webkit-transform:scale3D(1,1,1);transform:scale3D(1,1,1)}35%{-webkit-transform:scale3D(0,0,1);transform:scale3D(0,0,1)}}", ""]);

// exports


/***/ }),

/***/ "XYt4":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".payment-record .break-line[data-v-530882c9]{background-color:#f2f2f2;height:10px}.payment-record-table[data-v-530882c9]{text-align:center;line-height:40px}.payment-record-table-title[data-v-530882c9]{font-size:.9rem;font-weight:700}.payment-record-table-content[data-v-530882c9]{font-size:.8rem;color:gray}.payment-record-table-content-money[data-v-530882c9]{text-align:right;padding-right:8px}.payment-record-table-content-state3[data-v-530882c9]{color:red}.payment-record-table-content-state4[data-v-530882c9]{color:#daa520}.payment-record .my-order-no[data-v-530882c9]{margin-top:20%;text-align:center}", ""]);

// exports


/***/ }),

/***/ "Y45R":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".component.car-list .car-list-img[data-v-b809b0d8]{height:120px;max-height:120px}.component.car-list .car[data-v-b809b0d8]{text-align:left}.component.car-list .car-list-item[data-v-b809b0d8]{width:50%;border:1px solid transparent;padding-left:5px;padding-right:5px;height:230px}.component.car-list .car-info[data-v-b809b0d8]{font-size:.8rem;color:gray;margin-left:15px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.component.car-list .car-first[data-v-b809b0d8]{font-size:.7rem;color:#daa520}.component.car-list .car-month[data-v-b809b0d8]{font-size:.7rem;color:gray}.component.car-list .car .beyondLittle[data-v-b809b0d8]{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-left:15px}", ""]);

// exports


/***/ }),

/***/ "ZYEF":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/***/ }),

/***/ "ZcqS":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/vue/dist/vue.esm.js
var vue_esm = __webpack_require__("7+uW");

// EXTERNAL MODULE: ./node_modules/vue-class-component/dist/vue-class-component.common.js
var vue_class_component_common = __webpack_require__("c+8m");
var vue_class_component_common_default = /*#__PURE__*/__webpack_require__.n(vue_class_component_common);

// EXTERNAL MODULE: ./src/utils/net.service.ts + 7 modules
var net_service = __webpack_require__("1pVc");

// EXTERNAL MODULE: ./node_modules/vant/es/index.js + 107 modules
var es = __webpack_require__("Fd2+");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("ipus");

// EXTERNAL MODULE: ./src/components/common/city-picker.vue + 2 modules
var city_picker = __webpack_require__("T47b");

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/pages/upload-id-photo-first.vue
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var upload_id_photo_first_Login = /** @class */ (function (_super) {
    __extends(Login, _super);
    function Login() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.value = null;
        _this.arrImg = [];
        _this.photo = "";
        _this.photoTwo = "";
        _this.pickerDialog = false; //  民族弹窗
        _this.optionCity = false; // 城市选择弹窗
        _this.nation = '';
        _this.columns = [];
        _this.columnsTwo = [
            {
                text: '郑州',
                val: '902'
            }, {
                text: '南宁',
                val: '3125'
            }
        ];
        _this.idcard = {
            id_card: '',
            nation: '',
            id_card_validity_period_section: '',
            name: '',
            id_card_address: '',
            headPhoto: '',
            nationalPhoto: '',
            province: '',
            city: '',
        };
        _this.heandCity = ''; // 选择城市
        // 验证规则
        _this.rules = {
            name: { required: true, message: '请输入用户姓名' },
            id_card: [{ required: true, message: "请输入正确的身份证号码" }, { validator: _this.$validator.idCard }],
            nation: { required: true, message: '请选择民族' },
            id_card_address: { required: true, message: '请选择户籍信息' },
            id_card_validity_period_section: { required: true, message: '请输入身份证有效区间', },
        };
        return _this;
    }
    // 选择城市点击事件
    Login.prototype.onCityPickerConfirm = function (currentCitys) {
        this.idcard.province = currentCitys[0];
        this.idcard.city = currentCitys[1];
        this.idcard.id_card_address = currentCitys;
    };
    /**
     * 点击下一步
     */
    Login.prototype.addAffirm = function () {
        var _this = this;
        this.$validator.validate(this.idcard, this.rules).then(function (error) {
            if (!error) {
                for (var i in _this.arrImg) {
                    if (_this.arrImg[i].typeName == 1369) {
                        _this.idcard.headPhoto = _this.arrImg[i].materialUrl;
                    }
                    else if (_this.arrImg[i].typeName == 1370) {
                        _this.idcard.nationalPhoto = _this.arrImg[i].materialUrl;
                    }
                }
                if (_this.idcard.headPhoto == '') {
                    _this.$toast('请先上传身份证头像面');
                    return;
                }
                if (_this.idcard.nationalPhoto == '') {
                    _this.$toast('请先上传身份证国徽面');
                    return;
                }
                _this.$router.push('/upload-id-photo-two');
                _this.idcCard(_this.idcard);
                _this.tenantImg(_this.arrImg);
            }
            else {
                _this.$toast(error);
            }
        });
    };
    /**
     * 点击下拉确定事件
     */
    Login.prototype.onConfirm = function (val) {
        this.idcard.nation = val.value;
        this.nation = this.$dict.getDictName(Number(this.idcard.nation));
        this.pickerDialog = false;
    };
    /***
     * 选择下单城市确定事件
     */
    Login.prototype.onConfirmTwo = function (val) {
        this.selectCity([Number(val.val)]);
        console.log(this.IntoACity, '下单成');
        this.optionCity = false;
    };
    //测试图片上传
    Login.prototype.onRead = function (val, number) {
        var _this = this;
        return function (_a) {
            var file = _a.file;
            net_service["NetService"].upload(file).then(function (x) {
                console.log(x);
                _this[val] = x.localUrl;
                for (var i in _this.arrImg) {
                    if (_this.arrImg[i].typeName == number) {
                        _this.arrImg.splice(i, 1);
                    }
                }
                _this.arrImg.push({
                    // personalId: x.id,
                    uploadName: x.realName,
                    materialType: x.type,
                    dataSize: x.size,
                    materialUrl: x.url,
                    uploadTime: x.createTime,
                    typeName: number,
                });
            });
        };
    };
    /**
     * 图片删除
     */
    Login.prototype.closeIdentityCard = function (val, number) {
        this[val] = '';
        for (var i in this.arrImg) {
            if (this.arrImg[i].typeName == number) {
                this.arrImg.splice(i, 1);
            }
        }
    };
    /**
     * 图片预览
     */
    Login.prototype.lookIdentityCard = function (val) {
        Object(es["a" /* ImagePreview */])([this[val]]);
    };
    Login.prototype.mounted = function () {
        this.clearSelectCity();
        // this.IntoACity = []
        this.columns = this.$dict.getDictData('0486').map(function (v) {
            return Object.assign({ text: v.label }, v);
        });
    };
    __decorate([
        lib["c" /* Mutation */]
    ], Login.prototype, "idcCard", void 0);
    __decorate([
        lib["c" /* Mutation */]
    ], Login.prototype, "tenantImg", void 0);
    __decorate([
        lib["d" /* State */]
    ], Login.prototype, "intoA", void 0);
    __decorate([
        lib["c" /* Mutation */]
    ], Login.prototype, "selectCity", void 0);
    __decorate([
        lib["d" /* State */]
    ], Login.prototype, "IntoACity", void 0);
    __decorate([
        lib["c" /* Mutation */]
    ], Login.prototype, "clearSelectCity", void 0);
    Login = __decorate([
        vue_class_component_common_default()({
            components: {
                CityPicker: city_picker["a" /* default */],
            }
        })
    ], Login);
    return Login;
}(vue_esm["default"]));
/* harmony default export */ var upload_id_photo_first = (upload_id_photo_first_Login);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-46b91782","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/pages/upload-id-photo-first.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"page uploadIdPhotoFirst"},[_c('van-cell',{attrs:{"title":"选择城市","required":"","is-link":"","value":_vm._f("cityConvert")(_vm.IntoACity)},on:{"click":function($event){_vm.optionCity=true}}}),_vm._v(" "),_c('van-row',[_c('van-steps',{attrs:{"active":0,"active-color":"#FFE44D"}},[_c('van-step',[_vm._v("身份证信息")]),_vm._v(" "),_c('van-step',[_vm._v("驾驶证信息")]),_vm._v(" "),_c('van-step',[_vm._v("银行卡信息")])],1)],1),_vm._v(" "),_c('p',{staticClass:"base-info-title"},[_vm._v("请扫描上传承租人身份证照片")]),_vm._v(" "),_c('van-row',[_c('van-row',{staticClass:"imgList"},[_c('van-col',{attrs:{"span":"11"}},[_c('van-uploader',{staticClass:"imgSize headPortrait",attrs:{"result-type":"dataUrl","after-read":_vm.onRead('photo',1369),"accept":"image/gif, image/jpeg","multiple":""}},[(_vm.photo == '')?_c('van-icon',{staticClass:"vanIcon",attrs:{"name":"add"}}):_c('img',{attrs:{"width":"100%","src":_vm.photo,"alt":""}})],1),_vm._v(" "),(!_vm.photo == '')?_c('van-icon',{staticClass:"deleteiconHead",attrs:{"name":"close"},on:{"click":function($event){_vm.closeIdentityCard('photo',1369)}}}):_vm._e(),_vm._v(" "),(!_vm.photo == '')?_c('van-icon',{staticClass:"lookiconHead",attrs:{"name":"password-view"},on:{"click":function($event){_vm.lookIdentityCard('photo')}}}):_vm._e()],1),_vm._v(" "),_c('van-col',{attrs:{"span":"11"}},[_c('van-uploader',{staticClass:"imgSize headPortrait",attrs:{"result-type":"dataUrl","after-read":_vm.onRead('photoTwo',1370),"accept":"image/gif, image/jpeg","multiple":""}},[(_vm.photoTwo == '')?_c('van-icon',{staticClass:"vanIcon",attrs:{"name":"add"}}):_c('img',{attrs:{"width":"100%","src":_vm.photoTwo,"alt":""}})],1),_vm._v(" "),(!_vm.photoTwo == '')?_c('van-icon',{staticClass:"deleteiconHead",attrs:{"name":"close"},on:{"click":function($event){_vm.closeIdentityCard('photoTwo',1370)}}}):_vm._e(),_vm._v(" "),(!_vm.photoTwo == '')?_c('van-icon',{staticClass:"lookiconHead",attrs:{"name":"password-view"},on:{"click":function($event){_vm.lookIdentityCard('photoTwo')}}}):_vm._e()],1)],1),_vm._v(" "),_c('van-row',{staticStyle:{"text-align":"center"}},[_c('van-col',{attrs:{"span":"12"}},[_c('p',{staticStyle:{"font-size":"14px"}},[_vm._v("头像页")])]),_vm._v(" "),_c('van-col',{attrs:{"span":"12"}},[_c('p',{staticStyle:{"font-size":"14px"}},[_vm._v("国徽页")])])],1)],1),_vm._v(" "),_c('van-row',[_c('p',{staticClass:"base-info-title"},[_vm._v("请确认身份证信息是否一致")]),_vm._v(" "),_c('van-cell-group',[_c('van-field',{attrs:{"placeholder":"请输入证件姓名","required":"","label":"证件姓名"},model:{value:(_vm.idcard.name),callback:function ($$v) {_vm.$set(_vm.idcard, "name", $$v)},expression:"idcard.name"}}),_vm._v(" "),_c('van-field',{attrs:{"placeholder":"请输入证件号码","required":"","label":"证件号码"},model:{value:(_vm.idcard.id_card),callback:function ($$v) {_vm.$set(_vm.idcard, "id_card", $$v)},expression:"idcard.id_card"}}),_vm._v(" "),_c('van-field',{attrs:{"label":"民族","placeholder":"请选择民族","required":""},on:{"click":function($event){_vm.pickerDialog=true}},model:{value:(_vm.nation),callback:function ($$v) {_vm.nation=$$v},expression:"nation"}}),_vm._v(" "),_c('van-cell',{attrs:{"title":"户籍信息","required":"","is-link":"","value":_vm._f("cityConvert")(_vm.idcard.id_card_address)},on:{"click":function($event){_vm.$refs['cityPicker'].show()}}}),_vm._v(" "),_c('city-picker',{ref:"cityPicker",attrs:{"required":""},on:{"on-confirm":_vm.onCityPickerConfirm}}),_vm._v(" "),_c('van-field',{attrs:{"placeholder":"请输入有效期","required":"","label":"有效期限"},model:{value:(_vm.idcard.id_card_validity_period_section),callback:function ($$v) {_vm.$set(_vm.idcard, "id_card_validity_period_section", $$v)},expression:"idcard.id_card_validity_period_section"}})],1)],1),_vm._v(" "),_c('van-row',[_c('van-button',{attrs:{"type":"primary","bottom-action":""},on:{"click":_vm.addAffirm}},[_vm._v("下一步")])],1),_vm._v(" "),_c('transition',{attrs:{"name":"fade"}},[_c('van-picker',{directives:[{name:"show",rawName:"v-show",value:(_vm.pickerDialog),expression:"pickerDialog"}],ref:"vanpicker",attrs:{"columns":_vm.columns,"show-toolbar":""},on:{"confirm":_vm.onConfirm,"cancel":function($event){_vm.pickerDialog=false}}})],1),_vm._v(" "),_c('transition',{attrs:{"name":"fade"}},[_c('van-picker',{directives:[{name:"show",rawName:"v-show",value:(_vm.optionCity),expression:"optionCity"}],attrs:{"columns":_vm.columnsTwo,"show-toolbar":""},on:{"confirm":_vm.onConfirmTwo,"cancel":function($event){_vm.optionCity=false}}})],1)],1)}
var staticRenderFns = []

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/component-normalizer.js
var component_normalizer = __webpack_require__("XyMi");

// CONCATENATED MODULE: ./src/pages/upload-id-photo-first.vue
function injectStyle (context) {
  __webpack_require__("qOtP")
  __webpack_require__("9New")
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-46b91782"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(component_normalizer["a" /* default */])(
  upload_id_photo_first,
  render,
  staticRenderFns,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var pages_upload_id_photo_first = __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "aTCw":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".page.uploadIdPhotoTwo .van-step--horizontal.van-step--finish .van-step__circle,.page.uploadIdPhotoTwo .van-step--horizontal.van-step--finish .van-step__line{background-color:#ffe44d}.page.uploadIdPhotoTwo .van-step--horizontal.van-step--finish{color:#ffe44d}.page.uploadIdPhotoTwo .van-step--horizontal:last-child .van-step__title{color:gray}.page.uploadIdPhotoTwo .van-cell--required:before{left:-.3rem;bottom:.3rem;font-size:36px;color:#ffe44d}.page.uploadIdPhotoTwo .van-cell{margin:0 auto 0 3%;border-bottom:1px solid #e8e8e8;width:97%}.page.uploadIdPhotoTwo .van-button--bottom-action.van-button--primary{background-color:#ffe44d;position:fixed;bottom:0}.page.uploadIdPhotoTwo .van-picker{position:fixed;width:100%;bottom:0;z-index:100}.page.uploadIdPhotoTwo .icon.iconfont.icon-jiahao.add.van-icon.van-icon-undefined{font-size:60px;line-height:150px}.page.uploadIdPhotoTwo .imgSize.headPortrait.van-uploader{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}", ""]);

// exports


/***/ }),

/***/ "afVn":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./src/config/enum.config.ts
var enum_config = __webpack_require__("mfkW");

// CONCATENATED MODULE: ./src/config/server/manage-service/app-login.controller.ts

var SERVICE = 'service-manage';
var CONTROLLER = 'appLogin';
/* harmony default export */ var app_login_controller = ({
    /**
     * 获取验证码
     */
    getVerifyCode: {
        service: SERVICE,
        controller: CONTROLLER,
        action: 'appGetPersonalVericationCode',
        type: enum_config["requestType"].Get
    },
    /**
     * 根据验证码登陆
     */
    verifyCodeLogin: {
        service: SERVICE,
        controller: CONTROLLER,
        action: 'appVerificationLogin',
        type: enum_config["requestType"].Post
    },
    /**
    * 检测验证码
    */
    checkToken: {
        service: SERVICE,
        controller: CONTROLLER,
        action: 'checkToken',
        type: enum_config["requestType"].Get
    },
    /**
    * 退出
    */
    exit: {
        service: SERVICE,
        controller: CONTROLLER,
        action: 'exit',
        type: enum_config["requestType"].Post
    }
});
// CONCATENATED MODULE: ./src/config/server/manage-service/data-dict-type.controller.ts
// 数字字典controller

var data_dict_type_controller_SERVICE = 'service-manage';
var data_dict_type_controller_CONTROLLER = 'dataDictType';
/* harmony default export */ var data_dict_type_controller = ({
    /**
     * 查询所有数据字典类型
     */
    getAllDictType: {
        service: data_dict_type_controller_SERVICE,
        controller: data_dict_type_controller_CONTROLLER,
        action: 'getAllDictType',
        type: enum_config["requestType"].Get
    },
    /**
    * 新增或修改数据字典类型
    */
    createOrModifyDataDictType: {
        service: data_dict_type_controller_SERVICE,
        controller: data_dict_type_controller_CONTROLLER,
        action: 'createOrModifyDataDictType',
        type: enum_config["requestType"].Post
    }
});
// CONCATENATED MODULE: ./src/config/server/manage-service/data-dict.controller.ts
// 数字字典对应的详细信息controller

var data_dict_controller_SERVICE = 'service-manage';
var data_dict_controller_CONTROLLER = 'dataDict';
/* harmony default export */ var data_dict_controller = ({
    /**
     * 查询数字字典对应的数据字典项
     */
    getDataDictByTypeCode: {
        service: data_dict_controller_SERVICE,
        controller: data_dict_controller_CONTROLLER,
        action: 'getDataDictByTypeCode',
        type: enum_config["requestType"].Get
    },
    /**
     * 新增/修改数据字典项
     */
    createOrModifyDataDict: {
        service: data_dict_controller_SERVICE,
        controller: data_dict_controller_CONTROLLER,
        action: 'createOrModifyDataDict',
        type: enum_config["requestType"].Post
    },
    /**
     * 删除数据字典项
    */
    deleteDataDict: {
        service: data_dict_controller_SERVICE,
        controller: data_dict_controller_CONTROLLER,
        action: 'deleteDataDict',
        type: enum_config["requestType"].Delete
    },
    /**
     * 根据条件搜索对应的数字字典项
    */
    getAllDataDict: {
        service: data_dict_controller_SERVICE,
        controller: data_dict_controller_CONTROLLER,
        action: 'getAllDataDict',
        type: enum_config["requestType"].Get
    },
    /**
     * 查询所有数据字典项(无typeCode)
    */
    getAll: {
        service: data_dict_controller_SERVICE,
        controller: data_dict_controller_CONTROLLER,
        action: 'getAll',
        type: enum_config["requestType"].Get
    },
    /**
    * 获取字典HASH
    */
    getDictHash: {
        service: data_dict_controller_SERVICE,
        controller: data_dict_controller_CONTROLLER,
        action: 'getHashCode',
        type: 'GET'
    },
    /**
     * 获取字典数据
     */
    getDictData: {
        service: data_dict_controller_SERVICE,
        controller: data_dict_controller_CONTROLLER,
        action: 'getAll',
        type: 'GET'
    },
    /**
     * 获取字典数据
     */
    getDataDictByTypeCodeWithPage: {
        service: data_dict_controller_SERVICE,
        controller: data_dict_controller_CONTROLLER,
        action: 'getDataDictByTypeCodeWithPage',
        type: 'GET'
    }
});
// CONCATENATED MODULE: ./src/config/server/manage-service/product-order.controller.ts
// 进件 

var product_order_controller_SERVICE = 'service-manage';
var product_order_controller_CONTROLLER = 'productOrder';
/* harmony default export */ var product_order_controller = ({
    /**
     * 进件
     */
    createOrder: {
        service: product_order_controller_SERVICE,
        controller: product_order_controller_CONTROLLER,
        action: 'createOrder',
        type: enum_config["requestType"].Post
    },
    /**
     * 获取订单
     */
    getOrder: {
        service: product_order_controller_SERVICE,
        controller: product_order_controller_CONTROLLER,
        action: 'getAppProductOrderInfo',
        type: enum_config["requestType"].Get
    },
    /**
    * 获取订单基本数据
    */
    findOrderInfoByOrderNumber: {
        service: product_order_controller_SERVICE,
        controller: product_order_controller_CONTROLLER,
        action: 'findOrderInfoByOrderNumber',
        type: enum_config["requestType"].Get
    }
});
// CONCATENATED MODULE: ./src/config/server/manage-service/car-show-management.controller.ts
// 首页

var car_show_management_controller_SERVICE = 'service-manage';
var car_show_management_controller_CONTROLLER = 'carShowManagement';
/* harmony default export */ var car_show_management_controller = ({
    /**
     * 首页品牌列表
     */
    getTopTenCarBrandList: {
        service: car_show_management_controller_SERVICE,
        controller: car_show_management_controller_CONTROLLER,
        action: 'getTopTenCarBrandList',
        type: enum_config["requestType"].Get
    },
    /**
     * 获取全部品牌
     */
    getAllCarBrandList: {
        service: car_show_management_controller_SERVICE,
        controller: car_show_management_controller_CONTROLLER,
        action: 'getAllCarBrandList',
        type: enum_config["requestType"].Get
    },
    /**
     * 获取热门车辆
     */
    getGoodCarShowModelList: {
        service: car_show_management_controller_SERVICE,
        controller: car_show_management_controller_CONTROLLER,
        action: 'getGoodCarShowModelList',
        type: enum_config["requestType"].Get
    },
    /**
     * 车辆列表
     */
    getCarShowModelListByBrandIdAndName: {
        service: car_show_management_controller_SERVICE,
        controller: car_show_management_controller_CONTROLLER,
        action: 'getCarShowModelListByBrandIdAndName',
        type: enum_config["requestType"].Get
    }
});
// CONCATENATED MODULE: ./src/config/server/manage-service/car-management.controller.ts
// 车辆详情

var car_management_controller_SERVICE = 'service-manage';
var car_management_controller_CONTROLLER = 'carManagement';
/* harmony default export */ var car_management_controller = ({
    /**
     * 根据车辆id查询车辆属性列表
     */
    getCarParamList: {
        service: car_management_controller_SERVICE,
        controller: car_management_controller_CONTROLLER,
        action: 'getCarParamList',
        type: enum_config["requestType"].Get
    },
    /***
     * 获取车辆信息
     */
    getCarDetail: {
        service: car_management_controller_SERVICE,
        controller: car_management_controller_CONTROLLER,
        action: 'getCarDetail',
        type: enum_config["requestType"].Get
    },
    /***
     * 通过carId查找出栏目信息
     */
    getCarColumnCollectModel: {
        service: car_management_controller_SERVICE,
        controller: car_management_controller_CONTROLLER,
        action: 'getCarColumnCollectModel',
        type: enum_config["requestType"].Get
    },
    /***
     * 获取车辆详情首页图片
     */
    getCarPictureList: {
        service: car_management_controller_SERVICE,
        controller: car_management_controller_CONTROLLER,
        action: 'getCarPictureList',
        type: enum_config["requestType"].Get
    }
});
// CONCATENATED MODULE: ./src/config/server/manage-service/product.controller.ts
// 车辆详情 根据选择 价格期数显示对应数据

var product_controller_SERVICE = 'service-manage';
var product_controller_CONTROLLER = 'product';
/* harmony default export */ var product_controller = ({
    /**
     * 车辆详情3级联动选择价格
     */
    getCarProductResultModelList: {
        service: product_controller_SERVICE,
        controller: product_controller_CONTROLLER,
        action: 'getCarProductResultModelList',
        type: enum_config["requestType"].Get
    }
});
// CONCATENATED MODULE: ./src/config/server/manage-service/payment-schedule-controller.controller.ts
// 还款详情

var payment_schedule_controller_controller_SERVICE = 'service-manage';
var payment_schedule_controller_controller_CONTROLLER = 'paymentScheduleController';
/* harmony default export */ var payment_schedule_controller_controller = ({
    /**
     * 还款详情
     */
    getPaymentScheduleList: {
        service: payment_schedule_controller_controller_SERVICE,
        controller: payment_schedule_controller_controller_CONTROLLER,
        action: 'getPaymentScheduleList',
        type: enum_config["requestType"].Get
    }
});
// CONCATENATED MODULE: ./src/config/server/manage-service/contract-details-controller.controller.ts
// 查询订单合同

var contract_details_controller_controller_SERVICE = 'service-manage';
var contract_details_controller_controller_CONTROLLER = 'contractDetailsController';
/* harmony default export */ var contract_details_controller_controller = ({
    /**
     *  查看订单合同
     */
    getContractDetailsListByOrderId: {
        service: contract_details_controller_controller_SERVICE,
        controller: contract_details_controller_controller_CONTROLLER,
        action: 'getContractDetailsListByOrderId',
        type: enum_config["requestType"].Get
    }
});
// CONCATENATED MODULE: ./src/config/server/manage-service/index.ts
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return manageService; });









var manageService = {
    appLoginController: app_login_controller,
    dataDictTypeController: data_dict_type_controller,
    dataDictController: data_dict_controller,
    productOrderController: product_order_controller,
    carShowManagementController: car_show_management_controller,
    carManagementController: car_management_controller,
    productController: product_controller,
    paymentScheduleController: payment_schedule_controller_controller,
    contractDetailsController: contract_details_controller_controller
};

/***/ }),

/***/ "bMu+":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("unnt");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("2c7537c0", content, true, {});

/***/ }),

/***/ "bn4k":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".question-title-icon[data-v-9f464e00]{background-color:#ff0;width:30px;border-radius:5px;display:table-cell;vertical-align:middle;text-align:center;height:30px}.question-title-content[data-v-9f464e00]{font-weight:700;display:table-cell;vertical-align:middle;text-align:center;height:30px}.question-content[data-v-9f464e00]{font-size:.9rem;text-align:left;text-indent:1rem}", ""]);

// exports


/***/ }),

/***/ "ckpd":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("bn4k");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("a215f6c2", content, true, {});

/***/ }),

/***/ "dVU4":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".home[data-v-69e16561]{text-align:center}.home-nav-bar[data-v-69e16561]{padding-left:10px;padding-right:10px}.break-line[data-v-69e16561]{background-color:#f2f2f2;height:10px}.describe[data-v-69e16561]{width:100%;color:#666;margin-bottom:10px}.content[data-v-69e16561]{text-align:center;margin-top:20px;margin-bottom:20px}.siftCar[data-v-69e16561]{margin:10px}", ""]);

// exports


/***/ }),

/***/ "dmbO":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("Srf9");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("edf9d06c", content, true, {});

/***/ }),

/***/ "evdC":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".subscribe[data-v-3dca372e]{text-align:center}.title[data-v-3dca372e]{margin-top:40px;margin-bottom:20px}.buy-form[data-v-3dca372e],.buy-info[data-v-3dca372e]{margin-bottom:20px}.buy-success[data-v-3dca372e]{margin-top:20px;margin-bottom:20px}.buy-success-info[data-v-3dca372e]{font-size:.8rem;color:gray;margin-bottom:20px}", ""]);

// exports


/***/ }),

/***/ "f3r7":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["b"] = Dependencies;
/* harmony export (immutable) */ __webpack_exports__["c"] = Inject;
/* harmony export (immutable) */ __webpack_exports__["a"] = Debounce;
/* unused harmony export Layout */
/* unused harmony export Auth */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_reflect_metadata__ = __webpack_require__("I8yv");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_reflect_metadata___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_reflect_metadata__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_vue_class_component__ = __webpack_require__("c+8m");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_vue_class_component___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_vue_class_component__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_vue_inject__ = __webpack_require__("GeUp");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_vue_inject___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_vue_inject__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_rxjs__ = __webpack_require__("Gvdl");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_rxjs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_rxjs__);




/**
 * 组件内依赖注入
 * @param target
 */
function Dependencies(target) {
    return Object(__WEBPACK_IMPORTED_MODULE_1_vue_class_component__["createDecorator"])(function (componentOptions, key) {
        if (!__WEBPACK_IMPORTED_MODULE_2_vue_inject___default.a.$$factories[key] && target) {
            __WEBPACK_IMPORTED_MODULE_2_vue_inject___default.a.service(key, target);
        }
        if (typeof componentOptions['dependencies'] === 'undefined') {
            componentOptions['dependencies'] = [];
        }
        if (Array.isArray(componentOptions['dependencies'])) {
            componentOptions['dependencies'].push(key);
        }
    });
}
/**
 * 直接依赖注入
 */
function Inject(target) {
    return function (container, key) {
        if (!__WEBPACK_IMPORTED_MODULE_2_vue_inject___default.a.$$factories[key] && target) {
            __WEBPACK_IMPORTED_MODULE_2_vue_inject___default.a.service(key, target).lift;
        }
        try {
            container[key] = __WEBPACK_IMPORTED_MODULE_2_vue_inject___default.a.get(key);
        } catch (ex) {
            console.warn(ex);
        }
    };
}
/**
 * 函数去抖动
 * @param time
 */
function Debounce(time) {
    if (time === void 0) {
        time = 500;
    }
    return function (target, name, descriptor) {
        var oldValue = descriptor.value;
        var flag;
        descriptor.value = function () {
            if (flag) {
                return __WEBPACK_IMPORTED_MODULE_3_rxjs__["Observable"].empty();
            } else {
                flag = setTimeout(function () {
                    flag = null;
                }, time);
            }
            return oldValue.apply(target, arguments);
        };
        return descriptor;
    };
}
/**
 * 设置布局
 * @param target
 */
function Layout(layout) {
    return function (target) {
        target.$layout = layout;
        return target;
    };
}
/**
 * 权限码中间件
 * @param target
 */
function Auth(code) {
    return function (target) {
        target.$auth = code;
        return target;
    };
}

/***/ }),

/***/ "f8Av":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("AEoA");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("36199b8a", content, true, {});

/***/ }),

/***/ "fabK":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".page.details-scheme .downPaymentRow .van-col,.page.details-scheme .periodsRow .van-col{margin:10px}.page.details-scheme .dropDown{padding-left:13px;font-weight:600;font-size:13px}.page.details-scheme .dropDown .van-cell__title{color:grey}.page.details-scheme .dropDown .van-cell__value{color:#666}.page.details-scheme .van-collapse-item__content{padding:2px 0}.page.details-scheme .van-cell.van-cell--clickable.van-hairline{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center}.page.details-scheme .van-cell__value{color:grey}.page.details-scheme .headSwitch .van-tab,.page.details-scheme .headSwitch .van-tabs__nav--card{border:none}.page.details-scheme .headSwitch .van-tabs__nav.van-tabs__nav--card{position:relative;right:20px}.page.details-scheme .headSwitch .van-tab .van-ellipsis{border:1px solid grey;color:gray;font-size:13px}.page.details-scheme .headSwitch .van-tab--active{background:#fff;color:#ffd753}.page.details-scheme .headSwitch .van-tab.van-tab--active .van-ellipsis{border:1px solid #ffd753;color:#ffd753}.page.details-scheme .carDetails .van-cell-group.van-hairline--top-bottom{padding-left:13px}.page.details-scheme .carDetails .van-cell__title{color:grey;font-weight:600;font-size:13px}.page.details-scheme .carDetails .van-cell__value{color:#666;font-weight:600;font-size:13px}", ""]);

// exports


/***/ }),

/***/ "hZOI":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("/kJb");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("a8e3e760", content, true, {});

/***/ }),

/***/ "iCaX":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("aTCw");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("282672d7", content, true, {});

/***/ }),

/***/ "iX+j":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/vue/dist/vue.esm.js
var vue_esm = __webpack_require__("7+uW");

// EXTERNAL MODULE: ./node_modules/vue-class-component/dist/vue-class-component.common.js
var vue_class_component_common = __webpack_require__("c+8m");
var vue_class_component_common_default = /*#__PURE__*/__webpack_require__.n(vue_class_component_common);

// EXTERNAL MODULE: ./src/core/decorator.ts
var decorator = __webpack_require__("f3r7");

// EXTERNAL MODULE: ./src/services/manage-service/car-show-management.service.ts
var car_show_management_service = __webpack_require__("2OOm");

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/pages/all-vehicles.vue
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var all_vehicles_allVehicles = /** @class */ (function (_super) {
    __extends(allVehicles, _super);
    function allVehicles() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.trademarks = [];
        return _this;
    }
    allVehicles.prototype.Allcar = function (index, id) {
        this.$router.push("/buy-car-list/" + id);
    };
    allVehicles.prototype.fristVehicleBrand = function () {
        var _this = this;
        this.carShowManagementService.getAllCarBrandList().subscribe(function (data) {
            // console.log(data)
            _this.trademarks = data;
        }, function (err) { return _this.$toast(err.msg); });
    };
    allVehicles.prototype.mounted = function () {
        this.fristVehicleBrand();
    };
    __decorate([
        Object(decorator["b" /* Dependencies */])(car_show_management_service["a" /* carShowManagementService */])
    ], allVehicles.prototype, "carShowManagementService", void 0);
    allVehicles = __decorate([
        vue_class_component_common_default()({
            components: {}
        })
    ], allVehicles);
    return allVehicles;
}(vue_esm["default"]));
/* harmony default export */ var all_vehicles = (all_vehicles_allVehicles);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-2e872e26","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/pages/all-vehicles.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"page all-vehicles"},_vm._l((_vm.trademarks),function(item,index){return _c('div',{key:index,staticClass:"logo"},[_c('div',{on:{"click":function($event){_vm.Allcar(index,item.id)}}},[_c('img',{attrs:{"height":"40px","src":item.logoUrl,"alt":""}}),_vm._v(" "),_c('div',{staticClass:"logoDetails"},[_vm._v(_vm._s(item.brandName))])])])}))}
var staticRenderFns = []

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/component-normalizer.js
var component_normalizer = __webpack_require__("XyMi");

// CONCATENATED MODULE: ./src/pages/all-vehicles.vue
function injectStyle (context) {
  __webpack_require__("j1lW")
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-2e872e26"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(component_normalizer["a" /* default */])(
  all_vehicles,
  render,
  staticRenderFns,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var pages_all_vehicles = __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "j1lW":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("30eR");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("5068e0df", content, true, {});

/***/ }),

/***/ "jMoL":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("/owb");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("f70171ac", content, true, {});

/***/ }),

/***/ "jukp":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("Y45R");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("afe99800", content, true, {});

/***/ }),

/***/ "mfkW":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "requestType", function() { return requestType; });
var requestType = {
    Delete: "DELETE",
    Get: "GET",
    Post: "POST",
    Put: "PUT"
};

/***/ }),

/***/ "n1AL":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/***/ }),

/***/ "nBIJ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/vue/dist/vue.esm.js
var vue_esm = __webpack_require__("7+uW");

// EXTERNAL MODULE: ./node_modules/vue-class-component/dist/vue-class-component.common.js
var vue_class_component_common = __webpack_require__("c+8m");
var vue_class_component_common_default = /*#__PURE__*/__webpack_require__.n(vue_class_component_common);

// EXTERNAL MODULE: ./src/assets/area.ts
var assets_area = __webpack_require__("6z/E");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("ipus");

// EXTERNAL MODULE: ./src/components/common/city-picker.vue + 2 modules
var city_picker = __webpack_require__("T47b");

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/pages/custom-information.vue
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var custom_information_Login = /** @class */ (function (_super) {
    __extends(Login, _super);
    function Login() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.marriageBot = false; // 婚姻状况
        _this.marriages = [];
        _this.educationBot = false; // 学历信息
        _this.educations = [];
        _this.situationBot = false; // 居住情况
        _this.situations = [];
        _this.agelimitBot = false; // 居住年限
        _this.agelimits = [];
        _this.workingBot = false; // 工作情况
        _this.workings = [];
        _this.natureUnitBot = false; // 单位性质
        _this.natureUnits = [];
        _this.yearsWorkingBot = false; // 工作年限
        _this.yearsWorkings = [];
        _this.value = null;
        _this.inforModel = {
            phone: "",
            contactPhone: "",
            area: "",
            address: "",
            companyName: "",
            companyAdress: "",
            companyPhone: "",
            afterSalary: null,
            falseMarital: '',
            marital: "",
            falseeducation: '',
            education: '',
            falseSituation: '',
            situation: '',
            falseAgelimit: '',
            agelimit: '',
            falseWorking: '',
            working: '',
            falsenatureUnit: "",
            natureUnit: '',
            falseYearsWorking: '',
            yearsWorking: '',
            province1: '',
            city1: '',
            district1: '',
        };
        _this.show = {
            phone: false,
            contactPhone: false,
            living: false,
            livingYear: false,
            area: false,
            marital: false,
            educate: false // 学历信息
        };
        _this.columns = {
            educate: ['本科', '专科', '博士'],
            dataList: assets_area["a" /* default */],
            marital: ["未婚", "已婚", "丧偶", "离婚"]
        };
        // 验证规则
        _this.rules = {
            contactPhone: [{ message: "请输入正确的联系号码" }, { validator: _this.$validator.phoneNumber }],
            falseMarital: { required: true, message: '请选择婚姻状况' },
            falseeducation: { required: true, message: '请选择学历信息' },
            falseSituation: { required: true, message: '请选择居住情况' },
            falseAgelimit: { required: true, message: '请选择居住年限' },
            area: { required: true, message: '请选择居民地区' },
            address: { required: true, message: '请输入居民地址' },
            falseWorking: { required: true, message: '请选择工作情况' },
        };
        return _this;
        // onAreaConfirmClick(val) {
        //   // console.log(val)
        //   this.inforModel.province1 = val[0].name
        //   this.inforModel.city1 = val[1].name
        //   this.inforModel.district1 = val[2].name
        //   if (val && val.length >= 2) {
        //     this.inforModel.area = val[0].name + " " + val[1].name + " " + val[2].name
        //   }
        //   this.show.area = false
        // }
    }
    Login.prototype.onCityPickerConfirm = function (currentCitys) {
        this.inforModel.province1 = currentCitys[0];
        this.inforModel.city1 = currentCitys[1];
        this.inforModel.district1 = currentCitys[2];
        this.inforModel.area = currentCitys;
    };
    /**
     * 婚姻状况点击确定
     */
    Login.prototype.marriagefirm = function (val) {
        this.inforModel.marital = val.value;
        this.inforModel.falseMarital = this.$dict.getDictName(Number(this.inforModel.marital));
        this.marriageBot = false;
    };
    /**
     * 学历信息点击确定
     */
    Login.prototype.educationfirm = function (val) {
        this.inforModel.education = val.value;
        this.inforModel.falseeducation = this.$dict.getDictName(Number(this.inforModel.education));
        this.educationBot = false;
    };
    /**
     * 居住情况点击确定
     */
    Login.prototype.situationfirm = function (val) {
        this.inforModel.situation = val.value;
        this.inforModel.falseSituation = this.$dict.getDictName(Number(this.inforModel.situation));
        this.situationBot = false;
    };
    /**
     * 居住年限
     */
    Login.prototype.agelimitfirm = function (val) {
        this.inforModel.agelimit = val.value;
        this.inforModel.falseAgelimit = this.$dict.getDictName(Number(this.inforModel.agelimit));
        this.agelimitBot = false;
    };
    /**
     * 工作情况
     */
    Login.prototype.workingfirm = function (val) {
        this.inforModel.working = val.value;
        this.inforModel.falseWorking = this.$dict.getDictName(Number(this.inforModel.working));
        this.workingBot = false;
    };
    /**
     * 单位性质点击确定
     */
    Login.prototype.natureUnitfirm = function (val) {
        this.inforModel.natureUnit = val.value;
        this.inforModel.falsenatureUnit = this.$dict.getDictName(Number(this.inforModel.natureUnit));
        this.natureUnitBot = false;
    };
    /**
     * 工作年限点击确定
     */
    Login.prototype.yearsWorkingfirm = function (val) {
        this.inforModel.yearsWorking = val.value;
        this.inforModel.falseYearsWorking = this.$dict.getDictName(Number(this.inforModel.yearsWorking));
        this.yearsWorkingBot = false;
    };
    // verifyPhone(rule, value, callback) {
    //   if (value !== '') {
    //     if (!(/^((\d{3,4}-)|\d{3.4}-)?\d{7,8}$/).test(value)) {
    //       callback(new Error('请输入正确的单位电话'));
    //     } 
    //   }else{
    //     callback()
    //   }
    // }
    /**
    * 基本信息 点击下一步
    */
    Login.prototype.informationAffirm = function () {
        var _this = this;
        this.$validator.validate(this.inforModel, this.rules).then(function (error) {
            if (!error) {
                _this.going(_this.inforModel);
                _this.$router.push('/contact-information');
            }
            else {
                _this.$toast(error);
            }
        });
    };
    Login.prototype.mounted = function () {
        // 获取婚姻状况
        this.marriages = this.$dict.getDictData('0003').map(function (v) {
            return Object.assign({ text: v.label }, v);
        });
        // 获取学历信息
        this.educations = this.$dict.getDictData('0002').map(function (v) {
            return Object.assign({ text: v.label }, v);
        });
        // 居住情况
        this.situations = this.$dict.getDictData('0462').map(function (v) {
            return Object.assign({ text: v.label }, v);
        });
        // 居住年限
        this.agelimits = this.$dict.getDictData('0463').map(function (v) {
            return Object.assign({ text: v.label }, v);
        });
        // 工作情况
        this.workings = this.$dict.getDictData('0460').map(function (v) {
            return Object.assign({ text: v.label }, v);
        });
        // 工作性质
        this.natureUnits = this.$dict.getDictData('0012').map(function (v) {
            return Object.assign({ text: v.label }, v);
        });
        // 工作年限
        this.yearsWorkings = this.$dict.getDictData('0461').map(function (v) {
            return Object.assign({ text: v.label }, v);
        });
        // 获取登陆人手机号
        this.inforModel.phone = this.userData.userPhone;
        // console.log(this.userData,'phone')
    };
    /**
     * 数字键盘输入-手机号码
     */
    Login.prototype.inputPhone = function (val) {
        if (this.inforModel.phone.length === 11)
            return;
        this.inforModel.phone += val.toString();
    };
    /**
     * 数字键盘输入-联系号码
     */
    Login.prototype.contactPhone = function (val) {
        if (this.inforModel.contactPhone.length === 11)
            return;
        this.inforModel.contactPhone += val.toString();
    };
    /**
     * 按钮删除操作-手机号码
     */
    Login.prototype.deletePhone = function () {
        var length = this.inforModel.phone.length;
        if (length === 0)
            return;
        this.inforModel.phone = this.inforModel.phone.substring(0, length - 1);
    };
    /**
     * 按钮删除操作-联系号码
     */
    Login.prototype.deleteContactPhone = function () {
        var length = this.inforModel.contactPhone.length;
        if (length === 0)
            return;
        this.inforModel.phone = this.inforModel.contactPhone.substring(0, length - 1);
    };
    Login.prototype.onChange = function (picker, values, index) {
        console.log(values, 'value');
        if (values) {
            this.inforModel.marital = values;
        }
        else {
            this.inforModel.marital = "";
        }
    };
    __decorate([
        lib["d" /* State */]
    ], Login.prototype, "intoA", void 0);
    __decorate([
        lib["c" /* Mutation */]
    ], Login.prototype, "going", void 0);
    __decorate([
        lib["d" /* State */]
    ], Login.prototype, "userData", void 0);
    Login = __decorate([
        vue_class_component_common_default()({
            components: {
                CityPicker: city_picker["a" /* default */],
            }
            // ,
            // filters:{
            //   cityConvert: (values:Array<Number>) =>{
            //     let citys:any = CityService.getCityName(values[0],values[1],values[2])
            //     return citys.join(' ')
            //   }
            // }
        })
    ], Login);
    return Login;
}(vue_esm["default"]));
/* harmony default export */ var custom_information = (custom_information_Login);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-c07d463a","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/pages/custom-information.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"page customInformation"},[_c('van-row',[_c('p',{staticClass:"base-info-title"},[_vm._v("基本信息")]),_vm._v(" "),_c('van-cell-group',[_c('van-field',{attrs:{"disabled":"","label":"手机号码","placeholder":"请输入手机号","required":""},on:{"click":function($event){_vm.show.phone = true}},model:{value:(_vm.inforModel.phone),callback:function ($$v) {_vm.$set(_vm.inforModel, "phone", $$v)},expression:"inforModel.phone"}}),_vm._v(" "),_c('van-field',{attrs:{"label":"联系号码","placeholder":"客户第二个手机号"},on:{"click":function($event){_vm.show.phone = true}},model:{value:(_vm.inforModel.contactPhone),callback:function ($$v) {_vm.$set(_vm.inforModel, "contactPhone", $$v)},expression:"inforModel.contactPhone"}}),_vm._v(" "),_c('van-field',{attrs:{"label":"婚姻状况","placeholder":"请选择婚姻状况","required":""},on:{"click":function($event){_vm.marriageBot=true}},model:{value:(_vm.inforModel.falseMarital),callback:function ($$v) {_vm.$set(_vm.inforModel, "falseMarital", $$v)},expression:"inforModel.falseMarital"}}),_vm._v(" "),_c('van-field',{attrs:{"label":"学历信息","placeholder":"请选择学历信息","required":""},on:{"click":function($event){_vm.educationBot=true}},model:{value:(_vm.inforModel.falseeducation),callback:function ($$v) {_vm.$set(_vm.inforModel, "falseeducation", $$v)},expression:"inforModel.falseeducation"}})],1),_vm._v(" "),_c('van-number-keyboard',{attrs:{"show":_vm.show.phone,"close-button-text":"完成"},on:{"blur":function($event){_vm.show.phone = false},"input":_vm.inputPhone,"delete":_vm.deletePhone}}),_vm._v(" "),_c('van-number-keyboard',{attrs:{"show":_vm.show.contactPhone,"close-button-text":"完成"},on:{"blur":function($event){_vm.show.contactPhone = false},"input":_vm.contactPhone,"delete":_vm.deleteContactPhone}}),_vm._v(" "),_c('transition',{attrs:{"name":"fade"}},[_c('van-picker',{directives:[{name:"show",rawName:"v-show",value:(_vm.marriageBot),expression:"marriageBot"}],ref:"vanpicker",attrs:{"columns":_vm.marriages,"show-toolbar":""},on:{"confirm":_vm.marriagefirm,"cancel":function($event){_vm.marriageBot=false}}})],1),_vm._v(" "),_c('transition',{attrs:{"name":"fade"}},[_c('van-picker',{directives:[{name:"show",rawName:"v-show",value:(_vm.educationBot),expression:"educationBot"}],ref:"vanpicker",attrs:{"columns":_vm.educations,"show-toolbar":""},on:{"confirm":_vm.educationfirm,"cancel":function($event){_vm.educationBot=false}}})],1),_vm._v(" "),_c('transition',{attrs:{"name":"fade"}},[_c('van-picker',{directives:[{name:"show",rawName:"v-show",value:(_vm.situationBot),expression:"situationBot"}],ref:"vanpicker",attrs:{"columns":_vm.situations,"show-toolbar":""},on:{"confirm":_vm.situationfirm,"cancel":function($event){_vm.situationBot=false}}})],1),_vm._v(" "),_c('transition',{attrs:{"name":"fade"}},[_c('van-picker',{directives:[{name:"show",rawName:"v-show",value:(_vm.agelimitBot),expression:"agelimitBot"}],ref:"vanpicker",attrs:{"columns":_vm.agelimits,"show-toolbar":""},on:{"confirm":_vm.agelimitfirm,"cancel":function($event){_vm.agelimitBot=false}}})],1),_vm._v(" "),_c('transition',{attrs:{"name":"fade"}},[_c('van-picker',{directives:[{name:"show",rawName:"v-show",value:(_vm.workingBot),expression:"workingBot"}],ref:"vanpicker",attrs:{"columns":_vm.workings,"show-toolbar":""},on:{"confirm":_vm.workingfirm,"cancel":function($event){_vm.workingBot=false}}})],1),_vm._v(" "),_c('transition',{attrs:{"name":"fade"}},[_c('van-picker',{directives:[{name:"show",rawName:"v-show",value:(_vm.natureUnitBot),expression:"natureUnitBot"}],ref:"vanpicker",attrs:{"columns":_vm.natureUnits,"show-toolbar":""},on:{"confirm":_vm.natureUnitfirm,"cancel":function($event){_vm.natureUnitBot=false}}})],1),_vm._v(" "),_c('transition',{attrs:{"name":"fade"}},[_c('van-picker',{directives:[{name:"show",rawName:"v-show",value:(_vm.yearsWorkingBot),expression:"yearsWorkingBot"}],ref:"vanpicker",attrs:{"columns":_vm.yearsWorkings,"show-toolbar":""},on:{"confirm":_vm.yearsWorkingfirm,"cancel":function($event){_vm.yearsWorkingBot=false}}})],1)],1),_vm._v(" "),_c('van-row',[_c('p',{staticClass:"base-info-title"},[_vm._v("居住信息")]),_vm._v(" "),_c('van-cell-group',[_c('van-field',{attrs:{"required":"","label":"居住情况","placeholder":"请选择居住情况"},on:{"click":function($event){_vm.situationBot=true}},model:{value:(_vm.inforModel.falseSituation),callback:function ($$v) {_vm.$set(_vm.inforModel, "falseSituation", $$v)},expression:"inforModel.falseSituation"}}),_vm._v(" "),_c('van-field',{attrs:{"required":"","label":"居住年限","placeholder":"请选择居住年限"},on:{"click":function($event){_vm.agelimitBot=true}},model:{value:(_vm.inforModel.falseAgelimit ),callback:function ($$v) {_vm.$set(_vm.inforModel, "falseAgelimit", $$v)},expression:"inforModel.falseAgelimit "}}),_vm._v(" "),_c('van-cell',{attrs:{"title":"居民地区","required":"","is-link":"","value":_vm._f("cityConvert")(_vm.inforModel.area)},on:{"click":function($event){_vm.$refs['cityPicker'].show()}}}),_vm._v(" "),_c('city-picker',{ref:"cityPicker",attrs:{"required":""},on:{"on-confirm":_vm.onCityPickerConfirm}}),_vm._v(" "),_c('van-field',{staticClass:"address",attrs:{"type":"textarea","label":"居民地址","required":"","placeholder":"请输入详细的居民地址精确到门牌号"},model:{value:(_vm.inforModel.address),callback:function ($$v) {_vm.$set(_vm.inforModel, "address", $$v)},expression:"inforModel.address"}})],1),_vm._v(" "),_c('van-popup',{attrs:{"position":"bottom"},model:{value:(_vm.show.living),callback:function ($$v) {_vm.$set(_vm.show, "living", $$v)},expression:"show.living"}},[_c('van-picker',{attrs:{"columns":_vm.columns,"show-toolbar":""},on:{"change":_vm.onChange,"confirm":function($event){_vm.show.living=false},"cancel":function($event){_vm.show.living=false}}})],1),_vm._v(" "),_c('van-popup',{attrs:{"position":"bottom"},model:{value:(_vm.show.livingYear),callback:function ($$v) {_vm.$set(_vm.show, "livingYear", $$v)},expression:"show.livingYear"}},[_c('van-picker',{attrs:{"columns":_vm.columns,"show-toolbar":""},on:{"change":_vm.onChange,"confirm":function($event){_vm.show.livingYear=false},"cancel":function($event){_vm.show.livingYear=false}}})],1)],1),_vm._v(" "),_c('van-row',[_c('p',{staticClass:"base-info-title"},[_vm._v("工作信息")]),_vm._v(" "),_c('van-cell-group',[_c('van-field',{attrs:{"required":"","label":"工作情况","placeholder":"请选择工作情况"},on:{"click":function($event){_vm.workingBot=true}},model:{value:(_vm.inforModel.falseWorking),callback:function ($$v) {_vm.$set(_vm.inforModel, "falseWorking", $$v)},expression:"inforModel.falseWorking"}}),_vm._v(" "),_c('van-field',{attrs:{"label":"单位名称","placeholder":"请输入完整的公司名称"},model:{value:(_vm.inforModel.companyName),callback:function ($$v) {_vm.$set(_vm.inforModel, "companyName", $$v)},expression:"inforModel.companyName"}}),_vm._v(" "),_c('van-field',{attrs:{"label":"单位性质","placeholder":"请选择单位性质"},on:{"click":function($event){_vm.natureUnitBot=true}},model:{value:(_vm.inforModel.falsenatureUnit ),callback:function ($$v) {_vm.$set(_vm.inforModel, "falsenatureUnit", $$v)},expression:"inforModel.falsenatureUnit "}}),_vm._v(" "),_c('van-field',{attrs:{"label":"单位地址"},model:{value:(_vm.inforModel.companyAdress),callback:function ($$v) {_vm.$set(_vm.inforModel, "companyAdress", $$v)},expression:"inforModel.companyAdress"}}),_vm._v(" "),_c('van-field',{attrs:{"label":"单位电话","placeholder":"请输入公司电话"},model:{value:(_vm.inforModel.companyPhone),callback:function ($$v) {_vm.$set(_vm.inforModel, "companyPhone", $$v)},expression:"inforModel.companyPhone"}}),_vm._v(" "),_c('van-field',{attrs:{"label":"工作年限","placeholder":"请选择工作年限"},on:{"click":function($event){_vm.yearsWorkingBot=true}},model:{value:(_vm.inforModel.falseYearsWorking),callback:function ($$v) {_vm.$set(_vm.inforModel, "falseYearsWorking", $$v)},expression:"inforModel.falseYearsWorking"}}),_vm._v(" "),_c('van-field',{attrs:{"label":"税后月薪","placeholder":"请输入您税后的月薪"},model:{value:(_vm.inforModel.afterSalary),callback:function ($$v) {_vm.$set(_vm.inforModel, "afterSalary", $$v)},expression:"inforModel.afterSalary"}})],1)],1),_vm._v(" "),_c('van-button',{attrs:{"type":"primary","bottom-action":""},on:{"click":_vm.informationAffirm}},[_vm._v("下一步")])],1)}
var staticRenderFns = []

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/component-normalizer.js
var component_normalizer = __webpack_require__("XyMi");

// CONCATENATED MODULE: ./src/pages/custom-information.vue
function injectStyle (context) {
  __webpack_require__("DW+B")
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-c07d463a"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(component_normalizer["a" /* default */])(
  custom_information,
  render,
  staticRenderFns,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var pages_custom_information = __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "ne3W":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("TvMv");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("4a0d0816", content, true, {});

/***/ }),

/***/ "nmQF":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("tBWe");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("11ab5680", content, true, {});

/***/ }),

/***/ "oD+8":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("GCoC");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("60b7475a", content, true, {});

/***/ }),

/***/ "oFoz":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("1EYD");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("6cd93632", content, true, {});

/***/ }),

/***/ "oplY":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/vue/dist/vue.esm.js
var vue_esm = __webpack_require__("7+uW");

// EXTERNAL MODULE: ./node_modules/vue-class-component/dist/vue-class-component.common.js
var vue_class_component_common = __webpack_require__("c+8m");
var vue_class_component_common_default = /*#__PURE__*/__webpack_require__.n(vue_class_component_common);

// EXTERNAL MODULE: ./node_modules/vant/es/index.js + 107 modules
var es = __webpack_require__("Fd2+");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("ipus");

// EXTERNAL MODULE: ./src/utils/net.service.ts + 7 modules
var net_service = __webpack_require__("1pVc");

// EXTERNAL MODULE: ./src/components/common/city-picker.vue + 2 modules
var city_picker = __webpack_require__("T47b");

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/pages/upload-id-photo-three.vue
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var upload_id_photo_three_Login = /** @class */ (function (_super) {
    __extends(Login, _super);
    function Login() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.idName = null;
        _this.arrAll = [];
        _this.idNumber = null;
        _this.value = null;
        _this.photo = "";
        _this.photoTwo = '';
        _this.pickerDialog = false;
        _this.columns = [];
        _this.depositBank = "";
        _this.personalBank = {
            reserved_phone_number: '',
            deposit_bank: '',
            card_number: '',
            location: '',
            locationProvince: '',
            locationCity: '',
        };
        _this.optionCity = false; // 城市选择弹窗
        _this.columnsTwo = [
            {
                text: '郑州',
                val: '902'
            }, {
                text: '南宁',
                val: '3125'
            }
        ];
        // 验证规则
        _this.rules = {
            deposit_bank: { required: true, message: '请选择开户银行' },
            card_number: [{ required: true, message: "请输入正确的银行卡号" }, { validator: _this.$validator.bankNumber }],
            reserved_phone_number: [{ required: true, message: "请输入正确的手机号" }, { validator: _this.$validator.phoneNumber }],
        };
        return _this;
    }
    /***
    * 选择下单城市确定事件
    */
    Login.prototype.onConfirmTwo = function (val) {
        this.selectCity([Number(val.val)]);
        //  console.log(this.IntoACity)
        this.optionCity = false;
    };
    // 选择银行户籍点击确定
    Login.prototype.onCityPickerConfirm = function (currentCitys) {
        this.personalBank.locationProvince = currentCitys[0];
        this.personalBank.locationCity = currentCitys[1];
        this.personalBank.location = currentCitys;
    };
    /**
     * 点击下一步
     */
    Login.prototype.addAffirm = function () {
        var _this = this;
        // console.log(this.arrAll)
        var arr = [];
        for (var i in this.arrAll) {
            arr.push(this.arrAll[i].typeName);
        }
        if (arr.indexOf(1373) < 0) {
            this.$toast('请上传银行卡正面信息');
            return;
        }
        if (arr.indexOf(1374) < 0) {
            this.$toast('请上传银行卡负面信息');
            return;
        }
        if (!this.IntoACity) {
            this.$toast('请选择城市');
            return;
        }
        this.$validator.validate(this.personalBank, this.rules).then(function (error) {
            if (!error) {
                _this.$router.push('/custom-information');
                _this.bankCard(_this.personalBank);
            }
            else {
                _this.$toast(error);
            }
        });
    };
    /**
     * 点击开户银行
     */
    Login.prototype.onConfirm = function (val) {
        this.personalBank.deposit_bank = val.value;
        this.depositBank = this.$dict.getDictName(Number(this.personalBank.deposit_bank));
        this.pickerDialog = false;
    };
    Login.prototype.mounted = function () {
        this.arrAll = this.intoA.PersonalAdditional;
        console.log(this.intoA, '456545');
        this.columns = this.$dict.getDictData('0456').map(function (v) {
            return Object.assign({ text: v.label }, v);
        });
    };
    /**
  * 图片上传
  */
    Login.prototype.onRead = function (_a) {
        var _this = this;
        var file = _a.file;
        net_service["NetService"].upload(file).then(function (x) {
            _this.photo = x.localUrl;
            for (var i in _this.arrAll) {
                if (_this.arrAll[i].typeName == 1373) {
                    _this.arrAll.splice(i, 1);
                }
            }
            _this.arrAll.push({
                uploadName: x.realName,
                materialType: x.type,
                dataSize: x.size,
                materialUrl: x.url,
                uploadTime: x.createTime,
                typeName: 1373,
            });
        });
    };
    Login.prototype.onReadTwo = function (_a) {
        var _this = this;
        var file = _a.file;
        net_service["NetService"].upload(file).then(function (x) {
            _this.photoTwo = x.localUrl;
            for (var i in _this.arrAll) {
                if (_this.arrAll[i].typeName == 1374) {
                    _this.arrAll.splice(i, 1);
                }
            }
            _this.arrAll.push({
                // personalId: x.id,
                uploadName: x.realName,
                materialType: x.type,
                dataSize: x.size,
                materialUrl: x.url,
                uploadTime: x.createTime,
                typeName: 1374,
            });
        });
    };
    /**
   * 图片删除
   */
    Login.prototype.closeIdentityCard = function (val, number) {
        this[val] = '';
        for (var i in this.arrAll) {
            if (this.arrAll[i].typeName == number) {
                this.arrAll.splice(i, 1);
            }
        }
    };
    /**
     * 图片预览
     */
    Login.prototype.lookIdentityCard = function (val) {
        Object(es["a" /* ImagePreview */])([this[val]]);
    };
    __decorate([
        lib["c" /* Mutation */]
    ], Login.prototype, "bankCard", void 0);
    __decorate([
        lib["c" /* Mutation */]
    ], Login.prototype, "tenantImg", void 0);
    __decorate([
        lib["d" /* State */]
    ], Login.prototype, "intoA", void 0);
    __decorate([
        lib["c" /* Mutation */]
    ], Login.prototype, "selectCity", void 0);
    __decorate([
        lib["d" /* State */]
    ], Login.prototype, "IntoACity", void 0);
    Login = __decorate([
        vue_class_component_common_default()({
            components: {
                CityPicker: city_picker["a" /* default */],
            }
        })
    ], Login);
    return Login;
}(vue_esm["default"]));
/* harmony default export */ var upload_id_photo_three = (upload_id_photo_three_Login);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-5d8853cd","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/pages/upload-id-photo-three.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"page uploadIdPhotoThree"},[_c('van-cell',{attrs:{"title":"选择城市","required":"","is-link":"","value":_vm._f("cityConvert")(_vm.IntoACity)},on:{"click":function($event){_vm.optionCity=true}}}),_vm._v(" "),_c('van-row',[_c('van-steps',{attrs:{"active":2,"active-color":"#FFE44D"}},[_c('van-step',[_vm._v("身份证信息")]),_vm._v(" "),_c('van-step',[_vm._v("驾驶证信息")]),_vm._v(" "),_c('van-step',[_vm._v("银行卡信息")])],1)],1),_vm._v(" "),_c('p',{staticClass:"base-info-title"},[_vm._v("请上传承租人银行卡照片")]),_vm._v(" "),_c('van-row',[_c('van-row',{staticClass:"imgList"},[_c('van-col',{attrs:{"span":"11"}},[_c('van-uploader',{staticClass:"imgSize headPortrait",attrs:{"result-type":"dataUrl","after-read":_vm.onRead,"accept":"image/gif, image/jpeg","multiple":""}},[(_vm.photo == '')?_c('van-icon',{staticClass:"vanIcon",attrs:{"name":"add"}}):_c('img',{attrs:{"width":"100%","src":_vm.photo,"alt":""}})],1),_vm._v(" "),(!_vm.photo == '')?_c('van-icon',{staticClass:"deleteiconHead",attrs:{"name":"close"},on:{"click":function($event){_vm.closeIdentityCard('photo',1373)}}}):_vm._e(),_vm._v(" "),(!_vm.photo == '')?_c('van-icon',{staticClass:"lookiconHead",attrs:{"name":"password-view"},on:{"click":function($event){_vm.lookIdentityCard('photo')}}}):_vm._e()],1),_vm._v(" "),_c('van-col',{attrs:{"span":"11"}},[_c('van-uploader',{staticClass:"imgSize headPortrait",attrs:{"result-type":"dataUrl","after-read":_vm.onReadTwo,"accept":"image/gif, image/jpeg","multiple":""}},[(_vm.photoTwo == '')?_c('van-icon',{staticClass:"vanIcon",attrs:{"name":"add"}}):_c('img',{attrs:{"width":"100%","src":_vm.photoTwo,"alt":""}})],1),_vm._v(" "),(!_vm.photoTwo == '')?_c('van-icon',{staticClass:"deleteiconHead",attrs:{"name":"close"},on:{"click":function($event){_vm.closeIdentityCard('photoTwo',1374)}}}):_vm._e(),_vm._v(" "),(!_vm.photoTwo == '')?_c('van-icon',{staticClass:"lookiconHead",attrs:{"name":"password-view"},on:{"click":function($event){_vm.lookIdentityCard('photoTwo')}}}):_vm._e()],1)],1),_vm._v(" "),_c('van-row',{staticStyle:{"text-align":"center"}},[_c('van-col',{staticStyle:{"font-size":"14px"},attrs:{"span":"12"}},[_vm._v("银行卡正面")]),_vm._v(" "),_c('van-col',{staticStyle:{"font-size":"14px"},attrs:{"span":"12"}},[_vm._v("银行卡反面")])],1)],1),_vm._v(" "),_c('van-row',[_c('p',{staticClass:"base-info-title"},[_vm._v("请确认银行卡信息是否一致")]),_vm._v(" "),_c('van-cell-group',[_c('van-field',{attrs:{"required":"","label":"开户银行","placeholder":"请选择准开户银行"},on:{"click":function($event){_vm.pickerDialog=true}},model:{value:(_vm.depositBank),callback:function ($$v) {_vm.depositBank=$$v},expression:"depositBank"}}),_vm._v(" "),_c('van-field',{attrs:{"placeholder":"请输入开户卡号","label":"银行卡号","required":""},model:{value:(_vm.personalBank.card_number),callback:function ($$v) {_vm.$set(_vm.personalBank, "card_number", $$v)},expression:"personalBank.card_number"}}),_vm._v(" "),_c('van-cell',{attrs:{"title":"银行开户所在地","required":"","is-link":"","value":_vm._f("cityConvert")(_vm.personalBank.location)},on:{"click":function($event){_vm.$refs['cityPicker'].show()}}}),_vm._v(" "),_c('city-picker',{ref:"cityPicker",attrs:{"required":""},on:{"on-confirm":_vm.onCityPickerConfirm}}),_vm._v(" "),_c('van-field',{attrs:{"label":"预留手机号","placeholder":"请输入预留手机号","required":""},model:{value:(_vm.personalBank.reserved_phone_number),callback:function ($$v) {_vm.$set(_vm.personalBank, "reserved_phone_number", $$v)},expression:"personalBank.reserved_phone_number"}})],1)],1),_vm._v(" "),_c('transition',{attrs:{"name":"fade"}},[_c('van-picker',{directives:[{name:"show",rawName:"v-show",value:(_vm.pickerDialog),expression:"pickerDialog"}],ref:"vanpicker",attrs:{"columns":_vm.columns,"show-toolbar":""},on:{"confirm":_vm.onConfirm,"cancel":function($event){_vm.pickerDialog=false}}})],1),_vm._v(" "),_c('transition',{attrs:{"name":"fade"}},[_c('van-picker',{directives:[{name:"show",rawName:"v-show",value:(_vm.optionCity),expression:"optionCity"}],attrs:{"columns":_vm.columnsTwo,"show-toolbar":""},on:{"confirm":_vm.onConfirmTwo,"cancel":function($event){_vm.optionCity=false}}})],1),_vm._v(" "),_c('van-button',{attrs:{"type":"primary","bottom-action":""},on:{"click":_vm.addAffirm}},[_vm._v("下一步")])],1)}
var staticRenderFns = []

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/component-normalizer.js
var component_normalizer = __webpack_require__("XyMi");

// CONCATENATED MODULE: ./src/pages/upload-id-photo-three.vue
function injectStyle (context) {
  __webpack_require__("jMoL")
  __webpack_require__("f8Av")
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-5d8853cd"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(component_normalizer["a" /* default */])(
  upload_id_photo_three,
  render,
  staticRenderFns,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var pages_upload_id_photo_three = __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "q2p1":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("fabK");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("75a8a5cc", content, true, {});

/***/ }),

/***/ "qOtP":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("7Ndf");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("76f4d679", content, true, {});

/***/ }),

/***/ "qesE":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".my-order-no[data-v-4777e23a]{margin-top:20%;text-align:center}.my-order-title[data-v-4777e23a]{height:44px;line-height:44px}.my-order-title .van-col[data-v-4777e23a]{padding-left:15px}.my-order-month-pay[data-v-4777e23a]{font-size:.8rem;color:gray}.my-order-month-pay .van-col[data-v-4777e23a]{padding-left:15px;height:30px;line-height:30px}", ""]);

// exports


/***/ }),

/***/ "rQiK":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/vue/dist/vue.esm.js
var vue_esm = __webpack_require__("7+uW");

// EXTERNAL MODULE: ./node_modules/vue-class-component/dist/vue-class-component.common.js
var vue_class_component_common = __webpack_require__("c+8m");
var vue_class_component_common_default = /*#__PURE__*/__webpack_require__.n(vue_class_component_common);

// EXTERNAL MODULE: ./node_modules/vant/es/index.js + 107 modules
var es = __webpack_require__("Fd2+");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("ipus");

// EXTERNAL MODULE: ./src/utils/net.service.ts + 7 modules
var net_service = __webpack_require__("1pVc");

// EXTERNAL MODULE: ./src/services/manage-service/product-order.service.ts
var product_order_service = __webpack_require__("vpJI");

// EXTERNAL MODULE: ./src/core/decorator.ts
var decorator = __webpack_require__("f3r7");

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/pages/add-information.vue
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var add_information_Login = /** @class */ (function (_super) {
    __extends(Login, _super);
    function Login() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.arrImg = [];
        _this.idName = null;
        _this.idNumber = null;
        _this.value = null;
        _this.activeNames = []; // 当前激活的面板
        _this.pickerDialog = false;
        _this.columns = ['本科', '专科', '博士'];
        _this.imageName = "";
        _this.identityCard = ''; // 手持身份证照片
        _this.showName = '';
        _this.identityCardTwo = '';
        _this.photo = "";
        _this.listImg = '';
        _this.listImg2 = '';
        _this.listImg3 = '';
        _this.listImg4 = '';
        _this.listImg5 = '';
        _this.listImg6 = '';
        _this.listImg7 = '';
        _this.listImg8 = '';
        _this.suretyBot = false;
        _this.suretys = [];
        _this.personalAll = {};
        return _this;
    }
    /**
     * 进件点击确认提交
     */
    Login.prototype.IntoASubmit = function () {
        var _this = this;
        var arr = [];
        for (var i in this.arrImg) {
            arr.push(this.arrImg[i].typeName);
        }
        if (arr.indexOf(1363) < 0) {
            this.$toast('请上传承租人手持身份证照片');
            return;
        }
        if (arr.indexOf(1364) < 0) {
            this.$toast('请上传承租人手持业务员照片');
            return;
        }
        //  personal类
        //  （证件页面）idcard
        this.personalAll = {
            ///
            city: this.IntoACity[0],
            productResultId: this.intoA.orderCarTwo.productResultId,
            productId: this.intoA.orderCarTwo.productId,
            initialPayment: this.intoA.orderCarTwo.initialPayment,
            finalCash: this.intoA.orderCarTwo.finalCash,
            financingAmount: this.intoA.orderCarTwo.financingAmount,
            monthlySupply: this.intoA.orderCarTwo.monthlySupply,
            periods: this.intoA.orderCarTwo.periods,
            personal: {
                // certificateType: null,  
                // driverModel: null, 
                // driverNo: null,        
                // driverTerm:null,
                // idCardAddressDetail:null,
                headPhoto: this.intoA.personal.headPhoto,
                nationalPhoto: this.intoA.personal.nationalPhoto,
                driverPhoto: this.intoA.personalCar.driverPhoto,
                driverVicePhoto: this.intoA.personalCar.driverVicePhoto,
                name: this.intoA.personal.name,
                idCard: this.intoA.personal.id_card,
                nation: this.intoA.personal.nation,
                province: this.intoA.personal.province,
                city: this.intoA.personal.city,
                idCardTerm: this.intoA.personal.id_card_validity_period_section,
                mobileMain: this.intoA.PersonalJob.phone,
                mobileMinor: this.intoA.PersonalJob.contactPhone,
                marital: this.intoA.PersonalJob.marital,
                education: this.intoA.PersonalJob.education,
                livingSituation: this.intoA.PersonalJob.situation,
                livingUsefulTime: this.intoA.PersonalJob.agelimit,
                province1: this.intoA.PersonalJob.province1,
                city1: this.intoA.PersonalJob.city1,
                district1: this.intoA.PersonalJob.district1,
                localHomeAddr: this.intoA.PersonalJob.address,
                usefulTime: this.intoA.personalCar.useful_time,
                fileNumber: this.intoA.personalCar.file_number,
                drivingLicense: this.intoA.personalCar.driving_license,
                personalBank: {
                    depositProvince: this.intoA.personalBank.locationProvince,
                    depositCity: this.intoA.personalBank.locationCity,
                    depositBank: this.intoA.personalBank.deposit_bank,
                    cardNumber: this.intoA.personalBank.card_number,
                    reservedPhoneNumber: this.intoA.personalBank.reserved_phone_number,
                },
                personalJob: {
                    workingCondition: this.intoA.PersonalJob.working,
                    companyName: this.intoA.PersonalJob.companyName,
                    companyNature: this.intoA.PersonalJob.natureUnit,
                    companyAddressDetail: this.intoA.PersonalJob.companyAdress,
                    companyPhone: this.intoA.PersonalJob.companyPhone,
                    workingYears: this.intoA.PersonalJob.yearsWorking,
                    basicSalary: Number(this.intoA.PersonalJob.afterSalary),
                },
            },
            orderCar: {
                brandName: this.intoA.orderCar.brandName,
                interiorColor: this.intoA.orderCar.interiorColor,
                modelName: this.intoA.orderCar.modelName,
                seriesName: this.intoA.orderCar.seriesName,
                vehicleColor: this.intoA.orderCar.vehicleColor,
            },
            personalContacts: [
                {
                    relation: this.intoA.PersonalContact.relation,
                    name: this.intoA.PersonalContact.username,
                    phone: this.intoA.PersonalContact.phone // 联系人姓名
                }, {
                    relation: this.intoA.PersonalContact.relationTwo,
                    name: this.intoA.PersonalContact.usernameTwo,
                    phone: this.intoA.PersonalContact.phoneTwo // 联系人姓名
                }
            ],
        };
        this.personalAll.personalAdditionals = this.intoA.PersonalAdditional;
        // this.personalAll.orderCar = this.intoA.orderCar
        this.clearIntoA();
        this.productOrderService.createOrder(this.personalAll).subscribe(function (data) {
            _this.$router.push({
                name: 'MyOrder',
            });
        }, function (err) { return _this.$toast(err.msg); });
    };
    /**
     * 手持身份证图片事件
     */
    Login.prototype.identityCardFun = function (val, number) {
        var _this = this;
        return function (_a) {
            var file = _a.file;
            net_service["NetService"].upload(file).then(function (x) {
                _this[val] = x.localUrl;
                for (var i in _this.arrImg) {
                    if (_this.arrImg[i].typeName == number) {
                        _this.arrImg.splice(i, 1);
                    }
                }
                _this.arrImg.push({
                    // personalId: x.id,
                    uploadName: x.realName,
                    materialType: x.type,
                    dataSize: x.size,
                    materialUrl: x.url,
                    uploadTime: x.createTime,
                    typeName: number,
                });
            });
        };
    };
    // 点击追加担保人确定事件
    Login.prototype.suretyfirm = function () {
    };
    /**
     * 图片删除
     */
    Login.prototype.closeIdentityCard = function (val, number) {
        this[val] = '';
        for (var i in this.arrImg) {
            if (this.arrImg[i].typeName == number) {
                this.arrImg.splice(i, 1);
            }
        }
    };
    /**
     * 图片预览
     */
    Login.prototype.lookIdentityCard = function (val) {
        Object(es["a" /* ImagePreview */])([this[val]]);
    };
    Login.prototype.mounted = function () {
        this.arrImg = this.intoA.PersonalAdditional;
    };
    __decorate([
        Object(decorator["b" /* Dependencies */])(product_order_service["ProductOrderService"])
    ], Login.prototype, "productOrderService", void 0);
    __decorate([
        lib["c" /* Mutation */]
    ], Login.prototype, "tenantImg", void 0);
    __decorate([
        lib["c" /* Mutation */]
    ], Login.prototype, "clearIntoA", void 0);
    __decorate([
        lib["d" /* State */]
    ], Login.prototype, "intoA", void 0);
    __decorate([
        lib["c" /* Mutation */]
    ], Login.prototype, "selectCity", void 0);
    __decorate([
        lib["d" /* State */]
    ], Login.prototype, "IntoACity", void 0);
    Login = __decorate([
        vue_class_component_common_default()({})
    ], Login);
    return Login;
}(vue_esm["default"]));
/* harmony default export */ var add_information = (add_information_Login);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-01ed606e","hasScoped":false,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/pages/add-information.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"page addInformation"},[_c('van-row',[_c('p',{staticClass:"base-info-title"},[_c('span',{staticClass:"star"},[_vm._v("*")]),_vm._v("承租人手持身份证照片")]),_vm._v(" "),_c('van-row',{staticClass:"imgList"},[_c('van-col',{attrs:{"span":"11"}},[_c('van-uploader',{staticClass:"imgSize imglistTwo headPortrait",attrs:{"result-type":"dataUrl","after-read":_vm.identityCardFun('identityCard',1363),"accept":"image/gif, image/jpeg","multiple":""}},[(_vm.identityCard == '')?_c('van-icon',{staticClass:"vanIcon",attrs:{"name":"add"}}):_c('img',{attrs:{"width":"100%","src":_vm.identityCard,"alt":""}})],1),_vm._v(" "),(!_vm.identityCard == '')?_c('van-icon',{staticClass:"deleteiconHead",attrs:{"name":"close"},on:{"click":function($event){_vm.closeIdentityCard('identityCard',1363)}}}):_vm._e(),_vm._v(" "),(!_vm.identityCard == '')?_c('van-icon',{staticClass:"lookiconHead",attrs:{"name":"password-view"},on:{"click":function($event){_vm.lookIdentityCard('identityCard')}}}):_vm._e()],1)],1)],1),_vm._v(" "),_c('van-row',[_c('p',{staticClass:"base-info-title"},[_c('span',{staticClass:"star"},[_vm._v("*")]),_vm._v("承租人手持业务员照片")]),_vm._v(" "),_c('van-row',{staticClass:"imgList"},[_c('van-col',{attrs:{"span":"11"}},[_c('van-uploader',{staticClass:"imgSize imglistTwo headPortrait",attrs:{"result-type":"dataUrl","after-read":_vm.identityCardFun('identityCardTwo',1364),"accept":"image/gif, image/jpeg","multiple":""}},[(_vm.identityCardTwo == '')?_c('van-icon',{staticClass:"vanIcon",attrs:{"name":"add"}}):_c('img',{attrs:{"width":"100%","src":_vm.identityCardTwo,"alt":""}})],1),_vm._v(" "),(!_vm.identityCardTwo == '')?_c('van-icon',{staticClass:"deleteiconHead",attrs:{"name":"close"},on:{"click":function($event){_vm.closeIdentityCard('identityCardTwo',1364)}}}):_vm._e(),_vm._v(" "),(!_vm.identityCardTwo == '')?_c('van-icon',{staticClass:"lookiconHead",attrs:{"name":"password-view"},on:{"click":function($event){_vm.lookIdentityCard('identityCardTwo')}}}):_vm._e()],1)],1)],1),_vm._v(" "),_c('van-collapse',{model:{value:(_vm.activeNames),callback:function ($$v) {_vm.activeNames=$$v},expression:"activeNames"}},[_c('van-collapse-item',{attrs:{"title":"追加资料（选填）"}},[_c('van-row',{staticClass:"heandClass "},[_c('van-col',[_vm._v("户口本（户主页及个人页")])],1),_vm._v(" "),_c('van-row',{staticClass:"imgList"},[_c('van-col',{attrs:{"span":"11"}},[_c('van-uploader',{staticClass:"imgSize imglistTwo headPortrait",attrs:{"result-type":"dataUrl","after-read":_vm.identityCardFun('listImg',1354),"accept":"image/gif, image/jpeg","multiple":""}},[(_vm.listImg == '')?_c('van-icon',{staticClass:"vanIcon",attrs:{"name":"add"}}):_c('img',{attrs:{"width":"100%","src":_vm.listImg,"alt":""}})],1),_vm._v(" "),(!_vm.listImg == '')?_c('van-icon',{staticClass:"deleteiconHead",attrs:{"name":"close"},on:{"click":function($event){_vm.closeIdentityCard('listImg',1345)}}}):_vm._e(),_vm._v(" "),(!_vm.listImg == '')?_c('van-icon',{staticClass:"lookiconHead",attrs:{"name":"password-view"},on:{"click":function($event){_vm.lookIdentityCard('listImg')}}}):_vm._e()],1)],1),_vm._v(" "),_c('van-row',{staticClass:"heandClass"},[_c('van-col',[_vm._v("结婚证")])],1),_vm._v(" "),_c('van-row',{staticClass:"imgList imglistTwo"},[_c('van-col',{attrs:{"span":"11"}},[_c('van-uploader',{staticClass:"imgSize headPortrait",attrs:{"result-type":"dataUrl","after-read":_vm.identityCardFun('listImg2',1355),"accept":"image/gif, image/jpeg","multiple":""}},[(_vm.listImg2 == '')?_c('van-icon',{staticClass:"vanIcon",attrs:{"name":"add"}}):_c('img',{attrs:{"width":"100%","src":_vm.listImg2,"alt":""}})],1),_vm._v(" "),(!_vm.listImg2 == '')?_c('van-icon',{staticClass:"deleteiconHead",attrs:{"name":"close"},on:{"click":function($event){_vm.closeIdentityCard('listImg2',1355)}}}):_vm._e(),_vm._v(" "),(!_vm.listImg2 == '')?_c('van-icon',{staticClass:"lookiconHead",attrs:{"name":"password-view"},on:{"click":function($event){_vm.lookIdentityCard('listImg2')}}}):_vm._e()],1)],1),_vm._v(" "),_c('van-row',{staticClass:"heandClass"},[_c('van-col',[_vm._v("收入证明（劳动合同/收入证明")])],1),_vm._v(" "),_c('van-row',{staticClass:"imgList imglistTwo"},[_c('van-col',{attrs:{"span":"11"}},[_c('van-uploader',{staticClass:"imgSize headPortrait",attrs:{"result-type":"dataUrl","after-read":_vm.identityCardFun('listImg3',1356),"accept":"image/gif, image/jpeg","multiple":""}},[(_vm.listImg3 == '')?_c('van-icon',{staticClass:"vanIcon",attrs:{"name":"add"}}):_c('img',{attrs:{"width":"100%","src":_vm.listImg3,"alt":""}})],1),_vm._v(" "),(!_vm.listImg3 == '')?_c('van-icon',{staticClass:"deleteiconHead",attrs:{"name":"close"},on:{"click":function($event){_vm.closeIdentityCard('listImg3',1356)}}}):_vm._e(),_vm._v(" "),(!_vm.listImg3 == '')?_c('van-icon',{staticClass:"lookiconHead",attrs:{"name":"password-view"},on:{"click":function($event){_vm.lookIdentityCard('listImg3')}}}):_vm._e()],1)],1),_vm._v(" "),_c('van-row',{staticClass:"heandClass"},[_c('van-col',[_vm._v("近6个月银行流水（柜台打印盖章/网银现场查询）")])],1),_vm._v(" "),_c('van-row',{staticClass:"imgList imglistTwo"},[_c('van-col',{attrs:{"span":"11"}},[_c('van-uploader',{staticClass:"imgSize headPortrait",attrs:{"result-type":"dataUrl","after-read":_vm.identityCardFun('listImg4',1357),"accept":"image/gif, image/jpeg","multiple":""}},[(_vm.listImg4 == '')?_c('van-icon',{staticClass:"vanIcon",attrs:{"name":"add"}}):_c('img',{attrs:{"width":"100%","src":_vm.listImg4,"alt":""}})],1),_vm._v(" "),(!_vm.listImg4 == '')?_c('van-icon',{staticClass:"deleteiconHead",attrs:{"name":"close"},on:{"click":function($event){_vm.closeIdentityCard('listImg4',1357)}}}):_vm._e(),_vm._v(" "),(!_vm.listImg4 == '')?_c('van-icon',{staticClass:"lookiconHead",attrs:{"name":"password-view"},on:{"click":function($event){_vm.lookIdentityCard('listImg4')}}}):_vm._e()],1)],1),_vm._v(" "),_c('van-row',{staticClass:"heandClass"},[_c('van-col',[_vm._v("社保查询（柜台打印盖章/网上现场查询）")])],1),_vm._v(" "),_c('van-row',{staticClass:"imgList imglistTwo"},[_c('van-col',{attrs:{"span":"11"}},[_c('van-uploader',{staticClass:"imgSize headPortrait",attrs:{"result-type":"dataUrl","after-read":_vm.identityCardFun('listImg5',1358),"accept":"image/gif, image/jpeg","multiple":""}},[(_vm.listImg5 == '')?_c('van-icon',{staticClass:"vanIcon",attrs:{"name":"add"}}):_c('img',{attrs:{"width":"100%","src":_vm.listImg5,"alt":""}})],1),_vm._v(" "),(!_vm.listImg5 == '')?_c('van-icon',{staticClass:"deleteiconHead",attrs:{"name":"close"},on:{"click":function($event){_vm.closeIdentityCard('listImg5',1358)}}}):_vm._e(),_vm._v(" "),(!_vm.listImg5 == '')?_c('van-icon',{staticClass:"lookiconHead",attrs:{"name":"password-view"},on:{"click":function($event){_vm.lookIdentityCard('listImg5')}}}):_vm._e()],1)],1),_vm._v(" "),_c('van-row',{staticClass:"heandClass"},[_c('van-col',[_vm._v("房产证明（房产证/按揭合同/购房合同）")])],1),_vm._v(" "),_c('van-row',{staticClass:"imgList imglistTwo"},[_c('van-col',{attrs:{"span":"11"}},[_c('van-uploader',{staticClass:"imgSize headPortrait",attrs:{"result-type":"dataUrl","after-read":_vm.identityCardFun('listImg6',1359),"accept":"image/gif, image/jpeg","multiple":""}},[(_vm.listImg6 == '')?_c('van-icon',{staticClass:"vanIcon",attrs:{"name":"add"}}):_c('img',{attrs:{"width":"100%","src":_vm.listImg6,"alt":""}})],1),_vm._v(" "),(!_vm.listImg6 == '')?_c('van-icon',{staticClass:"deleteiconHead",attrs:{"name":"close"},on:{"click":function($event){_vm.closeIdentityCard('listImg6',1359)}}}):_vm._e(),_vm._v(" "),(!_vm.listImg6 == '')?_c('van-icon',{staticClass:"lookiconHead",attrs:{"name":"password-view"},on:{"click":function($event){_vm.lookIdentityCard('listImg6')}}}):_vm._e()],1)],1),_vm._v(" "),_c('van-row',{staticClass:"heandClass"},[_c('van-col',[_vm._v("居住证明（本人/直系亲属姓名的水电费.物业费等单据）")])],1),_vm._v(" "),_c('van-row',{staticClass:"imgList imglistTwo"},[_c('van-col',{attrs:{"span":"11"}},[_c('van-uploader',{staticClass:"imgSize headPortrait",attrs:{"result-type":"dataUrl","after-read":_vm.identityCardFun('listImg7',1360),"accept":"image/gif, image/jpeg","multiple":""}},[(_vm.listImg7 == '')?_c('van-icon',{staticClass:"vanIcon",attrs:{"name":"add"}}):_c('img',{attrs:{"width":"100%","src":_vm.listImg7,"alt":""}})],1),_vm._v(" "),(!_vm.listImg7 == '')?_c('van-icon',{staticClass:"deleteiconHead",attrs:{"name":"close"},on:{"click":function($event){_vm.closeIdentityCard('listImg7',1360)}}}):_vm._e(),_vm._v(" "),(!_vm.listImg7 == '')?_c('van-icon',{staticClass:"lookiconHead",attrs:{"name":"password-view"},on:{"click":function($event){_vm.lookIdentityCard('listImg7')}}}):_vm._e()],1)],1),_vm._v(" "),_c('van-row',{staticClass:"heandClass"},[_c('van-col',[_vm._v("其他照片资料")])],1),_vm._v(" "),_c('van-row',{staticClass:"imgList imglistTwo"},[_c('van-col',{attrs:{"span":"11"}},[_c('van-uploader',{staticClass:"imgSize headPortrait",attrs:{"result-type":"dataUrl","after-read":_vm.identityCardFun('listImg8',1361),"accept":"image/gif, image/jpeg","multiple":""}},[(_vm.listImg8 == '')?_c('van-icon',{staticClass:"vanIcon",attrs:{"name":"add"}}):_c('img',{attrs:{"width":"100%","src":_vm.listImg8,"alt":""}})],1),_vm._v(" "),(!_vm.listImg8 == '')?_c('van-icon',{staticClass:"deleteiconHead",attrs:{"name":"close"},on:{"click":function($event){_vm.closeIdentityCard('listImg8',1361)}}}):_vm._e(),_vm._v(" "),(!_vm.listImg8 == '')?_c('van-icon',{staticClass:"lookiconHead",attrs:{"name":"password-view"},on:{"click":function($event){_vm.lookIdentityCard('listImg8')}}}):_vm._e()],1)],1)],1)],1),_vm._v(" "),_c('van-button',{attrs:{"type":"primary","bottom-action":""}},[_vm._v("确认")]),_vm._v(" "),_c('transition',{attrs:{"name":"fade"}},[_c('van-picker',{directives:[{name:"show",rawName:"v-show",value:(_vm.pickerDialog),expression:"pickerDialog"}],ref:"vanpicker",attrs:{"columns":_vm.columns,"show-toolbar":""},on:{"confirm":function($event){_vm.pickerDialog=false},"cancel":function($event){_vm.pickerDialog=false}}})],1),_vm._v(" "),_c('van-button',{attrs:{"type":"primary","bottom-action":""},on:{"click":_vm.IntoASubmit}},[_vm._v("确认并提交")])],1)}
var staticRenderFns = []

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/component-normalizer.js
var component_normalizer = __webpack_require__("XyMi");

// CONCATENATED MODULE: ./src/pages/add-information.vue
function injectStyle (context) {
  __webpack_require__("nmQF")
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(component_normalizer["a" /* default */])(
  add_information,
  render,
  staticRenderFns,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var pages_add_information = __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "rxp8":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".page.uploadIdPhotoFirst .van-cell--required:before{left:-.3rem;bottom:.3rem;font-size:36px;color:#ffe44d}.page.uploadIdPhotoFirst .van-cell{margin:0 auto 0 3%;border-bottom:1px solid #e8e8e8;width:97%}.page.uploadIdPhotoFirst .van-button--bottom-action.van-button--primary{background-color:#ffe44d;position:fixed;bottom:0}.page.uploadIdPhotoFirst .imgSize.headPortrait.van-uploader{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}", ""]);

// exports


/***/ }),

/***/ "s2K6":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/vue/dist/vue.esm.js
var vue_esm = __webpack_require__("7+uW");

// EXTERNAL MODULE: ./node_modules/vue-class-component/dist/vue-class-component.common.js
var vue_class_component_common = __webpack_require__("c+8m");
var vue_class_component_common_default = /*#__PURE__*/__webpack_require__.n(vue_class_component_common);

// EXTERNAL MODULE: ./src/utils/net.service.ts + 7 modules
var net_service = __webpack_require__("1pVc");

// EXTERNAL MODULE: ./node_modules/vant/es/index.js + 107 modules
var es = __webpack_require__("Fd2+");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("ipus");

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/pages/upload-id-photo-two.vue
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var upload_id_photo_two_Login = /** @class */ (function (_super) {
    __extends(Login, _super);
    function Login() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.arrImgTwo = [];
        _this.arrAll = [];
        _this.idName = null;
        _this.idNumber = null;
        _this.value = null;
        _this.photo = "";
        _this.photoTwo = '';
        _this.pickerDialog = false;
        _this.columns = [];
        _this.drivingType = '';
        _this.peopleCar = {
            useful_time: '',
            file_number: '',
            driving_license: '',
            driverPhoto: '',
            driverVicePhoto: '',
        };
        _this.optionCity = false; // 城市选择弹窗
        _this.columnsTwo = [
            {
                text: '郑州',
                val: '902'
            }, {
                text: '南宁',
                val: '3125'
            }
        ];
        // 验证规则
        _this.rules = {
            useful_time: { required: true, message: '请输入有效期限' },
            file_number: { required: true, message: '请输入档案编号' },
            driving_license: { required: true, message: '请选择准驾车型' },
        };
        return _this;
    }
    /***
    * 选择下单城市确定事件
    */
    Login.prototype.onConfirmTwo = function (val) {
        this.selectCity([Number(val.val)]);
        //  console.log(this.IntoACity)
        this.optionCity = false;
    };
    /**
    * 点击准驾车型确定事件
    */
    Login.prototype.onConfirm = function (val) {
        this.peopleCar.driving_license = val.value;
        this.drivingType = this.$dict.getDictName(Number(this.peopleCar.driving_license));
        this.pickerDialog = false;
    };
    /**
     * 点击下一步
     */
    Login.prototype.nextStep = function () {
        var _this = this;
        this.$validator.validate(this.peopleCar, this.rules).then(function (error) {
            if (!error) {
                for (var i in _this.arrAll) {
                    if (_this.arrAll[i].typeName == 1371) {
                        _this.peopleCar.driverPhoto = _this.arrAll[i].materialUrl;
                    }
                    else if (_this.arrAll[i].typeName == 1372) {
                        _this.peopleCar.driverVicePhoto = _this.arrAll[i].materialUrl;
                    }
                }
                if (_this.peopleCar.driverPhoto == '') {
                    _this.$toast('请先上传驾驶证正面');
                    return;
                }
                if (_this.peopleCar.driverVicePhoto == '') {
                    _this.$toast('请先上传驾驶证负面');
                    return;
                }
                _this.$router.push('/upload-id-photo-three');
                _this.choosePeople(_this.peopleCar);
            }
            else {
                _this.$toast(error);
            }
        });
    };
    //图片上传
    Login.prototype.onRead = function (val, number) {
        var _this = this;
        return function (_a) {
            var file = _a.file;
            net_service["NetService"].upload(file).then(function (x) {
                console.log(x);
                _this[val] = x.localUrl;
                for (var i in _this.arrAll) {
                    if (_this.arrAll[i].typeName == number) {
                        _this.arrAll.splice(i, 1);
                    }
                }
                _this.arrAll.push({
                    uploadName: x.realName,
                    materialType: x.type,
                    dataSize: x.size,
                    materialUrl: x.url,
                    uploadTime: x.createTime,
                    typeName: number,
                });
            });
        };
    };
    /**
      * 图片删除
      */
    Login.prototype.closeIdentityCard = function (val, number) {
        this[val] = '';
        for (var i in this.arrAll) {
            if (this.arrAll[i].typeName == number) {
                this.arrAll.splice(i, 1);
            }
        }
    };
    /**
   * 图片预览
   */
    Login.prototype.lookIdentityCard = function (val) {
        Object(es["a" /* ImagePreview */])([this[val]]);
    };
    Login.prototype.mounted = function () {
        this.arrAll = this.intoA.PersonalAdditional;
        this.columns = this.$dict.getDictData('0478').map(function (v) {
            return Object.assign({ text: v.label }, v);
        });
        console.log(this.IntoACity);
    };
    __decorate([
        lib["c" /* Mutation */]
    ], Login.prototype, "choosePeople", void 0);
    __decorate([
        lib["c" /* Mutation */]
    ], Login.prototype, "tenantImg", void 0);
    __decorate([
        lib["d" /* State */]
    ], Login.prototype, "intoA", void 0);
    __decorate([
        lib["c" /* Mutation */]
    ], Login.prototype, "selectCity", void 0);
    __decorate([
        lib["d" /* State */]
    ], Login.prototype, "IntoACity", void 0);
    Login = __decorate([
        vue_class_component_common_default()({})
    ], Login);
    return Login;
}(vue_esm["default"]));
/* harmony default export */ var upload_id_photo_two = (upload_id_photo_two_Login);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-21ab6ac2","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/pages/upload-id-photo-two.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"page uploadIdPhotoTwo"},[_c('van-cell',{attrs:{"title":"选择城市","required":"","is-link":"","value":_vm._f("cityConvert")(_vm.IntoACity)},on:{"click":function($event){_vm.optionCity=true}}}),_vm._v(" "),_c('van-row',[_c('van-steps',{attrs:{"active":1,"active-color":"#FFE44D"}},[_c('van-step',[_vm._v("身份证信息")]),_vm._v(" "),_c('van-step',[_vm._v("驾驶证信息")]),_vm._v(" "),_c('van-step',[_vm._v("银行卡信息")])],1)],1),_vm._v(" "),_c('p',{staticClass:"base-info-title"},[_vm._v("请扫描上传承租人驾驶证照片")]),_vm._v(" "),_c('van-row',[_c('van-row',{staticClass:"imgList"},[_c('van-col',{attrs:{"span":"11"}},[_c('van-uploader',{staticClass:"imgSize headPortrait",attrs:{"result-type":"dataUrl","after-read":_vm.onRead('photo',1371),"accept":"image/gif, image/jpeg","multiple":""}},[(_vm.photo == '')?_c('van-icon',{staticClass:"vanIcon",attrs:{"name":"add"}}):_c('img',{attrs:{"width":"100%","src":_vm.photo,"alt":""}})],1),_vm._v(" "),(!_vm.photo == '')?_c('van-icon',{staticClass:"deleteiconHead",attrs:{"name":"close"},on:{"click":function($event){_vm.closeIdentityCard('photo',1371)}}}):_vm._e(),_vm._v(" "),(!_vm.photo == '')?_c('van-icon',{staticClass:"lookiconHead",attrs:{"name":"password-view"},on:{"click":function($event){_vm.lookIdentityCard('photo')}}}):_vm._e()],1),_vm._v(" "),_c('van-col',{attrs:{"span":"11"}},[_c('van-uploader',{staticClass:"imgSize headPortrait",attrs:{"result-type":"dataUrl","after-read":_vm.onRead('photoTwo',1372),"accept":"image/gif, image/jpeg","multiple":""}},[(_vm.photoTwo == '')?_c('van-icon',{staticClass:"vanIcon",attrs:{"name":"add"}}):_c('img',{attrs:{"width":"100%","src":_vm.photoTwo,"alt":""}})],1),_vm._v(" "),(!_vm.photoTwo == '')?_c('van-icon',{staticClass:"deleteiconHead",attrs:{"name":"close"},on:{"click":function($event){_vm.closeIdentityCard('photoTwo',1372)}}}):_vm._e(),_vm._v(" "),(!_vm.photoTwo == '')?_c('van-icon',{staticClass:"lookiconHead",attrs:{"name":"password-view"},on:{"click":function($event){_vm.lookIdentityCard('photoTwo')}}}):_vm._e()],1)],1),_vm._v(" "),_c('van-row',{staticStyle:{"text-align":"center"}},[_c('van-col',{staticStyle:{"font-size":"14px"},attrs:{"span":"12"}},[_vm._v("驾驶证正页")]),_vm._v(" "),_c('van-col',{staticStyle:{"font-size":"14px"},attrs:{"span":"12"}},[_vm._v("驾驶证副页")])],1)],1),_vm._v(" "),_c('van-row',[_c('p',{staticClass:"base-info-title"},[_vm._v("请确认驾驶证信息是否一致")]),_vm._v(" "),_c('van-cell-group',[_c('van-field',{attrs:{"placeholder":"请输入有效期限","label":"有效期限","required":""},model:{value:(_vm.peopleCar.useful_time),callback:function ($$v) {_vm.$set(_vm.peopleCar, "useful_time", $$v)},expression:"peopleCar.useful_time"}}),_vm._v(" "),_c('van-field',{attrs:{"placeholder":"请输入档案编号","label":"档案编号","required":""},model:{value:(_vm.peopleCar.file_number),callback:function ($$v) {_vm.$set(_vm.peopleCar, "file_number", $$v)},expression:"peopleCar.file_number"}}),_vm._v(" "),_c('van-field',{attrs:{"required":"","label":"准驾车型","placeholder":"请选择准驾车型"},on:{"click":function($event){_vm.pickerDialog=true}},model:{value:(_vm.drivingType),callback:function ($$v) {_vm.drivingType=$$v},expression:"drivingType"}})],1)],1),_vm._v(" "),_c('transition',{attrs:{"name":"fade"}},[_c('van-picker',{directives:[{name:"show",rawName:"v-show",value:(_vm.optionCity),expression:"optionCity"}],attrs:{"columns":_vm.columnsTwo,"show-toolbar":""},on:{"confirm":_vm.onConfirmTwo,"cancel":function($event){_vm.optionCity=false}}})],1),_vm._v(" "),_c('transition',{attrs:{"name":"fade"}},[_c('van-picker',{directives:[{name:"show",rawName:"v-show",value:(_vm.pickerDialog),expression:"pickerDialog"}],ref:"vanpicker",attrs:{"columns":_vm.columns,"show-toolbar":""},on:{"confirm":_vm.onConfirm,"cancel":function($event){_vm.pickerDialog=false}}})],1),_vm._v(" "),_c('van-button',{attrs:{"type":"primary","bottom-action":""},on:{"click":_vm.nextStep}},[_vm._v("下一步")])],1)}
var staticRenderFns = []

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/component-normalizer.js
var component_normalizer = __webpack_require__("XyMi");

// CONCATENATED MODULE: ./src/pages/upload-id-photo-two.vue
function injectStyle (context) {
  __webpack_require__("oFoz")
  __webpack_require__("iCaX")
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-21ab6ac2"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(component_normalizer["a" /* default */])(
  upload_id_photo_two,
  render,
  staticRenderFns,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var pages_upload_id_photo_two = __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "sUJW":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("dVU4");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("1438e542", content, true, {});

/***/ }),

/***/ "stHo":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("n1AL");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("49b2f0fb", content, true, {});

/***/ }),

/***/ "t/hv":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SortService", function() { return SortService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_object_entries__ = __webpack_require__("W3Iv");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_object_entries___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_object_entries__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof__ = __webpack_require__("pFYg");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof__);


var sortType = {
    "ascending": "asc",
    "descending": "decs"
};
var SortService = /** @class */function () {
    function SortService() {
        this.sort = {};
    }
    /**
     * 转换排序对象为字符串
     */
    SortService.stringify = function (value) {
        if ((typeof value === "undefined" ? "undefined" : __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof___default()(value)) !== "object") {
            return "";
        }
        if (value instanceof SortService) {
            value = value.sort;
        }
        return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_object_entries___default()(value).map(function (_a) {
            var k = _a[0],
                v = _a[1];
            return "sort=" + k + "," + v;
        }).join('&');
    };
    /**
     * 更新分页配置信息
     * @param param
     */
    SortService.prototype.update = function (key, value) {
        if (key == null || value == null) {
            return this.reset();
        }
        this.sort = (_a = {}, _a[key] = sortType[value] || value, _a);
        var _a;
    };
    /**
     * 重置分页数据
     */
    SortService.prototype.reset = function () {
        this.sort = {};
    };
    return SortService;
}();


/***/ }),

/***/ "tBWe":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".page.addInformation .imglistTwo{margin-left:15px}.page.addInformation .van-cell__title{max-width:100%}.page.addInformation .heandClass{display:-webkit-box;display:-ms-flexbox;display:flex;margin:10px 0 0;background-color:#e6e6e6;padding:5px;font-size:14px}.page.addInformation .lookicon{color:#6495ed;font-size:20px;position:absolute;top:10px;left:5px}.page.addInformation .lookiconHead{position:relative;top:-105px;left:-65px;color:#6495ed;font-size:25px}.page.addInformation .deleteiconHead{position:relative;top:-105px;left:65px;color:#6495ed;font-size:20px}.page.addInformation .imgList{text-align:center}.page.addInformation .imgList .imgSize{height:110px;border:1px solid #6666;width:100%;margin-top:10px;background:#e7e7e7}.page.addInformation .idPhoto.line,.page.addInformation .imgList .imgSize{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center}.page.addInformation .vanIcon{font-size:40px;color:#bebebe}.page.addInformation .deleteicon{color:#6495ed;font-size:20px;position:absolute;top:10px;right:5px}.page.addInformation .fade-enter-active,.page.addInformation .fade-leave-active{-webkit-transition:bottom .5s;transition:bottom .5s}.page.addInformation .fade-enter,.page.addInformation .fade-leave-to{bottom:-388px}.page.addInformation .van-cell--required:before{left:-.3rem;bottom:.3rem;font-size:36px;color:#ffe44d}.page.addInformation p{margin:0}.page.addInformation .idPhoto{margin:12px;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;color:#bebebe}.page.addInformation .star{color:#ffe44d;font-size:2rem;vertical-align:middle;margin-right:.2rem}.page.addInformation .iconfont{margin-left:18px}.page.addInformation .van-picker{position:fixed;width:100%;bottom:0;z-index:100}.page.addInformation .base-info-title{color:gray;padding:12px;font-size:.8rem;border-bottom:1px solid #e8e8e8}.page.addInformation .van-cell{margin:0 auto 0 3%;border-bottom:1px solid #e8e8e8;width:97%}.page.addInformation .van-button--bottom-action.van-button--primary{background-color:#ffe44d;position:fixed;bottom:0}.page.addInformation .idPhoto{height:110px;border:.1rem solid #e7e7e7;margin:3px;position:relative;background:#e7e7e7;background-repeat:no-repeat;background-size:contain}.page.addInformation .iconfont{font-size:1.5rem;margin-top:-.6rem;display:inline-block;color:#c9c9c9;margin-top:-3px;border:1px solid #e7e7e7;background:#fff;width:25px;height:18px;line-height:18px;margin-left:2px;-webkit-box-sizing:border-box;box-sizing:border-box}.page.addInformation .line{border:1px dashed #bababa}.page.addInformation .add{font-size:50px;background:transparent;margin-left:8px}.page.addInformation .van-collapse-item__content{padding:0;margin-bottom:60px}", ""]);

// exports


/***/ }),

/***/ "tRa9":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/***/ }),

/***/ "trH+":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/***/ }),

/***/ "uZqz":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".page.details .carImgBox{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}", ""]);

// exports


/***/ }),

/***/ "unnt":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".page.know-onion-car .backgroundColor[data-v-1a7de013]{background-color:#fafafa}", ""]);

// exports


/***/ }),

/***/ "uslO":
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "3CJN",
	"./af.js": "3CJN",
	"./ar": "3MVc",
	"./ar-dz": "tkWw",
	"./ar-dz.js": "tkWw",
	"./ar-kw": "j8cJ",
	"./ar-kw.js": "j8cJ",
	"./ar-ly": "wPpW",
	"./ar-ly.js": "wPpW",
	"./ar-ma": "dURR",
	"./ar-ma.js": "dURR",
	"./ar-sa": "7OnE",
	"./ar-sa.js": "7OnE",
	"./ar-tn": "BEem",
	"./ar-tn.js": "BEem",
	"./ar.js": "3MVc",
	"./az": "eHwN",
	"./az.js": "eHwN",
	"./be": "3hfc",
	"./be.js": "3hfc",
	"./bg": "lOED",
	"./bg.js": "lOED",
	"./bm": "hng5",
	"./bm.js": "hng5",
	"./bn": "aM0x",
	"./bn.js": "aM0x",
	"./bo": "w2Hs",
	"./bo.js": "w2Hs",
	"./br": "OSsP",
	"./br.js": "OSsP",
	"./bs": "aqvp",
	"./bs.js": "aqvp",
	"./ca": "wIgY",
	"./ca.js": "wIgY",
	"./cs": "ssxj",
	"./cs.js": "ssxj",
	"./cv": "N3vo",
	"./cv.js": "N3vo",
	"./cy": "ZFGz",
	"./cy.js": "ZFGz",
	"./da": "YBA/",
	"./da.js": "YBA/",
	"./de": "DOkx",
	"./de-at": "8v14",
	"./de-at.js": "8v14",
	"./de-ch": "Frex",
	"./de-ch.js": "Frex",
	"./de.js": "DOkx",
	"./dv": "rIuo",
	"./dv.js": "rIuo",
	"./el": "CFqe",
	"./el.js": "CFqe",
	"./en-au": "Sjoy",
	"./en-au.js": "Sjoy",
	"./en-ca": "Tqun",
	"./en-ca.js": "Tqun",
	"./en-gb": "hPuz",
	"./en-gb.js": "hPuz",
	"./en-ie": "ALEw",
	"./en-ie.js": "ALEw",
	"./en-il": "QZk1",
	"./en-il.js": "QZk1",
	"./en-nz": "dyB6",
	"./en-nz.js": "dyB6",
	"./eo": "Nd3h",
	"./eo.js": "Nd3h",
	"./es": "LT9G",
	"./es-do": "7MHZ",
	"./es-do.js": "7MHZ",
	"./es-us": "INcR",
	"./es-us.js": "INcR",
	"./es.js": "LT9G",
	"./et": "XlWM",
	"./et.js": "XlWM",
	"./eu": "sqLM",
	"./eu.js": "sqLM",
	"./fa": "2pmY",
	"./fa.js": "2pmY",
	"./fi": "nS2h",
	"./fi.js": "nS2h",
	"./fo": "OVPi",
	"./fo.js": "OVPi",
	"./fr": "tzHd",
	"./fr-ca": "bXQP",
	"./fr-ca.js": "bXQP",
	"./fr-ch": "VK9h",
	"./fr-ch.js": "VK9h",
	"./fr.js": "tzHd",
	"./fy": "g7KF",
	"./fy.js": "g7KF",
	"./gd": "nLOz",
	"./gd.js": "nLOz",
	"./gl": "FuaP",
	"./gl.js": "FuaP",
	"./gom-latn": "+27R",
	"./gom-latn.js": "+27R",
	"./gu": "rtsW",
	"./gu.js": "rtsW",
	"./he": "Nzt2",
	"./he.js": "Nzt2",
	"./hi": "ETHv",
	"./hi.js": "ETHv",
	"./hr": "V4qH",
	"./hr.js": "V4qH",
	"./hu": "xne+",
	"./hu.js": "xne+",
	"./hy-am": "GrS7",
	"./hy-am.js": "GrS7",
	"./id": "yRTJ",
	"./id.js": "yRTJ",
	"./is": "upln",
	"./is.js": "upln",
	"./it": "FKXc",
	"./it.js": "FKXc",
	"./ja": "ORgI",
	"./ja.js": "ORgI",
	"./jv": "JwiF",
	"./jv.js": "JwiF",
	"./ka": "RnJI",
	"./ka.js": "RnJI",
	"./kk": "j+vx",
	"./kk.js": "j+vx",
	"./km": "5j66",
	"./km.js": "5j66",
	"./kn": "gEQe",
	"./kn.js": "gEQe",
	"./ko": "eBB/",
	"./ko.js": "eBB/",
	"./ky": "6cf8",
	"./ky.js": "6cf8",
	"./lb": "z3hR",
	"./lb.js": "z3hR",
	"./lo": "nE8X",
	"./lo.js": "nE8X",
	"./lt": "/6P1",
	"./lt.js": "/6P1",
	"./lv": "jxEH",
	"./lv.js": "jxEH",
	"./me": "svD2",
	"./me.js": "svD2",
	"./mi": "gEU3",
	"./mi.js": "gEU3",
	"./mk": "Ab7C",
	"./mk.js": "Ab7C",
	"./ml": "oo1B",
	"./ml.js": "oo1B",
	"./mn": "CqHt",
	"./mn.js": "CqHt",
	"./mr": "5vPg",
	"./mr.js": "5vPg",
	"./ms": "ooba",
	"./ms-my": "G++c",
	"./ms-my.js": "G++c",
	"./ms.js": "ooba",
	"./mt": "oCzW",
	"./mt.js": "oCzW",
	"./my": "F+2e",
	"./my.js": "F+2e",
	"./nb": "FlzV",
	"./nb.js": "FlzV",
	"./ne": "/mhn",
	"./ne.js": "/mhn",
	"./nl": "3K28",
	"./nl-be": "Bp2f",
	"./nl-be.js": "Bp2f",
	"./nl.js": "3K28",
	"./nn": "C7av",
	"./nn.js": "C7av",
	"./pa-in": "pfs9",
	"./pa-in.js": "pfs9",
	"./pl": "7LV+",
	"./pl.js": "7LV+",
	"./pt": "ZoSI",
	"./pt-br": "AoDM",
	"./pt-br.js": "AoDM",
	"./pt.js": "ZoSI",
	"./ro": "wT5f",
	"./ro.js": "wT5f",
	"./ru": "ulq9",
	"./ru.js": "ulq9",
	"./sd": "fW1y",
	"./sd.js": "fW1y",
	"./se": "5Omq",
	"./se.js": "5Omq",
	"./si": "Lgqo",
	"./si.js": "Lgqo",
	"./sk": "OUMt",
	"./sk.js": "OUMt",
	"./sl": "2s1U",
	"./sl.js": "2s1U",
	"./sq": "V0td",
	"./sq.js": "V0td",
	"./sr": "f4W3",
	"./sr-cyrl": "c1x4",
	"./sr-cyrl.js": "c1x4",
	"./sr.js": "f4W3",
	"./ss": "7Q8x",
	"./ss.js": "7Q8x",
	"./sv": "Fpqq",
	"./sv.js": "Fpqq",
	"./sw": "DSXN",
	"./sw.js": "DSXN",
	"./ta": "+7/x",
	"./ta.js": "+7/x",
	"./te": "Nlnz",
	"./te.js": "Nlnz",
	"./tet": "gUgh",
	"./tet.js": "gUgh",
	"./tg": "5SNd",
	"./tg.js": "5SNd",
	"./th": "XzD+",
	"./th.js": "XzD+",
	"./tl-ph": "3LKG",
	"./tl-ph.js": "3LKG",
	"./tlh": "m7yE",
	"./tlh.js": "m7yE",
	"./tr": "k+5o",
	"./tr.js": "k+5o",
	"./tzl": "iNtv",
	"./tzl.js": "iNtv",
	"./tzm": "FRPF",
	"./tzm-latn": "krPU",
	"./tzm-latn.js": "krPU",
	"./tzm.js": "FRPF",
	"./ug-cn": "To0v",
	"./ug-cn.js": "To0v",
	"./uk": "ntHu",
	"./uk.js": "ntHu",
	"./ur": "uSe8",
	"./ur.js": "uSe8",
	"./uz": "XU1s",
	"./uz-latn": "/bsm",
	"./uz-latn.js": "/bsm",
	"./uz.js": "XU1s",
	"./vi": "0X8Q",
	"./vi.js": "0X8Q",
	"./x-pseudo": "e/KL",
	"./x-pseudo.js": "e/KL",
	"./yo": "YXlc",
	"./yo.js": "YXlc",
	"./zh-cn": "Vz2w",
	"./zh-cn.js": "Vz2w",
	"./zh-hk": "ZUyn",
	"./zh-hk.js": "ZUyn",
	"./zh-tw": "BbgG",
	"./zh-tw.js": "BbgG"
};
function webpackContext(req) {
	return __webpack_require__(webpackContextResolve(req));
};
function webpackContextResolve(req) {
	var id = map[req];
	if(!(id + 1)) // check for number or string
		throw new Error("Cannot find module '" + req + "'.");
	return id;
};
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "uslO";

/***/ }),

/***/ "vOxv":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("XYt4");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("0030842c", content, true, {});

/***/ }),

/***/ "vSrd":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".component.car-img-show .img-center[data-v-b045c3ac]{text-align:center}.component.car-img-show .mar10[data-v-b045c3ac]{margin-top:10px;margin-bottom:10px;font-size:14px;font-weight:600}", ""]);

// exports


/***/ }),

/***/ "vpJI":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductOrderService", function() { return ProductOrderService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_object_define_property__ = __webpack_require__("C4MV");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_object_define_property___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_object_define_property__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof__ = __webpack_require__("pFYg");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_get_own_property_descriptor__ = __webpack_require__("K6ED");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_get_own_property_descriptor___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_get_own_property_descriptor__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__utils_net_service__ = __webpack_require__("1pVc");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__core_decorator__ = __webpack_require__("f3r7");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__config_server_manage_service__ = __webpack_require__("afVn");



var __decorate = this && this.__decorate || function (decorators, target, key, desc) {
    var c = arguments.length,
        r = c < 3 ? target : desc === null ? desc = __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_get_own_property_descriptor___default()(target, key) : desc,
        d;
    if ((typeof Reflect === "undefined" ? "undefined" : __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof___default()(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
        if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    }return c > 3 && r && __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_object_define_property___default()(target, key, r), r;
};



var ProductOrderService = /** @class */function () {
    function ProductOrderService() {}
    ProductOrderService.prototype.createOrder = function (data) {
        return this.netService.send({
            server: __WEBPACK_IMPORTED_MODULE_5__config_server_manage_service__["a" /* manageService */].productOrderController.createOrder,
            data: data
        });
    };
    /**
     * 根据用户手机号 获取用户订单
     * @param personalId
     */
    ProductOrderService.prototype.getOrder = function (mobileMain) {
        return this.netService.send({
            server: __WEBPACK_IMPORTED_MODULE_5__config_server_manage_service__["a" /* manageService */].productOrderController.getOrder,
            data: {
                mobileMain: mobileMain
            }
        });
    };
    /**
     * 根据用户订单号查询订单基本信息
     */
    ProductOrderService.prototype.findOrderInfoByOrderNumber = function (orderNumber) {
        return this.netService.send({
            server: __WEBPACK_IMPORTED_MODULE_5__config_server_manage_service__["a" /* manageService */].productOrderController.findOrderInfoByOrderNumber,
            data: {
                orderNumber: orderNumber
            }
        });
    };
    __decorate([Object(__WEBPACK_IMPORTED_MODULE_4__core_decorator__["c" /* Inject */])(__WEBPACK_IMPORTED_MODULE_3__utils_net_service__["NetService"])], ProductOrderService.prototype, "netService", void 0);
    return ProductOrderService;
}();


/***/ }),

/***/ "vqxC":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("trH+");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("624c5d4a", content, true, {});

/***/ }),

/***/ "wAJw":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/***/ }),

/***/ "x35b":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/symbol/iterator.js
var iterator = __webpack_require__("Zzip");
var iterator_default = /*#__PURE__*/__webpack_require__.n(iterator);

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/symbol.js
var symbol = __webpack_require__("5QVw");
var symbol_default = /*#__PURE__*/__webpack_require__.n(symbol);

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/promise.js
var promise = __webpack_require__("//Fk");
var promise_default = /*#__PURE__*/__webpack_require__.n(promise);

// EXTERNAL MODULE: ./node_modules/vue/dist/vue.esm.js
var vue_esm = __webpack_require__("7+uW");

// EXTERNAL MODULE: ./node_modules/vue-class-component/dist/vue-class-component.common.js
var vue_class_component_common = __webpack_require__("c+8m");
var vue_class_component_common_default = /*#__PURE__*/__webpack_require__.n(vue_class_component_common);

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/App.vue
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


var App_App = /** @class */ (function (_super) {
    __extends(App, _super);
    function App() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    App = __decorate([
        vue_class_component_common_default()({})
    ], App);
    return App;
}(vue_esm["default"]));
/* harmony default export */ var selectortype_script_index_0_src_App = (App_App);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-3f921b0b","hasScoped":false,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/App.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{attrs:{"id":"app"}},[_c('router-view')],1)}
var staticRenderFns = []

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/component-normalizer.js
var component_normalizer = __webpack_require__("XyMi");

// CONCATENATED MODULE: ./src/App.vue
function injectStyle (context) {
  __webpack_require__("+bZQ")
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(component_normalizer["a" /* default */])(
  selectortype_script_index_0_src_App,
  render,
  staticRenderFns,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var src_App = (Component.exports);

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/object/assign.js
var object_assign = __webpack_require__("woOf");
var assign_default = /*#__PURE__*/__webpack_require__.n(object_assign);

// EXTERNAL MODULE: ./node_modules/vuex/dist/vuex.esm.js
var vuex_esm = __webpack_require__("NYxO");

// CONCATENATED MODULE: ./src/store/state.ts
/* harmony default export */ var store_state = ({
    // 启动状态
    ready: false,
    // 布局名称
    layout: 'default',
    // 字典数据
    dictData: '',
    // 用户token
    userToken: '',
    // 用户订单信息
    orderInfo: '',
    // 用户数据
    userData: '',
    // token是否过期
    tokenExpire: false,
    // 页面列表
    pageList: [{
        path: 'home',
        resoname: '主页'
    }],
    // 当前打开的页面
    currentPage: '',
    // 默认主题
    theme: 'theme-default',
    // 主题列表
    themeList: [{
        name: 'theme-default',
        color: '#265EA2'
    }, {
        name: 'theme-theme1',
        color: '#18879B'
    }],
    companyList: [],
    intoA: {},
    IntoACity: '' // 进件城市 
});
// EXTERNAL MODULE: ./src/utils/storage.service.ts
var storage_service = __webpack_require__("3mjx");

// CONCATENATED MODULE: ./src/store/mutations.ts


/* harmony default export */ var mutations = ({
    /**
    * 更新用户资源信息
    * @param state
    * @param rescource
    */
    updateUserMenuResource: function updateUserMenuResource(state, rescource) {
        state.menuResource = rescource;
    },
    /**
    * 更新用户资源信息
    * @param state
    * @param rescource
    */
    updateUserControlResource: function updateUserControlResource(state, rescource) {
        state.controlResource = rescource;
    },
    /**
     * 更新布局
     * @param state
     * @param layout
     */
    updateLayout: function updateLayout(state, layout) {
        state.layout = layout || 'default';
    },
    /**
     * 更新数据字典
     * @param state/
     * @param data
     */
    updateDictData: function updateDictData(state, data) {
        state.dictData = data;
    },
    /**
     * 更新用户token
     * @param state
     * @param token
     */
    updateUserToken: function updateUserToken(state, token) {
        state.userToken = token;
        storage_service["a" /* StorageService */].setItem("userToken", token);
    },
    /**
     * 更新用户数据
     * @param state
     * @param user
     */
    updateUserData: function updateUserData(state, user) {
        state.userData = user;
    },
    /**
     * 打开页面
     * @param state
     * @param page
     */
    openPage: function openPage(state, target) {
        var page, path, params;
        if (typeof target === "string") {
            path = target;
        } else {
            path = target.path;
            params = target.params;
        }
        // 获取是否是显示中的页面
        page = state.pageList.find(function (x) {
            return x.path === path;
        });
        if (page) {
            // 当前页面已经打开
            page.params = params;
        } else {
            // 当前页面未打开
            page = state.menuResource.find(function (x) {
                return x.path === path;
            });
            // 添加新页面
            state.pageList.push(assign_default()({
                params: params
            }, page));
        }
        // 切换显示页面
        state.currentPage = page.path;
    },
    /**
     * 关闭页面
     * @param state
     * @param path
     */
    closePage: function closePage(state, path) {
        var page = state.pageList.find(function (x) {
            return x.path === path;
        });
        if (!page) {
            return;
        }
        var index = state.pageList.indexOf(page);
        state.currentPage = state.pageList[index - 1].path;
        if (index > 0) {
            state.pageList.splice(index, 1);
        }
    },
    /**
     * 关闭所有
     * @param state
     */
    closeAllPage: function closeAllPage(state) {
        state.pageList = [{
            path: 'home',
            resoname: '主页'
        }];
        state.currentPage = 'home';
    },
    /**
     * 更新主题
     * @param state
     * @param theme
     */
    updateTheme: function updateTheme(state, theme) {
        state.theme = theme;
    },
    /**
     * 修改token过期标识
     * @param state
     * @param data
     */
    updateTokenExpire: function updateTokenExpire(state, data) {
        state.tokenExpire = data;
    },
    /**
     * 更新初始化状态
     * @param state
     */
    ready: function ready(state) {
        state.ready = true;
    },
    updateCompanyList: function updateCompanyList(state, data) {
        state.companyList = data;
    },
    /**
     * 更新用户手机号码
     * @param state
     * @param phoneNumber 手机号码
     */
    updateUserPhone: function updateUserPhone(state, phoneNumber) {
        state.userPhone = phoneNumber;
    },
    //身份证信息页
    idcCard: function idcCard(state, data) {
        state.intoA.personal = data;
    },
    //驾驶者信息页
    choosePeople: function choosePeople(state, data) {
        state.intoA.personalCar = data;
    },
    //银行卡信息页
    bankCard: function bankCard(state, data) {
        state.intoA.personalBank = data;
    },
    //工作情况
    going: function going(state, data) {
        state.intoA.PersonalJob = data;
    },
    // 联系人
    linkman: function linkman(state, data) {
        state.intoA.PersonalContact = data;
    },
    // 所有照片
    tenantImg: function tenantImg(state, data) {
        state.intoA.PersonalAdditional = data;
    },
    //车辆详情
    carDetails: function carDetails(state, data) {
        state.intoA.orderCar = data;
    },
    carDetailTwo: function carDetailTwo(state, data) {
        state.intoA.orderCarTwo = data;
    },
    // 改变进件城市选择
    selectCity: function selectCity(state, data) {
        state.IntoACity = data;
    },
    // 清空进件城市
    clearSelectCity: function clearSelectCity(state) {
        state.IntoACity = '';
    },
    // 清空intoA
    clearIntoA: function clearIntoA(state) {
        state.intoA = {};
    },
    /**
     * 更新用户订单数据
     * @param state
     * @param data
     */
    updateUserOrder: function updateUserOrder(state, data) {
        state.orderInfo = data;
    }
});
// CONCATENATED MODULE: ./src/store/actions.ts



var __awaiter = this && this.__awaiter || function (thisArg, _arguments, P, generator) {
    return new (P || (P = promise_default.a))(function (resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : new P(function (resolve) {
                resolve(result.value);
            }).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = this && this.__generator || function (thisArg, body) {
    var _ = { label: 0, sent: function sent() {
            if (t[0] & 1) throw t[1];return t[1];
        }, trys: [], ops: [] },
        f,
        y,
        t,
        g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof symbol_default.a === "function" && (g[iterator_default.a] = function () {
        return this;
    }), g;
    function verb(n) {
        return function (v) {
            return step([n, v]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) {
            try {
                if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [0, t.value];
                switch (op[0]) {
                    case 0:case 1:
                        t = op;break;
                    case 4:
                        _.label++;return { value: op[1], done: false };
                    case 5:
                        _.label++;y = op[1];op = [0];continue;
                    case 7:
                        op = _.ops.pop();_.trys.pop();continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                            _ = 0;continue;
                        }
                        if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                            _.label = op[1];break;
                        }
                        if (op[0] === 6 && _.label < t[1]) {
                            _.label = t[1];t = op;break;
                        }
                        if (t && _.label < t[2]) {
                            _.label = t[2];_.ops.push(op);break;
                        }
                        if (t[2]) _.ops.pop();
                        _.trys.pop();continue;
                }
                op = body.call(thisArg, _);
            } catch (e) {
                op = [6, e];y = 0;
            } finally {
                f = t = 0;
            }
        }if (op[0] & 5) throw op[1];return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var productOrderService = function productOrderService() {
    return new Promise(function(resolve) { resolve(); }).then(__webpack_require__.bind(null, "vpJI"));
};
/* harmony default export */ var actions = ({
    /**
     * 更新用户登录数据
     */
    updateUserLoginData: function updateUserLoginData(_a, _b) {
        var state = _a.state,
            commit = _a.commit,
            dispatch = _a.dispatch;
        var token = _b.token,
            personalId = _b.personalId,
            personalName = _b.personalName,
            userPhone = _b.userPhone;
        // 更新用户token
        if (!!token) {
            commit('updateUserToken', token);
        }
        // 更新用户数据
        commit('updateUserData', {
            id: personalId,
            personalName: personalName || "",
            userPhone: userPhone
        });
        // 执行 getOrderInfo 方法 传 userPhone
        dispatch('getOrderInfo', userPhone);
        commit('updateTokenExpire', false);
    },
    /**
     * 清除登录数据
     */
    clearUserLoginData: function clearUserLoginData(_a) {
        var commit = _a.commit;
        // 重置用户token
        commit('updateUserToken', "");
        // 清空用户订单数据
        commit('updateUserOrder', '');
        // 重置token过期标识
        commit('updateTokenExpire', true);
        // 清空数据
        localStorage.removeItem('vuex');
        localStorage.removeItem('userToken');
    },
    /**
     * 获取用户订单
     * @param param0  commit 方法
     * @param userPhone  用户手机号
     */
    getOrderInfo: function getOrderInfo(_a, userPhone) {
        var commit = _a.commit;
        return __awaiter(this, void 0, void 0, function () {
            var ProductOrderService, productService;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        return [4 /*yield*/, productOrderService()];
                    case 1:
                        ProductOrderService = _b.sent().ProductOrderService;
                        productService = new ProductOrderService();
                        productService.getOrder(userPhone).subscribe(function (data) {
                            // 更新用户订单数据
                            commit('updateUserOrder', data);
                        }, function (err) {
                            return console.error('获取用户订单出错');
                        });
                        return [2 /*return*/];
                }
            });
        });
    }
});
// CONCATENATED MODULE: ./src/store/getters.ts
/* harmony default export */ var getters = ({
    /**
     * 计算当前是否含有订单
     * @param state
     */
    hasOrder: function hasOrder(state) {
        return state.orderInfo && state.orderInfo !== '';
    }
});
// EXTERNAL MODULE: ./node_modules/vuex-persistedstate/dist/vuex-persistedstate.es.js
var vuex_persistedstate_es = __webpack_require__("424j");

// CONCATENATED MODULE: ./src/store/index.ts








vue_esm["default"].use(vuex_esm["a" /* default */]);
var filterList = ['ready'];
var store_store = new vuex_esm["a" /* default */].Store({
    state: store_state,
    getters: getters,
    mutations: mutations,
    actions: actions,
    plugins: [
    // 持久化存储插件
    Object(vuex_persistedstate_es["a" /* default */])({
        key: "vuex",
        reducer: function reducer(state, paths) {
            return assign_default()({}, state, { ready: false });
        },
        storage: localStorage,
        filter: function filter(_a) {
            var type = _a.type,
                payload = _a.payload;
            return !filterList.includes(type);
        }
    })]
});
/* harmony default export */ var src_store = (store_store);
// EXTERNAL MODULE: ./node_modules/vue-router/dist/vue-router.esm.js
var vue_router_esm = __webpack_require__("/ocq");

// CONCATENATED MODULE: ./src/core/bootstrap/store.init.ts



var store_init___awaiter = this && this.__awaiter || function (thisArg, _arguments, P, generator) {
    return new (P || (P = promise_default.a))(function (resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : new P(function (resolve) {
                resolve(result.value);
            }).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var store_init___generator = this && this.__generator || function (thisArg, body) {
    var _ = { label: 0, sent: function sent() {
            if (t[0] & 1) throw t[1];return t[1];
        }, trys: [], ops: [] },
        f,
        y,
        t,
        g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof symbol_default.a === "function" && (g[iterator_default.a] = function () {
        return this;
    }), g;
    function verb(n) {
        return function (v) {
            return step([n, v]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) {
            try {
                if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [0, t.value];
                switch (op[0]) {
                    case 0:case 1:
                        t = op;break;
                    case 4:
                        _.label++;return { value: op[1], done: false };
                    case 5:
                        _.label++;y = op[1];op = [0];continue;
                    case 7:
                        op = _.ops.pop();_.trys.pop();continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                            _ = 0;continue;
                        }
                        if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                            _.label = op[1];break;
                        }
                        if (op[0] === 6 && _.label < t[1]) {
                            _.label = t[1];t = op;break;
                        }
                        if (t && _.label < t[2]) {
                            _.label = t[2];_.ops.push(op);break;
                        }
                        if (t[2]) _.ops.pop();
                        _.trys.pop();continue;
                }
                op = body.call(thisArg, _);
            } catch (e) {
                op = [6, e];y = 0;
            } finally {
                f = t = 0;
            }
        }if (op[0] & 5) throw op[1];return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var creatDataDictService = function creatDataDictService() {
    return __webpack_require__.e/* import() */(3).then(__webpack_require__.bind(null, "V7k7"));
};
/* harmony default export */ var store_init = (function (_a) {
    var store = _a.store,
        router = _a.router;
    return store_init___awaiter(this, void 0, void 0, function () {
        /**
         * 检测用户数据
         */
        function updateUserData() {
            return store_init___awaiter(this, void 0, void 0, function () {
                return store_init___generator(this, function (_a) {
                    return [2 /*return*/, new promise_default.a(function (reslove, reject) {
                        // 登录页面不更新用户数据
                        if (!store.state.userToken && window.location.pathname == "/") {
                            reslove();
                            return;
                        }
                        // 不存在token不更新用户数据
                        if (!store.state.userToken && window.location.pathname != "/") {
                            store.commit("updateTokenExpire", true);
                            reject();
                            return;
                        }
                    })];
                });
            });
        }
        /**
         * 检查数据字典
         * @param reslove
         */
        function updateDictData() {
            return new promise_default.a(function (reslove, reject) {
                dataDictService.getAll().subscribe(function (data) {
                    store.commit('updateDictData', data);
                    reslove();
                }, function () {
                    reject();
                });
            });
        }
        var DataDictService, dataDictService, flag;
        return store_init___generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    return [4 /*yield*/, creatDataDictService()];
                case 1:
                    DataDictService = _b.sent().DataDictService;
                    dataDictService = new DataDictService();
                    return [4 /*yield*/, promise_default.a.all([updateDictData()]).then(function () {
                        return true;
                    }).catch(function (ex) {
                        // 基础数据初始化失败
                        return false;
                    })];
                case 2:
                    flag = _b.sent();
                    store.commit('ready', true);
                    return [2 /*return*/];
            }
        });
    });
});
// EXTERNAL MODULE: ./src/core/decorator.ts
var decorator = __webpack_require__("f3r7");

// EXTERNAL MODULE: ./src/services/manage-service/car-show-management.service.ts
var car_show_management_service = __webpack_require__("2OOm");

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/home/trademark.vue
var trademark___extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var trademark___decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var trademark_Trademark = /** @class */ (function (_super) {
    trademark___extends(Trademark, _super);
    function Trademark() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.trademarks = [];
        return _this;
    }
    Object.defineProperty(Trademark.prototype, "trademarkList", {
        get: function () {
            var list = this.trademarks.slice(0, 9);
            list.push({
                logoUrl: "/static/images/home/trademarks/all.png",
                brandName: "全部品牌"
            });
            return list;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * 点击当前品牌 进入相对应的品牌车辆
     */
    Trademark.prototype.Allcar = function (index, id) {
        if (index < 9) {
            this.$router.push("/buy-car-list/?b=" + id);
        }
        else {
            this.$router.push("/buy-car-list");
        }
    };
    Trademark.prototype.fristVehicleBrand = function () {
        var _this = this;
        this.carShowManagementService.getTopTenCarBrandList().subscribe(function (data) {
            _this.trademarks = data;
        }, function (err) { return _this.$toast(err.msg); });
    };
    Trademark.prototype.mounted = function () {
        this.fristVehicleBrand();
    };
    trademark___decorate([
        Object(decorator["b" /* Dependencies */])(car_show_management_service["a" /* carShowManagementService */])
    ], Trademark.prototype, "carShowManagementService", void 0);
    Trademark = trademark___decorate([
        vue_class_component_common_default()({})
    ], Trademark);
    return Trademark;
}(vue_esm["default"]));
/* harmony default export */ var trademark = (trademark_Trademark);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-c9c367ae","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/home/trademark.vue
var trademark_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component trademark"},_vm._l((_vm.trademarkList),function(item,index){return _c('div',{key:index,staticClass:"logo"},[_c('div',{on:{"click":function($event){_vm.Allcar(index,item.id)}}},[_c('img',{attrs:{"height":"30px","src":item.logoUrl,"alt":""}}),_vm._v(" "),_c('div',{staticClass:"logoDetails"},[_vm._v(_vm._s(item.brandName))])])])}))}
var trademark_staticRenderFns = []

// CONCATENATED MODULE: ./src/components/home/trademark.vue
function trademark_injectStyle (context) {
  __webpack_require__("Iurx")
}
/* script */


/* template */

/* template functional */
var trademark___vue_template_functional__ = false
/* styles */
var trademark___vue_styles__ = trademark_injectStyle
/* scopeId */
var trademark___vue_scopeId__ = "data-v-c9c367ae"
/* moduleIdentifier (server only) */
var trademark___vue_module_identifier__ = null

var trademark_Component = Object(component_normalizer["a" /* default */])(
  trademark,
  trademark_render,
  trademark_staticRenderFns,
  trademark___vue_template_functional__,
  trademark___vue_styles__,
  trademark___vue_scopeId__,
  trademark___vue_module_identifier__
)

/* harmony default export */ var home_trademark = (trademark_Component.exports);

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/home/question.vue
var question___extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var question___decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


var question_Question = /** @class */ (function (_super) {
    question___extends(Question, _super);
    function Question() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // 当前激活的面板
        _this.activeNames = [];
        _this.dataSet = [
            {
                id: 1,
                title: "在洋葱汽车买车有哪些优势?",
                content: "透明费用，流程渐变，还包购置税送保险。商场直接提供车源品牌保障，现有直营店近百家，遍布全国，超低购车门槛，审核简单，急速通道，首付 + 首期月供 + 押金（结清后退还押金）即可提车。"
            },
            {
                id: 2,
                title: "洋葱汽车购车流程是怎么样的?",
                content: "首先在线预约，选好意向车型后预约，洋葱骑车直营店，客户经理将在24小时内为您提供1对1服务，然后签约购车，选择合适的购车方案，收履约保证金，通过风控征信审核后签订购车协议。第三步支付费用，支付首付，第一期月供，违章保证金。最后到店提车，客户经理将联系您到附近的直营店提车"
            },
            {
                id: 3,
                title: "需要准备哪些材料?",
                content: "二代身份证、驾驶证、征信报告。"
            },
            {
                id: 4,
                title: "其他疑问谁能解答?",
                content: "关注 '云南洋葱汽车科技有限公司' 微信公众号"
            },
        ];
        return _this;
    }
    Question = question___decorate([
        vue_class_component_common_default()({})
    ], Question);
    return Question;
}(vue_esm["default"]));
/* harmony default export */ var question = (question_Question);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-9f464e00","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/home/question.vue
var question_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component question"},[_c('van-collapse',{model:{value:(_vm.activeNames),callback:function ($$v) {_vm.activeNames=$$v},expression:"activeNames"}},_vm._l((_vm.dataSet),function(item){return _c('van-collapse-item',{key:item.id},[_c('div',{attrs:{"slot":"title"},slot:"title"},[_c('van-row',[_c('van-col',{attrs:{"span":3}},[_c('div',{staticClass:"question-title-icon"},[_vm._v("问")])]),_vm._v(" "),_c('van-col',{attrs:{"span":21}},[_c('div',{staticClass:"question-title-content"},[_vm._v(_vm._s(item.title))])])],1)],1),_vm._v(" "),_c('p',{staticClass:"question-content"},[_vm._v(_vm._s(item.content))])])}))],1)}
var question_staticRenderFns = []

// CONCATENATED MODULE: ./src/components/home/question.vue
function question_injectStyle (context) {
  __webpack_require__("ckpd")
}
/* script */


/* template */

/* template functional */
var question___vue_template_functional__ = false
/* styles */
var question___vue_styles__ = question_injectStyle
/* scopeId */
var question___vue_scopeId__ = "data-v-9f464e00"
/* moduleIdentifier (server only) */
var question___vue_module_identifier__ = null

var question_Component = Object(component_normalizer["a" /* default */])(
  question,
  question_render,
  question_staticRenderFns,
  question___vue_template_functional__,
  question___vue_styles__,
  question___vue_scopeId__,
  question___vue_module_identifier__
)

/* harmony default export */ var home_question = (question_Component.exports);

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/home/car-list.vue
var car_list___extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var car_list___decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var car_list_CarList = /** @class */ (function (_super) {
    car_list___extends(CarList, _super);
    function CarList() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.carIntro = [];
        _this.dataSet = [];
        return _this;
    }
    /**
     * 获取精品车辆
     */
    CarList.prototype.getBoutiqueCar = function () {
        var _this = this;
        this.carShowManagementService.getGoodCarShowModelList().subscribe(function (data) {
            _this.carIntro = data;
        }, function (err) { return _this.$toast(err.msg); });
    };
    /**
     * 点击车辆跳转
     */
    CarList.prototype.carInfoClick = function (id) {
        this.$router.push("/details/" + id);
    };
    CarList.prototype.mounted = function () {
        this.getBoutiqueCar();
    };
    car_list___decorate([
        Object(decorator["b" /* Dependencies */])(car_show_management_service["a" /* carShowManagementService */])
    ], CarList.prototype, "carShowManagementService", void 0);
    CarList = car_list___decorate([
        vue_class_component_common_default()({})
    ], CarList);
    return CarList;
}(vue_esm["default"]));
/* harmony default export */ var car_list = (car_list_CarList);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-b809b0d8","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/home/car-list.vue
var car_list_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component car-list"},[_c('van-row',_vm._l((_vm.carIntro),function(item,index){return _c('van-col',{key:index,staticClass:"car-list-item",attrs:{"span":"12"}},[_c('div',{staticClass:"car-list-img",on:{"click":function($event){_vm.carInfoClick(item.carId)}}},[_c('img',{attrs:{"src":item.carPictures.length > 0 ?item.carPictures[0].url:null,"alt":item.modelName,"height":"100%"}})]),_vm._v(" "),_c('div',{staticClass:"car"},[_c('p',{staticClass:"beyondLittle"},[_vm._v(_vm._s(item.brandSeriesName))]),_vm._v(" "),_c('p',{staticClass:"car-info"},[_vm._v(_vm._s(item.modelName))])]),_vm._v(" "),_c('van-row',[_c('van-col',{staticClass:"car-first",attrs:{"span":"12"}},[_vm._v("首付"+_vm._s(_vm._f("toThousands")(item.firstPayment/10000))+"万")]),_vm._v(" "),_c('van-col',{staticClass:"car-month",attrs:{"span":"12"}},[_vm._v("月供"+_vm._s(_vm._f("toThousands")(item.monthRent))+"元")])],1)],1)}))],1)}
var car_list_staticRenderFns = []

// CONCATENATED MODULE: ./src/components/home/car-list.vue
function car_list_injectStyle (context) {
  __webpack_require__("jukp")
}
/* script */


/* template */

/* template functional */
var car_list___vue_template_functional__ = false
/* styles */
var car_list___vue_styles__ = car_list_injectStyle
/* scopeId */
var car_list___vue_scopeId__ = "data-v-b809b0d8"
/* moduleIdentifier (server only) */
var car_list___vue_module_identifier__ = null

var car_list_Component = Object(component_normalizer["a" /* default */])(
  car_list,
  car_list_render,
  car_list_staticRenderFns,
  car_list___vue_template_functional__,
  car_list___vue_styles__,
  car_list___vue_scopeId__,
  car_list___vue_module_identifier__
)

/* harmony default export */ var home_car_list = (car_list_Component.exports);

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.umd.js
var vue_property_decorator_umd = __webpack_require__("EOM2");
var vue_property_decorator_umd_default = /*#__PURE__*/__webpack_require__.n(vue_property_decorator_umd);

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/common/nav-bar.vue
var nav_bar___extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var nav_bar___decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var nav_bar_NavBar = /** @class */ (function (_super) {
    nav_bar___extends(NavBar, _super);
    function NavBar() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    // 点击买新车
    NavBar.prototype.toBuyCarList = function () {
        this.$router.push({
            name: 'BuyCarList',
            params: {
                brandId: '-1'
            }
        });
        this.onNavItemClick();
    };
    Object.defineProperty(NavBar.prototype, "showNavBar", {
        /**
         * 因为popup 的 v-model 绑定的当前model/属性
         * 所以这里需要使用计算器获取
        */
        get: function () {
            return this.show;
        },
        /**
         * 这里使用属性计算器 设置
         * 提交一个事件来使父组件改变model/属性的值
         */
        set: function (val) {
            this.onNavItemClick(val);
        },
        enumerable: true,
        configurable: true
    });
    NavBar.prototype.onNavItemClick = function (val) {
        if (val === void 0) { val = !this.show; }
    };
    nav_bar___decorate([
        Object(vue_property_decorator_umd["Model"])('change')
    ], NavBar.prototype, "show", void 0);
    nav_bar___decorate([
        Object(vue_property_decorator_umd["Emit"])('change')
    ], NavBar.prototype, "onNavItemClick", null);
    NavBar = nav_bar___decorate([
        vue_class_component_common_default()({})
    ], NavBar);
    return NavBar;
}(vue_esm["default"]));
/* harmony default export */ var nav_bar = (nav_bar_NavBar);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-543b8621","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/common/nav-bar.vue
var nav_bar_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component nav-bar"},[_c('van-popup',{attrs:{"position":"right"},on:{"click-overlay":function($event){_vm.onNavItemClick(false)}},model:{value:(_vm.showNavBar ),callback:function ($$v) {_vm.showNavBar =$$v},expression:"showNavBar "}},[_c('van-cell-group',[_c('van-cell',{attrs:{"title":"首页","to":"/home","clickable":""},on:{"click":_vm.onNavItemClick}}),_vm._v(" "),_c('van-cell',{attrs:{"title":"买新车","clickable":""},on:{"click":_vm.toBuyCarList}})],1),_vm._v(" "),_c('div',{staticClass:"van-hairline--bottom"}),_vm._v(" "),_c('van-cell-group',[_c('van-cell',{attrs:{"title":"我的订单","to":"/my-order","clickable":""},on:{"click":_vm.onNavItemClick}}),_vm._v(" "),_c('van-cell',{attrs:{"title":"还款明细","to":"/payment-record","clickable":""},on:{"click":_vm.onNavItemClick}})],1),_vm._v(" "),_c('div',{staticClass:"van-hairline--bottom"}),_vm._v(" "),_c('van-cell-group',[_c('van-cell',{attrs:{"title":"常见问题","to":"/FAQ","clickable":""},on:{"click":_vm.onNavItemClick}}),_vm._v(" "),_c('van-cell',{attrs:{"title":"了解洋葱汽车","to":"/know-onion-car","clickable":""},on:{"click":_vm.onNavItemClick}}),_vm._v(" "),_c('van-cell',{attrs:{"title":"退出","to":"/","clickable":""},on:{"click":_vm.onNavItemClick}})],1)],1)],1)}
var nav_bar_staticRenderFns = []

// CONCATENATED MODULE: ./src/components/common/nav-bar.vue
function nav_bar_injectStyle (context) {
  __webpack_require__("ne3W")
  __webpack_require__("dmbO")
}
/* script */


/* template */

/* template functional */
var nav_bar___vue_template_functional__ = false
/* styles */
var nav_bar___vue_styles__ = nav_bar_injectStyle
/* scopeId */
var nav_bar___vue_scopeId__ = "data-v-543b8621"
/* moduleIdentifier (server only) */
var nav_bar___vue_module_identifier__ = null

var nav_bar_Component = Object(component_normalizer["a" /* default */])(
  nav_bar,
  nav_bar_render,
  nav_bar_staticRenderFns,
  nav_bar___vue_template_functional__,
  nav_bar___vue_styles__,
  nav_bar___vue_scopeId__,
  nav_bar___vue_module_identifier__
)

/* harmony default export */ var common_nav_bar = (nav_bar_Component.exports);

// EXTERNAL MODULE: ./src/components/common/city-picker.vue + 2 modules
var city_picker = __webpack_require__("T47b");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("ipus");

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/pages/home.vue
var home___extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var home___decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};








var home_Home = /** @class */ (function (_super) {
    home___extends(Home, _super);
    function Home() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.serachKeyWord = "";
        _this.images = [
            "/static/images/home/home_1.jpg",
            "/static/images/home/home_2.jpg"
        ];
        // 控制各个组件显示flag
        _this.show = {
            navBar: false,
            search: false
        };
        return _this;
    }
    Object.defineProperty(Home.prototype, "keyWord", {
        get: function () {
            return this.serachKeyWord;
        },
        set: function (val) {
            this.serachKeyWord = val;
            this.show.search = val !== "";
        },
        enumerable: true,
        configurable: true
    });
    /**
     * 搜索页面
     */
    Home.prototype.onSearch = function () {
        this.$router.push("/buy-car-list/?k=" + this.keyWord);
    };
    Home.prototype.mounted = function () {
        // console.log(this.intoA,'看这里')
    };
    home___decorate([
        lib["d" /* State */]
    ], Home.prototype, "intoA", void 0);
    Home = home___decorate([
        vue_class_component_common_default()({
            components: {
                Trademark: home_trademark,
                CarList: home_car_list,
                Question: home_question,
                NavBar: common_nav_bar,
                CityPicker: city_picker["a" /* default */]
            }
        })
    ], Home);
    return Home;
}(vue_esm["default"]));
/* harmony default export */ var home = (home_Home);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-69e16561","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/pages/home.vue
var home_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"page home"},[_c('section',[_c('form',{attrs:{"action":"/"}},[_c('van-search',{attrs:{"placeholder":"寻找您想要买的爱车","show-action":""},on:{"click-icon":function($event){_vm.keyWord = ''},"search":_vm.onSearch},model:{value:(_vm.keyWord),callback:function ($$v) {_vm.keyWord=$$v},expression:"keyWord"}},[_c('div',{attrs:{"slot":"action"},slot:"action"},[(!_vm.show.search)?_c('van-icon',{staticClass:"home-nav-bar",attrs:{"name":"wap-nav"},on:{"click":function($event){_vm.show.navBar = true}}}):_c('div',{staticClass:"home-nav-bar",on:{"click":_vm.onSearch}},[_vm._v("搜索")])],1)])],1),_vm._v(" "),_c('van-swipe',{attrs:{"autoplay":3000}},_vm._l((_vm.images),function(image,index){return _c('van-swipe-item',{key:index},[_c('img',{attrs:{"width":"100%","src":image}})])}))],1),_vm._v(" "),_c('trademark'),_vm._v(" "),_c('section',[_c('div',{staticClass:"break-line"}),_vm._v(" "),_vm._m(0),_vm._v(" "),_c('car-list')],1),_vm._v(" "),_c('section',[_c('div',{staticClass:"break-line"}),_vm._v(" "),_c('h3',[_vm._v("常见问题")]),_vm._v(" "),_c('question')],1),_vm._v(" "),_c('section',[_c('div',{staticClass:"break-line"}),_vm._v(" "),_c('div',{staticClass:"content"},[_c('img',{attrs:{"height":"35px","src":"/static/images/common/home_logo.png"}}),_vm._v(" "),_c('p',{staticClass:"describe"},[_vm._v("中业金服旗下洋葱汽车新品上线")]),_vm._v(" "),_c('van-button',{staticClass:"full-radius",attrs:{"type":"primary","size":"large"},on:{"click":function($event){_vm.$router.push('/subscribe')}}},[_vm._v("帮我买车")])],1)]),_vm._v(" "),_c('city-picker'),_vm._v(" "),_c('nav-bar',{model:{value:(_vm.show.navBar),callback:function ($$v) {_vm.$set(_vm.show, "navBar", $$v)},expression:"show.navBar"}})],1)}
var home_staticRenderFns = [function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',[_c('img',{staticClass:"siftCar",attrs:{"height":"30px","src":"/static/images/home/ad.png"}})])}]

// CONCATENATED MODULE: ./src/pages/home.vue
function home_injectStyle (context) {
  __webpack_require__("sUJW")
}
/* script */


/* template */

/* template functional */
var home___vue_template_functional__ = false
/* styles */
var home___vue_styles__ = home_injectStyle
/* scopeId */
var home___vue_scopeId__ = "data-v-69e16561"
/* moduleIdentifier (server only) */
var home___vue_module_identifier__ = null

var home_Component = Object(component_normalizer["a" /* default */])(
  home,
  home_render,
  home_staticRenderFns,
  home___vue_template_functional__,
  home___vue_styles__,
  home___vue_scopeId__,
  home___vue_module_identifier__
)

/* harmony default export */ var pages_home = (home_Component.exports);

// EXTERNAL MODULE: ./src/assets/area.ts
var assets_area = __webpack_require__("6z/E");

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/pages/subscribe.vue
var subscribe___extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var subscribe___decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var subscribe_Subscribe = /** @class */ (function (_super) {
    subscribe___extends(Subscribe, _super);
    function Subscribe() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.dataList = assets_area["a" /* default */];
        _this.showForm = false;
        _this.show = {
            phone: false,
            area: false,
            confirm: false,
            success: false // 成功标识
        };
        _this.buyModel = {
            cityName: "",
            phone: "",
            city: "",
            appointmentShop: "" // 预约门店
        };
        _this.rules = {
            cityName: { required: true, message: "请选择所在城市" },
            phone: [{ required: true, message: "请输入正确的手机号" }, { validator: _this.$validator.phoneNumber }]
        };
        return _this;
    }
    // 选择城市点击事件
    Subscribe.prototype.onCityPickerConfirm = function (currentCitys) {
        // console.log(currentCitys)
        currentCitys.pop();
        this.buyModel.cityName = currentCitys;
        this.buyModel.city = currentCitys[1];
    };
    /**
    * 键盘输入
    * @param val 案件内容
    */
    Subscribe.prototype.onKeyBoardInputPhone = function (val) {
        if (this.buyModel.phone.length === 11)
            return;
        this.buyModel.phone += val.toString();
    };
    /**
     * 按钮删除操作
     */
    Subscribe.prototype.onKeyBoardDeletePhone = function () {
        var length = this.buyModel.phone.length;
        if (length === 0)
            return;
        this.buyModel.phone = this.buyModel.phone.substring(0, length - 1);
    };
    // private onAreaConfirmClick(val) {
    //   console.log(val)
    //   if (val && val.length >= 2) {
    //     let city = val[1]
    //     this.buyModel.city = city.code
    //     this.buyModel.cityName = city.name
    //   }
    //   this.show.area = false
    // }
    Subscribe.prototype.onSubmitClick = function () {
        var _this = this;
        this.$validator.validate(this.buyModel, this.rules).then(function (error) {
            if (!error) {
                _this.show.confirm = true;
            }
            else {
                _this.$toast(error);
            }
        });
        // TODO 测试。先注释
        // this.$validator.validate(this.buyModel, this.rules).then(err => {
        //   if (err) {
        //     this.$toast(err)
        //     return
        //   }
        //   this.show.confirm = true
        // })
    };
    Subscribe.prototype.onConfirmClick = function () {
        var _this = this;
        this.show.success = true;
        setTimeout(function () {
            _this.show.success = false;
            _this.$router.push('/home');
        }, 3000);
    };
    Subscribe = subscribe___decorate([
        vue_class_component_common_default()({
            components: {
                CityPicker: city_picker["a" /* default */],
            }
        })
    ], Subscribe);
    return Subscribe;
}(vue_esm["default"]));
/* harmony default export */ var subscribe = (subscribe_Subscribe);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-3dca372e","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/pages/subscribe.vue
var subscribe_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"page subscribe"},[_c('p',{staticClass:"title"},[_vm._v("提交购车需求,金牌顾问为您服务")]),_vm._v(" "),_c('div',{staticClass:"buy-form"},[_c('van-cell',{staticClass:"cityLive",attrs:{"title":"所在城市","is-link":"","value":_vm._f("cityConvert")(_vm.buyModel.cityName)},on:{"click":function($event){_vm.$refs['cityPicker'].show()}}}),_vm._v(" "),_c('city-picker',{ref:"cityPicker",attrs:{"required":""},on:{"on-confirm":_vm.onCityPickerConfirm}}),_vm._v(" "),_c('van-field',{staticClass:"phoneText",attrs:{"maxlength":"11","label":"手机号码","placeholder":"请输入您的手机号","icon":"clear"},on:{"click-icon":function($event){_vm.buyModel.phone = ''},"focus":function($event){_vm.show.phone = true}},model:{value:(_vm.buyModel.phone),callback:function ($$v) {_vm.$set(_vm.buyModel, "phone", $$v)},expression:"buyModel.phone"}}),_vm._v(" "),_c('van-number-keyboard',{attrs:{"show":_vm.show.phone,"title":"洋葱汽车安全键盘","close-button-text":"完成"},on:{"blur":function($event){_vm.show.phone = false},"input":_vm.onKeyBoardInputPhone,"delete":_vm.onKeyBoardDeletePhone}})],1),_vm._v(" "),_c('van-button',{staticClass:"full-radius",attrs:{"type":"primary","size":"large"},on:{"click":_vm.onSubmitClick}},[_vm._v("帮我买车")]),_vm._v(" "),_c('van-dialog',{attrs:{"confirmButtonText":"立即预约"},on:{"confirm":_vm.onConfirmClick},model:{value:(_vm.show.confirm),callback:function ($$v) {_vm.$set(_vm.show, "confirm", $$v)},expression:"show.confirm"}},[_c('div',{staticClass:"buy-info"},[_c('p',[_vm._v("您的电话："+_vm._s(_vm.buyModel.phone))]),_vm._v(" "),_c('p',[_vm._v("所在城市："+_vm._s(_vm._f("cityConvert")(_vm.buyModel.cityName)))])])]),_vm._v(" "),_c('van-dialog',{attrs:{"show-confirm-button":false},model:{value:(_vm.show.success),callback:function ($$v) {_vm.$set(_vm.show, "success", $$v)},expression:"show.success"}},[_c('div',{staticClass:"buy-success"},[_c('img',{attrs:{"src":"/static/images/home/success.png"}})]),_vm._v(" "),_c('p',[_vm._v("提交成功")]),_vm._v(" "),_c('p',{staticClass:"buy-success-info"},[_vm._v("金牌顾问第一时间会联系您")])])],1)}
var subscribe_staticRenderFns = []

// CONCATENATED MODULE: ./src/pages/subscribe.vue
function subscribe_injectStyle (context) {
  __webpack_require__("6P+K")
  __webpack_require__("6fZv")
}
/* script */


/* template */

/* template functional */
var subscribe___vue_template_functional__ = false
/* styles */
var subscribe___vue_styles__ = subscribe_injectStyle
/* scopeId */
var subscribe___vue_scopeId__ = "data-v-3dca372e"
/* moduleIdentifier (server only) */
var subscribe___vue_module_identifier__ = null

var subscribe_Component = Object(component_normalizer["a" /* default */])(
  subscribe,
  subscribe_render,
  subscribe_staticRenderFns,
  subscribe___vue_template_functional__,
  subscribe___vue_styles__,
  subscribe___vue_scopeId__,
  subscribe___vue_module_identifier__
)

/* harmony default export */ var pages_subscribe = (subscribe_Component.exports);

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/pages/faq.vue
var faq___extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var faq___decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var faq_Faq = /** @class */ (function (_super) {
    faq___extends(Faq, _super);
    function Faq() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.show = {
            navBar: false
        };
        return _this;
    }
    Faq = faq___decorate([
        vue_class_component_common_default()({
            components: {
                Question: home_question,
                NavBar: common_nav_bar
            }
        })
    ], Faq);
    return Faq;
}(vue_esm["default"]));
/* harmony default export */ var faq = (faq_Faq);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-0bb91d77","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/pages/faq.vue
var faq_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"page faq"},[_c('van-cell-group',[_c('van-cell',{attrs:{"title":"常见问题"}},[_c('van-icon',{staticClass:"right-icon",attrs:{"slot":"right-icon","name":"wap-nav"},on:{"click":function($event){_vm.show.navBar = true}},slot:"right-icon"})],1)],1),_vm._v(" "),_c('question'),_vm._v(" "),_c('nav-bar',{model:{value:(_vm.show.navBar),callback:function ($$v) {_vm.$set(_vm.show, "navBar", $$v)},expression:"show.navBar"}})],1)}
var faq_staticRenderFns = []

// CONCATENATED MODULE: ./src/pages/faq.vue
function faq_injectStyle (context) {
  __webpack_require__("vqxC")
}
/* script */


/* template */

/* template functional */
var faq___vue_template_functional__ = false
/* styles */
var faq___vue_styles__ = faq_injectStyle
/* scopeId */
var faq___vue_scopeId__ = "data-v-0bb91d77"
/* moduleIdentifier (server only) */
var faq___vue_module_identifier__ = null

var faq_Component = Object(component_normalizer["a" /* default */])(
  faq,
  faq_render,
  faq_staticRenderFns,
  faq___vue_template_functional__,
  faq___vue_styles__,
  faq___vue_scopeId__,
  faq___vue_module_identifier__
)

/* harmony default export */ var pages_faq = (faq_Component.exports);

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/pages/buy-car-list.vue
var buy_car_list___extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var buy_car_list___decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var buy_car_list_BuyCarList = /** @class */ (function (_super) {
    buy_car_list___extends(BuyCarList, _super);
    function BuyCarList() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.searchModel = {
            brandId: '',
            name: ''
        };
        _this.carDataSet = []; // 查询到的车辆 
        // 控制各个组件显示flag
        _this.show = {
            navBar: false,
            search: false,
            loading: false,
            finished: false,
            toTop: false
        };
        _this.dataSet = [];
        return _this;
    }
    Object.defineProperty(BuyCarList.prototype, "keyWord", {
        get: function () {
            return this.searchModel.name;
        },
        set: function (val) {
            this.searchModel.name = val;
            this.show.search = val !== "";
        },
        enumerable: true,
        configurable: true
    });
    BuyCarList.prototype.scrollTop = function (val) {
        window.scrollTo(0, 0);
    };
    BuyCarList.prototype.onScrollTopChage = function () {
        var height = document.documentElement.scrollTop || window.pageYOffset;
        this.show.toTop = height > 300;
    };
    /**
     * 点击清空按钮
     */
    BuyCarList.prototype.onClearClick = function () {
        this.keyWord = '';
        this.searchCarList();
    };
    /**
     * 获取当前品牌车辆
     */
    BuyCarList.prototype.searchCarList = function () {
        var _this = this;
        this.carShowManagementService.searchCarList(this.searchModel)
            .subscribe(function (data) {
            _this.carDataSet = data;
        }, function (err) {
            _this.$toast(err.msg);
        });
    };
    BuyCarList.prototype.mounted = function () {
        this.dataSet = [];
        if (this.brandId > 0)
            this.searchModel.brandId = this.brandId;
        if (this.transKeyWord !== '')
            this.keyWord = this.transKeyWord;
        this.searchCarList();
        window.addEventListener('scroll', this.onScrollTopChage);
    };
    BuyCarList.prototype.beforeDestroy = function () {
        window.removeEventListener('scroll', this.onScrollTopChage);
    };
    buy_car_list___decorate([
        Object(decorator["b" /* Dependencies */])(car_show_management_service["a" /* carShowManagementService */])
    ], BuyCarList.prototype, "carShowManagementService", void 0);
    buy_car_list___decorate([
        Object(vue_property_decorator_umd["Prop"])({
            default: -1
        })
    ], BuyCarList.prototype, "brandId", void 0);
    buy_car_list___decorate([
        Object(vue_property_decorator_umd["Prop"])({
            default: ''
        })
    ], BuyCarList.prototype, "transKeyWord", void 0);
    BuyCarList = buy_car_list___decorate([
        vue_class_component_common_default()({
            components: {
                NavBar: common_nav_bar
            }
        })
    ], BuyCarList);
    return BuyCarList;
}(vue_esm["default"]));
/* harmony default export */ var buy_car_list = (buy_car_list_BuyCarList);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-7ef8c8af","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/pages/buy-car-list.vue
var buy_car_list_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component buy-car-list"},[_c('form',{attrs:{"action":"/"}},[_c('van-search',{attrs:{"placeholder":"寻找您想要买的爱车","show-action":""},on:{"click-icon":_vm.onClearClick,"search":_vm.searchCarList},model:{value:(_vm.keyWord),callback:function ($$v) {_vm.keyWord=$$v},expression:"keyWord"}},[_c('div',{attrs:{"slot":"action"},slot:"action"},[(!_vm.show.search)?_c('van-icon',{staticClass:"buy-car-list-nav-bar",attrs:{"name":"wap-nav"},on:{"click":function($event){_vm.show.navBar = true}}}):_c('div',{staticClass:"buy-car-list-nav-bar",on:{"click":_vm.searchCarList}},[_vm._v("搜索")])],1)])],1),_vm._v(" "),_vm._l((_vm.carDataSet),function(item,index){return (_vm.carDataSet.length > 0)?_c('van-row',{key:index,staticClass:"buy-car-list-item"},[_c('div',{on:{"click":function($event){_vm.$router.push(("/details/" + (item.carId)))}}},[_c('van-col',{attrs:{"span":"10"}},[_c('div',[_c('img',{attrs:{"src":(item.carPictures[0] || {}).url,"height":"80px"}})])]),_vm._v(" "),_c('van-col',{staticClass:"carStyle",attrs:{"span":"14"}},[_c('div',{staticClass:"car"},[_c('span',[_vm._v(_vm._s(item.brandSeriesName))]),_vm._v(" "),_c('br'),_vm._v(" "),_c('span',{staticClass:"car-info"},[_vm._v(_vm._s(item.modelName))])]),_vm._v(" "),_c('van-row',[_c('van-col',{staticClass:"car-first",attrs:{"span":"12"}},[_vm._v("首付"+_vm._s(_vm._f("toThousands")(item.firstPayment/1000))+"万")]),_vm._v(" "),_c('van-col',{staticClass:"car-month",attrs:{"span":"12"}},[_vm._v("月供"+_vm._s(_vm._f("toThousands")(item.monthRent))+"元")])],1)],1)],1)]):_c('div',{staticClass:"no-cars"},[_c('p',[_vm._v("新车型即将上架，敬请期待")])])}),_vm._v(" "),_c('div',{directives:[{name:"show",rawName:"v-show",value:(_vm.show.toTop),expression:"show.toTop"}],staticClass:"to-top",on:{"click":_vm.scrollTop}},[_c('van-icon',{attrs:{"name":"upgrade","color":"#f2f2f2"}})],1),_vm._v(" "),_c('nav-bar',{model:{value:(_vm.show.navBar),callback:function ($$v) {_vm.$set(_vm.show, "navBar", $$v)},expression:"show.navBar"}})],2)}
var buy_car_list_staticRenderFns = []

// CONCATENATED MODULE: ./src/pages/buy-car-list.vue
function buy_car_list_injectStyle (context) {
  __webpack_require__("hZOI")
}
/* script */


/* template */

/* template functional */
var buy_car_list___vue_template_functional__ = false
/* styles */
var buy_car_list___vue_styles__ = buy_car_list_injectStyle
/* scopeId */
var buy_car_list___vue_scopeId__ = "data-v-7ef8c8af"
/* moduleIdentifier (server only) */
var buy_car_list___vue_module_identifier__ = null

var buy_car_list_Component = Object(component_normalizer["a" /* default */])(
  buy_car_list,
  buy_car_list_render,
  buy_car_list_staticRenderFns,
  buy_car_list___vue_template_functional__,
  buy_car_list___vue_styles__,
  buy_car_list___vue_scopeId__,
  buy_car_list___vue_module_identifier__
)

/* harmony default export */ var pages_buy_car_list = (buy_car_list_Component.exports);

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/object/define-property.js
var define_property = __webpack_require__("C4MV");
var define_property_default = /*#__PURE__*/__webpack_require__.n(define_property);

// EXTERNAL MODULE: ./node_modules/babel-runtime/helpers/typeof.js
var helpers_typeof = __webpack_require__("pFYg");
var typeof_default = /*#__PURE__*/__webpack_require__.n(helpers_typeof);

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/object/get-own-property-descriptor.js
var get_own_property_descriptor = __webpack_require__("K6ED");
var get_own_property_descriptor_default = /*#__PURE__*/__webpack_require__.n(get_own_property_descriptor);

// EXTERNAL MODULE: ./src/utils/net.service.ts + 7 modules
var net_service = __webpack_require__("1pVc");

// EXTERNAL MODULE: ./src/config/server/manage-service/index.ts + 9 modules
var manage_service = __webpack_require__("afVn");

// CONCATENATED MODULE: ./src/services/manage-service/contract-details-controller.service.ts



var contract_details_controller_service___decorate = this && this.__decorate || function (decorators, target, key, desc) {
    var c = arguments.length,
        r = c < 3 ? target : desc === null ? desc = get_own_property_descriptor_default()(target, key) : desc,
        d;
    if ((typeof Reflect === "undefined" ? "undefined" : typeof_default()(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
        if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    }return c > 3 && r && define_property_default()(target, key, r), r;
};



var contract_details_controller_service_ContractDetailsControllerService = /** @class */function () {
    function ContractDetailsControllerService() {}
    /**
     * 获取订单合同数据
     */
    ContractDetailsControllerService.prototype.getContractDetailsListByOrderId = function (orderId) {
        return this.netService.send({
            server: manage_service["a" /* manageService */].contractDetailsController.getContractDetailsListByOrderId,
            data: {
                orderId: orderId
            }
        });
    };
    contract_details_controller_service___decorate([Object(decorator["c" /* Inject */])(net_service["NetService"])], ContractDetailsControllerService.prototype, "netService", void 0);
    return ContractDetailsControllerService;
}();

// EXTERNAL MODULE: ./node_modules/vant/es/index.js + 107 modules
var es = __webpack_require__("Fd2+");

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/order/order-contract.vue
var order_contract___extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var order_contract___decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var order_contract_OrderContract = /** @class */ (function (_super) {
    order_contract___extends(OrderContract, _super);
    function OrderContract() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.dataCompact = [];
        return _this;
    }
    // private dataSet: any = []
    // @Prop() orderId: number;
    // @Watch('orderId', { immediate: true })
    // onOrderIdChange() {
    //   // TODO  重新获取合同列表
    //   this.dataSet = []
    //   let index = 0
    //   while (index < 4) {
    //     this.dataSet.push(this.createTmpContrace())
    //     index++
    //   }
    // }
    // private createTmpContrace() {
    //   return {
    //     id: 1,
    //     title: "租赁合同",
    //     state: false,
    //     content: "balabala租赁合同balabala租赁合同balabala租赁合同balabala租赁合同" +
    //       "balabala租赁合同balabala租赁合同balabala租赁合同balabala租赁合同" +
    //       "balabala租赁合同balabala租赁合同balabala租赁合同balabala租赁合同" +
    //       "balabala租赁合同balabala租赁合同balabala租赁合同balabala租赁合同" +
    //       "balabala租赁合同balabala租赁合同balabala租赁合同balabala租赁合同" +
    //       "balabala租赁合同balabala租赁合同balabala租赁合同balabala租赁合同" +
    //       "balabala租赁合同balabala租赁合同balabala租赁合同balabala租赁合同"
    //   }
    // }
    OrderContract.prototype.onitemClick = function (item, code) {
        if (code == 1000) {
            Object(es["a" /* ImagePreview */])([
                item
            ], 1);
        }
        else {
            this.$toast('当前合同暂未生成');
        }
    };
    OrderContract.prototype.getContractDetails = function () {
        var _this = this;
        this.contractDetailsControllerService.getContractDetailsListByOrderId(156).subscribe(function (data) {
            _this.dataCompact = data;
            // console.log(this.dataCompact, '789789789')
        }, function (err) { return _this.$toast(err.msg); });
    };
    OrderContract.prototype.mounted = function () {
        this.getContractDetails();
    };
    order_contract___decorate([
        Object(decorator["b" /* Dependencies */])(contract_details_controller_service_ContractDetailsControllerService)
    ], OrderContract.prototype, "contractDetailsControllerService", void 0);
    OrderContract = order_contract___decorate([
        vue_class_component_common_default()({})
    ], OrderContract);
    return OrderContract;
}(vue_esm["default"]));
/* harmony default export */ var order_contract = (order_contract_OrderContract);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-5d679f0a","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/order/order-contract.vue
var order_contract_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-contract"},[_c('van-cell-group',_vm._l((this.dataCompact),function(item,index){return _c('van-cell',{key:index,attrs:{"title":("《" + (item.contractName) + "》"),"value":_vm.$dict.getDictName(item.signContract),"is-link":""},on:{"click":function($event){_vm.onitemClick(item.viewpdfUrl,item.code)}}})}))],1)}
var order_contract_staticRenderFns = []

// CONCATENATED MODULE: ./src/components/order/order-contract.vue
function order_contract_injectStyle (context) {
  __webpack_require__("Q2H+")
}
/* script */


/* template */

/* template functional */
var order_contract___vue_template_functional__ = false
/* styles */
var order_contract___vue_styles__ = order_contract_injectStyle
/* scopeId */
var order_contract___vue_scopeId__ = "data-v-5d679f0a"
/* moduleIdentifier (server only) */
var order_contract___vue_module_identifier__ = null

var order_contract_Component = Object(component_normalizer["a" /* default */])(
  order_contract,
  order_contract_render,
  order_contract_staticRenderFns,
  order_contract___vue_template_functional__,
  order_contract___vue_styles__,
  order_contract___vue_scopeId__,
  order_contract___vue_module_identifier__
)

/* harmony default export */ var order_order_contract = (order_contract_Component.exports);

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/order/order-record.vue
var order_record___extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var order_record___decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var order_record_OrderRecord = /** @class */ (function (_super) {
    order_record___extends(OrderRecord, _super);
    function OrderRecord() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.dataSet = [];
        return _this;
    }
    // @Prop() orderId: number;
    // @Watch('orderId', { immediate: true })
    // onOrderIdChange() {
    //   // TODO  重新获取合同列表
    //   this.dataSet = []
    //   let index = 0
    //   while (index < 4) {
    //     this.dataSet.push(this.createTmpRecord())
    //     index++
    //   }
    // }
    // private createTmpRecord() {
    //   return {
    //     id: 1,
    //     title: "订单签署",
    //     date: new Date()
    //   }
    // }
    OrderRecord.prototype.orderRecordfun = function (val) {
        this.dataSet = val;
    };
    OrderRecord.prototype.mounted = function () {
        // this.dataSet = this.orderInfo
        // console.log(this.dataSet,'ccaozuo')
    };
    order_record___decorate([
        lib["d" /* State */]
    ], OrderRecord.prototype, "orderInfo", void 0);
    OrderRecord = order_record___decorate([
        vue_class_component_common_default()({})
    ], OrderRecord);
    return OrderRecord;
}(vue_esm["default"]));
/* harmony default export */ var order_record = (order_record_OrderRecord);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-7750be58","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/order/order-record.vue
var order_record_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-record"},[_c('van-cell-group',_vm._l((this.dataSet),function(item,index){return _c('van-cell',{key:index,attrs:{"title":_vm.$dict.getDictName(item.orderLink),"label":_vm._f("dateFormat")(item.operateTime)}})}))],1)}
var order_record_staticRenderFns = []

// CONCATENATED MODULE: ./src/components/order/order-record.vue
function order_record_injectStyle (context) {
  __webpack_require__("2JjU")
}
/* script */


/* template */

/* template functional */
var order_record___vue_template_functional__ = false
/* styles */
var order_record___vue_styles__ = order_record_injectStyle
/* scopeId */
var order_record___vue_scopeId__ = "data-v-7750be58"
/* moduleIdentifier (server only) */
var order_record___vue_module_identifier__ = null

var order_record_Component = Object(component_normalizer["a" /* default */])(
  order_record,
  order_record_render,
  order_record_staticRenderFns,
  order_record___vue_template_functional__,
  order_record___vue_styles__,
  order_record___vue_scopeId__,
  order_record___vue_module_identifier__
)

/* harmony default export */ var order_order_record = (order_record_Component.exports);

// EXTERNAL MODULE: ./src/services/manage-service/product-order.service.ts
var product_order_service = __webpack_require__("vpJI");

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/pages/my-order.vue
var my_order___extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var my_order___decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var my_order_MyOrder = /** @class */ (function (_super) {
    my_order___extends(MyOrder, _super);
    function MyOrder() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.orderNumber = ''; // 获取当前订单号
        _this.activatedCollapse = [];
        _this.productOrderInfo = {}; // 订单基本信息 存储
        return _this;
    }
    MyOrder.prototype.getOredrMessage = function () {
        var _this = this;
        this.productOrderService.findOrderInfoByOrderNumber(this.orderNumber).subscribe(function (data) {
            _this.productOrderInfo = data;
        }, function (err) { return _this.$toast(err.msg); });
    };
    /**
     * 操作记录
     */
    MyOrder.prototype.operating = function () {
        var a = this.productOrderInfo.orderProcessRecord;
        var orderRecord = this.$refs['order-record'];
        orderRecord.orderRecordfun(a);
    };
    MyOrder.prototype.mounted = function () {
        this.orderNumber = this.orderInfo.orderNumber;
        this.getOredrMessage();
    };
    my_order___decorate([
        Object(decorator["b" /* Dependencies */])(product_order_service["ProductOrderService"])
    ], MyOrder.prototype, "productOrderService", void 0);
    my_order___decorate([
        lib["b" /* Getter */]
    ], MyOrder.prototype, "hasOrder", void 0);
    my_order___decorate([
        lib["d" /* State */]
    ], MyOrder.prototype, "orderInfo", void 0);
    MyOrder = my_order___decorate([
        vue_class_component_common_default()({
            components: {
                OrderContract: order_order_contract,
                OrderRecord: order_order_record
            }
        })
    ], MyOrder);
    return MyOrder;
}(vue_esm["default"]));
/* harmony default export */ var my_order = (my_order_MyOrder);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-4777e23a","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/pages/my-order.vue
var my_order_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"page my-order"},[(!_vm.hasOrder)?_c('div',{key:"no-order",staticClass:"my-order-no"},[_c('img',{attrs:{"src":"/static/images/home/no-order.png"}})]):_c('div',{key:"has-order"},[_c('van-cell-group',[_c('van-cell',{attrs:{"title":("订单编号：" + (_vm.productOrderInfo.orderNumber))}}),_vm._v(" "),_c('van-cell',{attrs:{"title":("车型：" + (_vm.productOrderInfo.orderCar.modelName))}}),_vm._v(" "),_c('van-cell',{attrs:{"title":"下单城市","is-link":"","value":_vm._f("cityConvert")([_vm.productOrderInfo.city])}}),_vm._v(" "),_c('van-cell',{attrs:{"title":("首付：" + (_vm.productOrderInfo.schedulePlanResultModel.schedulePlanResult.firstPayment) + " 元")}}),_vm._v(" "),_c('van-cell',{attrs:{"title":("期数：" + (_vm.productOrderInfo.schedulePlanResultModel.schedulePlanResult.planType) + " 期")}}),_vm._v(" "),_c('van-cell',{attrs:{"title":("月供信息：" + (_vm.productOrderInfo.schedulePlanResultModel.schedulePlanResult.firstYearMonthrent) + "元 ")}})],1),_vm._v(" "),_c('van-collapse',{model:{value:(_vm.activatedCollapse),callback:function ($$v) {_vm.activatedCollapse=$$v},expression:"activatedCollapse"}},[_c('van-collapse-item',{attrs:{"title":"合同详情","name":"contract"}},[_c('order-contract',{attrs:{"orderId":_vm.orderInfo.id}})],1),_vm._v(" "),_c('div',{on:{"click":_vm.operating}},[_c('van-collapse-item',{attrs:{"title":"订单操作记录","name":"record"}},[_c('order-record',{ref:"order-record",attrs:{"orderId":_vm.orderInfo.id}})],1)],1)],1)],1)])}
var my_order_staticRenderFns = []

// CONCATENATED MODULE: ./src/pages/my-order.vue
function my_order_injectStyle (context) {
  __webpack_require__("OBem")
}
/* script */


/* template */

/* template functional */
var my_order___vue_template_functional__ = false
/* styles */
var my_order___vue_styles__ = my_order_injectStyle
/* scopeId */
var my_order___vue_scopeId__ = "data-v-4777e23a"
/* moduleIdentifier (server only) */
var my_order___vue_module_identifier__ = null

var my_order_Component = Object(component_normalizer["a" /* default */])(
  my_order,
  my_order_render,
  my_order_staticRenderFns,
  my_order___vue_template_functional__,
  my_order___vue_styles__,
  my_order___vue_scopeId__,
  my_order___vue_module_identifier__
)

/* harmony default export */ var pages_my_order = (my_order_Component.exports);

// CONCATENATED MODULE: ./src/services/manage-service/payment-schedule-controller.service.ts



var payment_schedule_controller_service___decorate = this && this.__decorate || function (decorators, target, key, desc) {
    var c = arguments.length,
        r = c < 3 ? target : desc === null ? desc = get_own_property_descriptor_default()(target, key) : desc,
        d;
    if ((typeof Reflect === "undefined" ? "undefined" : typeof_default()(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
        if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    }return c > 3 && r && define_property_default()(target, key, r), r;
};



var payment_schedule_controller_service_PaymentScheduleControllerService = /** @class */function () {
    function PaymentScheduleControllerService() {}
    /**
     * 获取还款详情
     */
    PaymentScheduleControllerService.prototype.getPaymentScheduleList = function (personalId) {
        return this.netService.send({
            server: manage_service["a" /* manageService */].paymentScheduleController.getPaymentScheduleList,
            data: {
                personId: personalId
            }
        });
    };
    payment_schedule_controller_service___decorate([Object(decorator["c" /* Inject */])(net_service["NetService"])], PaymentScheduleControllerService.prototype, "netService", void 0);
    return PaymentScheduleControllerService;
}();

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/pages/payment-record.vue
var payment_record___extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var payment_record___decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var payment_record_PaymentRecord = /** @class */ (function (_super) {
    payment_record___extends(PaymentRecord, _super);
    function PaymentRecord() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.dataSet = [];
        return _this;
    }
    // 查询还款详情
    PaymentRecord.prototype.getPaymentDetails = function () {
        var _this = this;
        this.paymentScheduleControllerService.getPaymentScheduleList(this.userData.id).subscribe(function (data) {
            _this.dataSet = data;
        }, function (err) { return _this.$toast(err.msg); });
    };
    PaymentRecord.prototype.mounted = function () {
        if (this.hasOrder)
            this.getPaymentDetails();
    };
    payment_record___decorate([
        Object(decorator["b" /* Dependencies */])(payment_schedule_controller_service_PaymentScheduleControllerService)
    ], PaymentRecord.prototype, "paymentScheduleControllerService", void 0);
    payment_record___decorate([
        lib["d" /* State */]
    ], PaymentRecord.prototype, "userData", void 0);
    payment_record___decorate([
        lib["b" /* Getter */]
    ], PaymentRecord.prototype, "hasOrder", void 0);
    PaymentRecord = payment_record___decorate([
        vue_class_component_common_default()({
            components: {},
            filters: {
                convertState: function (key) {
                    var str = '';
                    switch (key) {
                        case 4:
                            str = '已还清';
                            break;
                        case 3:
                            str = '已逾期';
                            break;
                        case 2:
                            str = '待还款';
                            break;
                        default:
                            str = '未出账单';
                            break;
                    }
                    return str;
                }
            }
        })
    ], PaymentRecord);
    return PaymentRecord;
}(vue_esm["default"]));
/* harmony default export */ var payment_record = (payment_record_PaymentRecord);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-530882c9","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/pages/payment-record.vue
var payment_record_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"page payment-record"},[(!_vm.hasOrder)?_c('div',{key:"no-order",staticClass:"my-order-no"},[_c('img',{attrs:{"src":"/static/images/home/no-order.png"}})]):_c('div',{key:"has-order"},[_c('div',{staticClass:"break-line"}),_vm._v(" "),_c('div',{staticClass:"payment-record-table"},[_c('van-row',{staticClass:"payment-record-table-title"},[_c('van-col',{attrs:{"span":4}},[_vm._v("期数")]),_vm._v(" "),_c('van-col',{attrs:{"span":8}},[_vm._v("还款日期")]),_vm._v(" "),_c('van-col',{attrs:{"span":6}},[_vm._v("还款金额")]),_vm._v(" "),_c('van-col',{attrs:{"span":6}},[_vm._v("还款状态")])],1),_vm._v(" "),_c('div',{staticClass:"van-hairline--bottom"}),_vm._v(" "),_vm._l((_vm.dataSet),function(item){return _c('van-row',{key:item.period,staticClass:"payment-record-table-content"},[_c('van-col',{attrs:{"span":4}},[_vm._v(_vm._s(((item.periods) + "/" + (_vm.dataSet.length))))]),_vm._v(" "),_c('van-col',{attrs:{"span":8}},[_vm._v(_vm._s(_vm._f("dateFormat")(item.minRepayDate,'yyyy-MM-dd')))]),_vm._v(" "),_c('van-col',{attrs:{"span":6}},[_vm._v("￥"+_vm._s(_vm._f("toThousands")(item.sumAmount)))]),_vm._v(" "),_c('van-col',{attrs:{"span":6}},[_vm._v(_vm._s(item.status))])],1)})],2)])])}
var payment_record_staticRenderFns = []

// CONCATENATED MODULE: ./src/pages/payment-record.vue
function payment_record_injectStyle (context) {
  __webpack_require__("vOxv")
}
/* script */


/* template */

/* template functional */
var payment_record___vue_template_functional__ = false
/* styles */
var payment_record___vue_styles__ = payment_record_injectStyle
/* scopeId */
var payment_record___vue_scopeId__ = "data-v-530882c9"
/* moduleIdentifier (server only) */
var payment_record___vue_module_identifier__ = null

var payment_record_Component = Object(component_normalizer["a" /* default */])(
  payment_record,
  payment_record_render,
  payment_record_staticRenderFns,
  payment_record___vue_template_functional__,
  payment_record___vue_styles__,
  payment_record___vue_scopeId__,
  payment_record___vue_module_identifier__
)

/* harmony default export */ var pages_payment_record = (payment_record_Component.exports);

// CONCATENATED MODULE: ./src/router/routes.ts







var routes_CustomInformation = function CustomInformation() {
    return promise_default.a.resolve(__webpack_require__("nBIJ"));
};
var routes_ContactInformation = function ContactInformation() {
    return promise_default.a.resolve(__webpack_require__("9+Ux"));
};
var routes_UploadIdPhotoFirst = function UploadIdPhotoFirst() {
    return promise_default.a.resolve(__webpack_require__("ZcqS"));
};
var routes_UploadIdPhotoTwo = function UploadIdPhotoTwo() {
    return promise_default.a.resolve(__webpack_require__("s2K6"));
};
var routes_UploadIdPhotoThree = function UploadIdPhotoThree() {
    return promise_default.a.resolve(__webpack_require__("oplY"));
};
var routes_AddInformation = function AddInformation() {
    return promise_default.a.resolve(__webpack_require__("rQiK"));
};
var routes_Details = function Details() {
    return promise_default.a.resolve(__webpack_require__("KBJM"));
};
var routes_AllVehicles = function AllVehicles() {
    return promise_default.a.resolve(__webpack_require__("iX+j"));
};
var routes_KnowOnionCar = function KnowOnionCar() {
    return promise_default.a.resolve(__webpack_require__("PLP8"));
};
// const AddDocumentInfor = () => Promise.resolve(require('~/pages/add-document-infor.vue'))
// 路由信息配置
var routes = [{
    path: '/home',
    name: 'Home',
    component: pages_home,
    meta: {
        title: '洋葱汽车'
    }
}, {
    path: '/subscribe',
    name: 'Subscribe',
    component: pages_subscribe,
    meta: {
        title: '帮我买车'
    }
}, {
    path: '/FAQ',
    name: 'FAQ',
    component: pages_faq
}, {
    path: '/buy-car-list',
    name: 'BuyCarList',
    component: pages_buy_car_list,
    props: function props(route) {
        return {
            brandId: route.query.b,
            transKeyWord: route.query.k
        };
    }
}, {
    path: '/custom-information',
    name: 'custom-information',
    component: routes_CustomInformation
}, {
    path: '/contact-information',
    name: 'contact-information',
    component: routes_ContactInformation
}, {
    path: '/upload-id-photo-first',
    name: 'upload-id-photo-first',
    component: routes_UploadIdPhotoFirst
}, {
    path: '/upload-id-photo-two',
    name: 'upload-id-photo-two',
    component: routes_UploadIdPhotoTwo
}, {
    path: '/upload-id-photo-three',
    name: 'upload-id-photo-three',
    component: routes_UploadIdPhotoThree
}, {
    path: '/add-information',
    name: 'add-information',
    component: routes_AddInformation
}, {
    path: '/my-order',
    name: 'MyOrder',
    meta: {
        title: '我的订单'
    },
    component: pages_my_order
}, {
    path: '/payment-record',
    name: 'PaymentRecord',
    meta: {
        title: '还款明细'
    },
    component: pages_payment_record
}, {
    path: '/details/:carId',
    name: 'details',
    component: routes_Details,
    props: true
}, {
    path: '/all-vehicles',
    name: 'AllVehicles',
    component: routes_AllVehicles
}, {
    path: '/know-onion-car',
    name: 'KnowOnionCar',
    component: routes_KnowOnionCar
}];
/* harmony default export */ var router_routes = (routes);
// CONCATENATED MODULE: ./src/router/index.ts



var router___awaiter = this && this.__awaiter || function (thisArg, _arguments, P, generator) {
    return new (P || (P = promise_default.a))(function (resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : new P(function (resolve) {
                resolve(result.value);
            }).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var router___generator = this && this.__generator || function (thisArg, body) {
    var _ = { label: 0, sent: function sent() {
            if (t[0] & 1) throw t[1];return t[1];
        }, trys: [], ops: [] },
        f,
        y,
        t,
        g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof symbol_default.a === "function" && (g[iterator_default.a] = function () {
        return this;
    }), g;
    function verb(n) {
        return function (v) {
            return step([n, v]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) {
            try {
                if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [0, t.value];
                switch (op[0]) {
                    case 0:case 1:
                        t = op;break;
                    case 4:
                        _.label++;return { value: op[1], done: false };
                    case 5:
                        _.label++;y = op[1];op = [0];continue;
                    case 7:
                        op = _.ops.pop();_.trys.pop();continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                            _ = 0;continue;
                        }
                        if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                            _.label = op[1];break;
                        }
                        if (op[0] === 6 && _.label < t[1]) {
                            _.label = t[1];t = op;break;
                        }
                        if (t && _.label < t[2]) {
                            _.label = t[2];_.ops.push(op);break;
                        }
                        if (t[2]) _.ops.pop();
                        _.trys.pop();continue;
                }
                op = body.call(thisArg, _);
            } catch (e) {
                op = [6, e];y = 0;
            } finally {
                f = t = 0;
            }
        }if (op[0] & 5) throw op[1];return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var router__this = this;




var Login = function Login() {
    return __webpack_require__.e/* import() */(2).then(__webpack_require__.bind(null, "Luci"));
};
var Index = function Index() {
    return __webpack_require__.e/* import() */(1).then(__webpack_require__.bind(null, "2NXm"));
};
var NotFound = function NotFound() {
    return __webpack_require__.e/* import() */(0).then(__webpack_require__.bind(null, "NLAC"));
};

vue_esm["default"].use(vue_router_esm["a" /* default */]);
// 生成路由配置
var src_router_routes = [{
    path: '/',
    name: 'Login',
    component: Login,
    beforeEnter: function beforeEnter(to, from, next) {
        src_store.dispatch('clearUserLoginData');
        next();
    }
}, {
    path: '/index',
    name: 'Index',
    component: Index,
    // index 页面使用了router-view 这里需要重新定向到home 
    // 以使home组件为router-view的默认值
    redirect: '/home',
    children: router_routes.slice()
}, {
    path: '*',
    name: 'notfound',
    component: NotFound
}];
// 生成路由实体
var router_router = new vue_router_esm["a" /* default */]({
    mode: 'history',
    scrollBehavior: function scrollBehavior(to, from, savedPosition) {
        return { x: 0, y: 0 };
    },
    routes: src_router_routes
});
router_router.beforeEach(function (_a, from, next) {
    var matched = _a.matched,
        path = _a.path;
    return router___awaiter(router__this, void 0, void 0, function () {
        return router___generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    if (!!src_store.state.ready) return [3 /*break*/, 2];
                    return [4 /*yield*/, store_init({
                        store: src_store,
                        router: router_router
                    })];
                case 1:
                    _b.sent();
                    _b.label = 2;
                case 2:
                    if ((src_store.state.tokenExpire || src_store.state.userToken === '') && path !== "/") {
                        // 重置用户过期状态
                        src_store.commit('updateTokenExpire', false);
                        return [2 /*return*/, next("/")];
                    }
                    next();
                    return [2 /*return*/];
            }
        });
    });
});
/* harmony default export */ var src_router = (router_router);
// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/object/values.js
var object_values = __webpack_require__("gRE1");
var values_default = /*#__PURE__*/__webpack_require__.n(object_values);

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/object/entries.js
var entries = __webpack_require__("W3Iv");
var entries_default = /*#__PURE__*/__webpack_require__.n(entries);

// EXTERNAL MODULE: ./node_modules/vue-inject/src/index.js
var src = __webpack_require__("GeUp");
var src_default = /*#__PURE__*/__webpack_require__.n(src);

// CONCATENATED MODULE: ./src/core/provide.ts
var NetService = function NetService() {
    return __webpack_require__("1pVc");
};
var PageService = function PageService() {
    return __webpack_require__("F3Vo");
};
var SortService = function SortService() {
    return __webpack_require__("t/hv");
};
// const DataDictSerivce = () => require('~/services/business-service/data-dict.service')
// const ResourceSerivce = () => require('~/services/business-service/resource.service')
// const LoginSerivce = () => require('~/services/business-service/login.service')
/* harmony default export */ var core_provide = (function () {
    return {
        'netService': [NetService, 'none'],
        'pageService': [PageService, 'none'],
        'sortService': [SortService, 'none']
    };
});
// EXTERNAL MODULE: ./src/config/enum.config.ts
var enum_config = __webpack_require__("mfkW");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("PJh5");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./node_modules/lodash.round/index.js
var lodash_round = __webpack_require__("rcfA");
var lodash_round_default = /*#__PURE__*/__webpack_require__.n(lodash_round);

// EXTERNAL MODULE: ./node_modules/lodash.clonedeep/index.js
var lodash_clonedeep = __webpack_require__("zM1N");
var lodash_clonedeep_default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep);

// CONCATENATED MODULE: ./src/utils/lodash.service.ts


var lodash_service_LodashService = /** @class */function () {
    function LodashService() {}
    LodashService.round = lodash_round_default.a;
    LodashService.clonedeep = lodash_clonedeep_default.a;
    return LodashService;
}();

// EXTERNAL MODULE: ./src/utils/city.service.ts
var city_service = __webpack_require__("8eB/");

// CONCATENATED MODULE: ./src/utils/filter.service.ts






var filter_service_FilterService = /** @class */function () {
    function FilterService() {}
    /**
     * 转换枚举数据
     * @param value
     * @param key
     */
    FilterService.enumConvert = function (value, key) {
        // 排除空字典或者空key
        if (!enum_config || !key || !enum_config[key]) {
            return '';
        }
        var data = enum_config[key] instanceof Array ? enum_config[key] : values_default()(enum_config[key]);
        var target = data.find(function (x) {
            return x.value === value;
        });
        return target ? target.name : "";
    };
    /**
     * 转换字典数据
     * @param id
     */
    FilterService.dictConvert = function (id) {
        var dictData = src_store.state.dictData;
        var target;
        if (dictData) {
            target = dictData.find(function (x) {
                return x.id === id;
            });
        }
        return target ? target.name : "";
    };
    /**
     * 日期范围转换
     * @param dateRange
     * @param fmt
     */
    FilterService.dateRanageFormat = function (dateRange, fmt) {
        if (fmt === void 0) {
            fmt = "yyyy-MM-dd hh:mm:ss";
        }
        var target = {
            start: '',
            end: ''
        };
        // 检测非法输入
        if (!dateRange || dateRange.length === 0 || !(dateRange instanceof Array)) {
            return target;
        }
        target.start = FilterService.dateFormat(dateRange[0], fmt);
        var tmpDate = moment_default()(dateRange[1]);
        if (tmpDate.isValid()) {
            var endTime = moment_default()(dateRange[1]).add(1, 'd').subtract(1, 's').toDate();
            target.end = FilterService.dateFormat(endTime, fmt);
        }
        return target;
    };
    /**
     * 日期格式化
     * @param date
     * @param fmt
     */
    FilterService.dateFormat = function (date, fmt) {
        if (fmt === void 0) {
            fmt = "yyyy-MM-dd hh:mm:ss";
        }
        // 空数据处理
        if (date === null || date === undefined || date === '') {
            return '';
        }
        // 如果是时间戳则转化为时间
        if (typeof date === 'number') {
            date = new Date(date);
        }
        var o = {
            'M+': date.getMonth() + 1,
            'd+': date.getDate(),
            'h+': date.getHours(),
            'm+': date.getMinutes(),
            's+': date.getSeconds(),
            'q+': Math.floor((date.getMonth() + 3) / 3),
            'S': date.getMilliseconds() // 毫秒
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
        for (var k in o) {
            if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length === 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
        }
        return fmt;
    };
    /**
     * 千分位转换
     * @param number
     */
    FilterService.toThousands = function (number) {
        var num = '';
        if (number === null || number === '') {
            num = number | 0;
        } else {
            num = Number(number).toFixed(2);
            if (isNaN(num) || num === '' || num === undefined || num === null) {
                return '0';
            }
            num = num + '';
            if (/^.*\..*$/.test(num)) {
                var pointIndex = num.lastIndexOf('.');
                var intPart = num.substring(0, pointIndex);
                var pointPart = num.substring(pointIndex + 1, num.length);
                intPart = intPart + '';
                var re = /(-?\d+)(\d{3})/;
                while (re.test(intPart)) {
                    intPart = intPart.replace(re, '$1,$2');
                }
                num = intPart + '.' + pointPart;
            } else {
                num = num + '';
                var re = /(-?\d+)(\d{3})/;
                while (re.test(num)) {
                    num = num.replace(re, '$1,$2');
                }
            }
        }
        return num;
    };
    /**
     * 手机号脱敏显示转换器
     */
    FilterService.encryptPhone = function (value) {
        if (!value || value === '') {
            return '';
        }
        return value.substr(0, 3) + '****' + value.substr(7);
    };
    /**
     * 身份证脱敏显示转换器(后四位脱敏)
     */
    FilterService.encryptIDCardFour = function (value) {
        if (!value || value === '') {
            return '';
        }
        // return value.substr(0, 3).padEnd(value.length - 4, '*') + value.substr(-4)
        return value.substr(0, 14) + '****';
    };
    /**
     * 字符串截取
     * @param str 要截取的字符串
     * @param subIndex 截取长度,默认6位
     */
    FilterService.subString = function (str, subIndex) {
        if (subIndex === void 0) {
            subIndex = 6;
        }
        if (!str) {
            return '';
        }
        return str.length > subIndex ? str.substring(0, subIndex) + '...' : str;
    };
    /**
     * 对字符串进行格式化
     * @param str 要格式化的字符串
     * @param length 每行字符长度
     * @param appendStr 要插入的字符串
     */
    FilterService.strSplit = function (str, length, appendStr) {
        if (length === void 0) {
            length = 4;
        }
        if (appendStr === void 0) {
            appendStr = '-';
        }
        if (!str) return '';
        var r = new RegExp(".{" + length + "}", 'g');
        var s = new RegExp(appendStr + "$", 'g');
        return str.replace(r, function ($0) {
            return $0 + appendStr;
        }).replace(s, '');
    };
    /**
     *
     * @param value 要解析的金额字符串
     */
    FilterService.moneyParse = function (value) {
        return value.replace(/,*/g, '');
    };
    /**
     *
     * @param value 要格式化的金额字符串
     */
    FilterService.moneyFormat = function (value) {
        var result = lodash_service_LodashService.round(value, 2);
        return ("" + result).replace(/^\d+/g, function (m) {
            return m.replace(/(?=(?!^)(\d{3})+$)/g, ',');
        });
    };
    /**
     *
     * @param value 要格式化的金额字符串
     */
    FilterService.moneyFormatFour = function (value) {
        var result = lodash_service_LodashService.round(value, 4);
        return ("" + result).replace(/^\d+/g, function (m) {
            return m.replace(/(?=(?!^)(\d{3})+$)/g, ',');
        });
    };
    FilterService.safeNumber = function (value) {
        if (isNaN(value) || value == undefined) {
            return null;
        } else {
            return value;
        }
    };
    /**
     * 格式化显示金额追加百分比符号
     * @param value 要格式化的金额
     */
    FilterService.percentFormat = function (value) {
        var result = lodash_service_LodashService.round(value, 4);
        return result + "%";
    };
    /**
     * 格式化去掉百分比的符号
     * @param value 要去掉%的数值
     */
    FilterService.percentParse = function (value) {
        return value.replace('%', '');
    };
    /**
     *
     * @param value 要格式化的金额或字符串
     * @param d 要保留的小数位数
     */
    FilterService.decimalToPrecent = function (value, d) {
        if (d === void 0) {
            d = 2;
        }
        if (!value) {
            return '0';
        }
        var f = 0;
        var result = '';
        f = parseFloat(value) || f;
        result = lodash_service_LodashService.round(f * 100, d);
        return FilterService.percentFormat(result);
    };
    /**
     * 银行卡号码格式化
     * @param value 要格式化的银行卡号
     */
    FilterService.formatBankCardNumber = function (value) {
        var result = new String(value);
        return result.replace(/(\d{4})(?=\d)/g, "$1" + "-");
    };
    /**
     * 城市文字转换
     * @param values 要转换的城市ID 数组或者单个ID
     */
    FilterService.cityConvert = function (values) {
        var citys = [];
        if (values) {
            var index = 0;
            while (index < values.length) {
                citys.push(city_service["a" /* CityService */].getCityName(values[index]));
                index++;
            }
        }
        return citys.join(' ');
    };
    return FilterService;
}();

// CONCATENATED MODULE: ./src/extension/filter.ts

/* harmony default export */ var filter = (function (_a) {
    var store = _a.store;
    return filter_service_FilterService;
});
// CONCATENATED MODULE: ./src/extension/plugin/city.plugin.ts


/* harmony default export */ var city_plugin = ({
    install: function install() {
        vue_esm["default"].prototype.$city = city_service["a" /* CityService */];
    }
});
// CONCATENATED MODULE: ./src/utils/dict.service.ts

var dict_service_DictService = /** @class */function () {
    function DictService() {}
    /**
     * 获取字典数据
     * @param codes
     */
    DictService.getDictData = function () {
        var codes = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            codes[_i] = arguments[_i];
        }
        var results = [];
        // 获取字典项
        codes.forEach(function (code) {
            var items = src_store.state.dictData.filter(function (x) {
                return x.typeCode === code;
            }).map(function (x) {
                return {
                    value: x.id,
                    label: x.name
                };
            });
            results.push.apply(results, items);
        });
        return results;
    };
    DictService.getDictName = function (value) {
        var data = src_store.state.dictData.find(function (x) {
            return value === x.id;
        });
        if (data) {
            return data.name;
        } else {
            return value;
        }
    };
    return DictService;
}();

// CONCATENATED MODULE: ./src/extension/plugin/dict.plugin.ts


/* harmony default export */ var dict_plugin = ({
    install: function install() {
        vue_esm["default"].prototype.$dict = dict_service_DictService;
    }
});
// CONCATENATED MODULE: ./src/extension/plugin/filter.plugin.ts


/* harmony default export */ var filter_plugin = ({
    install: function install() {
        vue_esm["default"].prototype.$filter = filter_service_FilterService;
    }
});
// CONCATENATED MODULE: ./src/utils/common.service.ts






var common_service___awaiter = this && this.__awaiter || function (thisArg, _arguments, P, generator) {
    return new (P || (P = promise_default.a))(function (resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : new P(function (resolve) {
                resolve(result.value);
            }).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var common_service___generator = this && this.__generator || function (thisArg, body) {
    var _ = { label: 0, sent: function sent() {
            if (t[0] & 1) throw t[1];return t[1];
        }, trys: [], ops: [] },
        f,
        y,
        t,
        g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof symbol_default.a === "function" && (g[iterator_default.a] = function () {
        return this;
    }), g;
    function verb(n) {
        return function (v) {
            return step([n, v]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) {
            try {
                if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [0, t.value];
                switch (op[0]) {
                    case 0:case 1:
                        t = op;break;
                    case 4:
                        _.label++;return { value: op[1], done: false };
                    case 5:
                        _.label++;y = op[1];op = [0];continue;
                    case 7:
                        op = _.ops.pop();_.trys.pop();continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                            _ = 0;continue;
                        }
                        if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                            _.label = op[1];break;
                        }
                        if (op[0] === 6 && _.label < t[1]) {
                            _.label = t[1];t = op;break;
                        }
                        if (t && _.label < t[2]) {
                            _.label = t[2];_.ops.push(op);break;
                        }
                        if (t[2]) _.ops.pop();
                        _.trys.pop();continue;
                }
                op = body.call(thisArg, _);
            } catch (e) {
                op = [6, e];y = 0;
            } finally {
                f = t = 0;
            }
        }if (op[0] & 5) throw op[1];return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var unit = 25;
/**
 * 公共服务类
 */
var common_service_CommonService = /** @class */function () {
    function CommonService() {}
    /**
     * 获取组件名称
     * @param path
     */
    CommonService.getComponentName = function (path) {
        var pathArray = path.split('.')[0].split('/');
        return ("-" + pathArray[pathArray.length - 1]).replace(/\-(\w)/g, function ($0, $1) {
            return $1.toUpperCase();
        });
    };
    /**
     * 下载文件
     */
    CommonService.downloadFile = function (url, filename) {
        var a = document.createElement('a');
        a.href = url;
        a.download = filename || +new Date();
        a.click();
    };
    /**
     * 批量下载文件
     * @param pathList 需要下载的文件列表，需要包含 url,filename
     */
    CommonService.downloadAll = function (pathList) {
        var _this = this;
        var download = function download() {
            return common_service___awaiter(_this, void 0, void 0, function () {
                var _loop_1, index;
                return common_service___generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            _loop_1 = function _loop_1(index) {
                                var v;
                                return common_service___generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0:
                                            v = pathList[index];
                                            return [4 /*yield*/, new promise_default.a(function (reslove) {
                                                CommonService.downloadFile(v.url, v.filename);
                                                setTimeout(function () {
                                                    reslove();
                                                }, 100);
                                            })];
                                        case 1:
                                            _a.sent();
                                            return [2 /*return*/];
                                    }
                                });
                            };
                            index = 0;
                            _a.label = 1;
                        case 1:
                            if (!(index < pathList.length)) return [3 /*break*/, 4];
                            return [5 /*yield**/, _loop_1(index)];
                        case 2:
                            _a.sent();
                            _a.label = 3;
                        case 3:
                            index++;
                            return [3 /*break*/, 1];
                        case 4:
                            return [2 /*return*/];
                    }
                });
            });
        };
        download();
    };
    /**
    * 用户部门数据
    * @param sourece
    */
    CommonService.departmentData = function (sourece) {
        if (!sourece) {
            return;
        }
        // 生成部门结构数据
        var fun = function fun(node) {
            // 递归对象子元素
            var children = sourece.filter(function (x) {
                return node.id === x.pid;
            }).map(fun);
            if (children && children.length) {
                return assign_default()({}, node, { children: children });
            } else {
                return node;
            }
        };
        // 过滤父节点
        var rootList = sourece.filter(function (x) {
            if (!x.deptPid) {
                return true;
            }
            return !sourece.find(function (item) {
                return item.id === x.pid;
            });
        });
        // 生成树形结构
        return rootList.map(fun);
    };
    CommonService.getColumnWidth = function (count) {
        return count * unit;
    };
    CommonService.reset = function (target, options) {
        var check = function check(item, key, value) {
            switch (typeof value === "undefined" ? "undefined" : typeof_default()(value)) {
                case 'number':
                    {
                        item[key] = 0;
                        break;
                    }
                case 'string':
                    {
                        item[key] = "";
                        break;
                    }
                case 'object':
                    {
                        if (value instanceof Array) {
                            item[key] = [];
                        } else {
                            clearObject(value);
                        }
                        break;
                    }
            }
        };
        var clearObject = function clearObject(object) {
            if (!object) return;
            entries_default()(object).forEach(function (_a) {
                var key = _a[0],
                    value = _a[1];
                check(object, key, value);
            });
        };
        var clearArray = function clearArray(array) {
            array.forEach(function (value, index) {
                check(array, index, value);
            });
        };
        if (target instanceof Array) {
            clearArray(target);
        } else {
            clearObject(target);
        }
    };
    CommonService.revert = function (source) {
        var values = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            values[_i - 1] = arguments[_i];
        }
        var sourceType = typeof source === "undefined" ? "undefined" : typeof_default()(source);
        if (!values.every(function (x) {
            return (typeof x === "undefined" ? "undefined" : typeof_default()(x)) === sourceType;
        })) {
            return;
        }
        if (source instanceof Array) {
            source.length = 0;
            values.forEach(function (item) {
                item.forEach(function (x) {
                    return source.push(x);
                });
            });
        } else {
            values.forEach(function (item) {
                for (var key in item) {
                    if (key in source) {
                        source[key] = item[key];
                    }
                }
            });
        }
        return source;
    };
    return CommonService;
}();

// CONCATENATED MODULE: ./src/extension/plugin/common.plugin.ts


/* harmony default export */ var common_plugin = ({
    install: function install() {
        vue_esm["default"].prototype.$common = common_service_CommonService;
    }
});
// EXTERNAL MODULE: ./node_modules/async-validator/es/index.js + 24 modules
var async_validator_es = __webpack_require__("jwfv");

// CONCATENATED MODULE: ./src/utils/validator.service.ts


var validator_service_ValidatorService = /** @class */function () {
    function ValidatorService() {}
    /**
     * 自定义验证器
     * @param data
     * @param descriptor
     * @param callback
     */
    ValidatorService.validate = function (data, descriptor) {
        var schema = new async_validator_es["a" /* default */](descriptor);
        var process = new promise_default.a(function (reslove, reject) {
            schema.validate(data, function (errors, fields) {
                if (errors && errors.length) {
                    var error = errors[0];
                    // 验证成功
                    reslove(error.message);
                } else {
                    reslove();
                }
            });
        });
        return process;
    };
    /**
     * 验证银行卡号
     */
    ValidatorService.bankNumber = function (rule, value, callback) {
        if (ValidatorService.regex.bankNumber.test(value) || !value) {
            callback();
        } else {
            callback(new Error("请输入正确银行卡号"));
        }
    };
    /**
     * 验证手机号
     */
    ValidatorService.phoneNumber = function (rule, value, callback) {
        if (ValidatorService.regex.phoneNumber.test(value) || !value) {
            callback();
        } else {
            callback(new Error("请输入正确的手机号"));
        }
    };
    /**
     * 验证身份证
     */
    ValidatorService.idCard = function (rule, value, callback) {
        if (ValidatorService.regex.idCard.test(value) || !value) {
            callback();
        } else {
            callback(new Error("请输入正确的身份证号码"));
        }
    };
    /**
     * 验证金额
     */
    ValidatorService.money = function (rule, value, callback) {
        if (ValidatorService.regex.money.test(value) || !value) {
            callback();
        } else {
            callback(new Error("请输入正确格式的金额"));
        }
    };
    /**
    * 验证金额
    */
    ValidatorService.zipCode = function (rule, value, callback) {
        if (ValidatorService.regex.zipCode.test(value) || !value) {
            callback();
        } else {
            callback(new Error("请输入正确的邮政编码"));
        }
    };
    /**
     * 验证手机号
     */
    ValidatorService.carCardNo = function (rule, value, callback) {
        if (ValidatorService.regex.carCardNo.test(value) || !value) {
            callback();
        } else {
            callback(new Error("请输入正确的车牌照号码"));
        }
    };
    /**
     * 表单验证
     * @param rule
     * @param value
     * @param callback
     */
    ValidatorService.formValidate = function (rule, value, callback) {
        if (!value) {
            return callback();
        }
        value.validate(function (valid) {
            if (valid) {
                callback();
            } else {
                callback(new Error(rule.message || "输入项填写错误"));
            }
        });
    };
    // 验证正则列表
    ValidatorService.regex = {
        // 手机号
        phoneNumber: /^1([^1,2])\d{9}$/,
        // 身份证18位
        idCard: /(^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$)/,
        // 金额
        money: /(^[1-9](\d+)?(\.\d{1,2})?$)|(^(0){1}$)|(^\d\.\d{1,2}?$)/,
        // 邮编
        zipCode: /^[1-9]\d{5}(?!\d)$/,
        // 车牌照正则表达式
        carCardNo: /^(([\u4e00-\u9fa5][a-zA-Z]|[\u4e00-\u9fa5]{2}\d{2}|[\u4e00-\u9fa5]{2}[a-zA-Z])[-]?|([wW][Jj][\u4e00-\u9fa5]{1}[-]?)|([a-zA-Z]{2}))([A-Za-z0-9]{5}|[DdFf][A-HJ-NP-Za-hj-np-z0-9][0-9]{4}|[0-9]{5}[DdFf])$/,
        //验证银行卡号
        bankNumber: /^([1-9]{1})(\d{15}|\d{18})$/
    };
    return ValidatorService;
}();

// CONCATENATED MODULE: ./src/extension/plugin/validator.plugin.ts


/* harmony default export */ var validator_plugin = ({
    install: function install() {
        vue_esm["default"].prototype.$validator = validator_service_ValidatorService;
    }
});
// CONCATENATED MODULE: ./src/extension/plugin/index.ts





/* harmony default export */ var extension_plugin = (function (_a) {
    var store = _a.store;
    return {
        cityPlugin: city_plugin,
        dictPlugin: dict_plugin,
        filterPlugin: filter_plugin,
        commonPlugin: common_plugin,
        validatorPlugin: validator_plugin
    };
});
// CONCATENATED MODULE: ./src/core/bootstrap/base.init.ts





var base_init___awaiter = this && this.__awaiter || function (thisArg, _arguments, P, generator) {
    return new (P || (P = promise_default.a))(function (resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : new P(function (resolve) {
                resolve(result.value);
            }).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var base_init___generator = this && this.__generator || function (thisArg, body) {
    var _ = { label: 0, sent: function sent() {
            if (t[0] & 1) throw t[1];return t[1];
        }, trys: [], ops: [] },
        f,
        y,
        t,
        g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof symbol_default.a === "function" && (g[iterator_default.a] = function () {
        return this;
    }), g;
    function verb(n) {
        return function (v) {
            return step([n, v]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) {
            try {
                if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [0, t.value];
                switch (op[0]) {
                    case 0:case 1:
                        t = op;break;
                    case 4:
                        _.label++;return { value: op[1], done: false };
                    case 5:
                        _.label++;y = op[1];op = [0];continue;
                    case 7:
                        op = _.ops.pop();_.trys.pop();continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                            _ = 0;continue;
                        }
                        if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                            _.label = op[1];break;
                        }
                        if (op[0] === 6 && _.label < t[1]) {
                            _.label = t[1];t = op;break;
                        }
                        if (t && _.label < t[2]) {
                            _.label = t[2];_.ops.push(op);break;
                        }
                        if (t[2]) _.ops.pop();
                        _.trys.pop();continue;
                }
                op = body.call(thisArg, _);
            } catch (e) {
                op = [6, e];y = 0;
            } finally {
                f = t = 0;
            }
        }if (op[0] & 5) throw op[1];return { value: op[0] ? op[1] : void 0, done: true };
    }
};





/* harmony default export */ var base_init = (function (_a) {
    var store = _a.store;
    return base_init___awaiter(this, void 0, void 0, function () {
        return base_init___generator(this, function (_b) {
            // 创建提供器
            if (core_provide) {
                vue_esm["default"].use(src_default.a);
                entries_default()(core_provide()).forEach(function (_a) {
                    var key = _a[0],
                        value = _a[1];
                    var lifecycle = "class";
                    var provide;
                    if (value instanceof Array) {
                        lifecycle = value[1];
                        provide = value[0];
                    } else {
                        provide = value;
                    }
                    var target = values_default()(provide())[0];
                    src_default.a.service(key, target).lifecycle[lifecycle]();
                });
            }
            // 安装过滤器
            if (filter) {
                entries_default()(filter({ store: store })).forEach(function (_a) {
                    var key = _a[0],
                        fun = _a[1];
                    vue_esm["default"].filter(key, fun);
                });
            }
            // 安装插件
            if (extension_plugin) {
                entries_default()(extension_plugin({ store: store })).forEach(function (_a) {
                    var key = _a[0],
                        plugin = _a[1];
                    vue_esm["default"].use(plugin);
                });
            }
            return [2 /*return*/];
        });
    });
});
// EXTERNAL MODULE: ./node_modules/vant/lib/vant-css/index.css
var vant_css = __webpack_require__("CMvz");
var vant_css_default = /*#__PURE__*/__webpack_require__.n(vant_css);

// CONCATENATED MODULE: ./src/core/bootstrap/plugin.init.ts



var plugin_init___awaiter = this && this.__awaiter || function (thisArg, _arguments, P, generator) {
    return new (P || (P = promise_default.a))(function (resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : new P(function (resolve) {
                resolve(result.value);
            }).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var plugin_init___generator = this && this.__generator || function (thisArg, body) {
    var _ = { label: 0, sent: function sent() {
            if (t[0] & 1) throw t[1];return t[1];
        }, trys: [], ops: [] },
        f,
        y,
        t,
        g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof symbol_default.a === "function" && (g[iterator_default.a] = function () {
        return this;
    }), g;
    function verb(n) {
        return function (v) {
            return step([n, v]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) {
            try {
                if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [0, t.value];
                switch (op[0]) {
                    case 0:case 1:
                        t = op;break;
                    case 4:
                        _.label++;return { value: op[1], done: false };
                    case 5:
                        _.label++;y = op[1];op = [0];continue;
                    case 7:
                        op = _.ops.pop();_.trys.pop();continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                            _ = 0;continue;
                        }
                        if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                            _.label = op[1];break;
                        }
                        if (op[0] === 6 && _.label < t[1]) {
                            _.label = t[1];t = op;break;
                        }
                        if (t && _.label < t[2]) {
                            _.label = t[2];_.ops.push(op);break;
                        }
                        if (t[2]) _.ops.pop();
                        _.trys.pop();continue;
                }
                op = body.call(thisArg, _);
            } catch (e) {
                op = [6, e];y = 0;
            } finally {
                f = t = 0;
            }
        }if (op[0] & 5) throw op[1];return { value: op[0] ? op[1] : void 0, done: true };
    }
};



/* harmony default export */ var plugin_init = (function (_a) {
    var store = _a.store;
    return plugin_init___awaiter(this, void 0, void 0, function () {
        return plugin_init___generator(this, function (_b) {
            vue_esm["default"].use(es["b" /* default */]);
            return [2 /*return*/];
        });
    });
});
// CONCATENATED MODULE: ./src/core/bootstrap/index.ts



var bootstrap___awaiter = this && this.__awaiter || function (thisArg, _arguments, P, generator) {
    return new (P || (P = promise_default.a))(function (resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : new P(function (resolve) {
                resolve(result.value);
            }).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var bootstrap___generator = this && this.__generator || function (thisArg, body) {
    var _ = { label: 0, sent: function sent() {
            if (t[0] & 1) throw t[1];return t[1];
        }, trys: [], ops: [] },
        f,
        y,
        t,
        g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof symbol_default.a === "function" && (g[iterator_default.a] = function () {
        return this;
    }), g;
    function verb(n) {
        return function (v) {
            return step([n, v]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) {
            try {
                if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [0, t.value];
                switch (op[0]) {
                    case 0:case 1:
                        t = op;break;
                    case 4:
                        _.label++;return { value: op[1], done: false };
                    case 5:
                        _.label++;y = op[1];op = [0];continue;
                    case 7:
                        op = _.ops.pop();_.trys.pop();continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                            _ = 0;continue;
                        }
                        if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                            _.label = op[1];break;
                        }
                        if (op[0] === 6 && _.label < t[1]) {
                            _.label = t[1];t = op;break;
                        }
                        if (t && _.label < t[2]) {
                            _.label = t[2];_.ops.push(op);break;
                        }
                        if (t[2]) _.ops.pop();
                        _.trys.pop();continue;
                }
                op = body.call(thisArg, _);
            } catch (e) {
                op = [6, e];y = 0;
            } finally {
                f = t = 0;
            }
        }if (op[0] & 5) throw op[1];return { value: op[0] ? op[1] : void 0, done: true };
    }
};


/* harmony default export */ var bootstrap = (function (_a) {
    var store = _a.store,
        router = _a.router;
    return bootstrap___awaiter(this, void 0, void 0, function () {
        return bootstrap___generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    // 基础功能初始化
                    return [4 /*yield*/, base_init({ store: store })
                    // 第三方插件初始化
                    ];
                case 1:
                    // 基础功能初始化
                    _b.sent();
                    // 第三方插件初始化
                    return [4 /*yield*/, plugin_init({ store: store })];
                case 2:
                    // 第三方插件初始化
                    _b.sent();
                    return [2 /*return*/];
            }
        });
    });
});
// CONCATENATED MODULE: ./src/main.ts



// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
var main___awaiter = this && this.__awaiter || function (thisArg, _arguments, P, generator) {
    return new (P || (P = promise_default.a))(function (resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : new P(function (resolve) {
                resolve(result.value);
            }).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var main___generator = this && this.__generator || function (thisArg, body) {
    var _ = { label: 0, sent: function sent() {
            if (t[0] & 1) throw t[1];return t[1];
        }, trys: [], ops: [] },
        f,
        y,
        t,
        g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof symbol_default.a === "function" && (g[iterator_default.a] = function () {
        return this;
    }), g;
    function verb(n) {
        return function (v) {
            return step([n, v]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) {
            try {
                if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [0, t.value];
                switch (op[0]) {
                    case 0:case 1:
                        t = op;break;
                    case 4:
                        _.label++;return { value: op[1], done: false };
                    case 5:
                        _.label++;y = op[1];op = [0];continue;
                    case 7:
                        op = _.ops.pop();_.trys.pop();continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                            _ = 0;continue;
                        }
                        if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                            _.label = op[1];break;
                        }
                        if (op[0] === 6 && _.label < t[1]) {
                            _.label = t[1];t = op;break;
                        }
                        if (t && _.label < t[2]) {
                            _.label = t[2];_.ops.push(op);break;
                        }
                        if (t[2]) _.ops.pop();
                        _.trys.pop();continue;
                }
                op = body.call(thisArg, _);
            } catch (e) {
                op = [6, e];y = 0;
            } finally {
                f = t = 0;
            }
        }if (op[0] & 5) throw op[1];return { value: op[0] ? op[1] : void 0, done: true };
    }
};





function startUp() {
    return main___awaiter(this, void 0, void 0, function () {
        return main___generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    // 启动主体业务逻辑
                    return [4 /*yield*/, bootstrap({ store: src_store, router: src_router })];
                case 1:
                    // 启动主体业务逻辑
                    _a.sent();
                    window['__store'] = src_store;
                    window['__router'] = src_router;
                    // 生成提示信息
                    vue_esm["default"].config.productionTip = false;
                    /* eslint-disable no-new */
                    new vue_esm["default"]({
                        el: '#app',
                        router: src_router,
                        store: src_store,
                        template: '<App/>',
                        components: { App: src_App }
                    });
                    return [2 /*return*/];
            }
        });
    });
}
// 打印版本发布信息
if (true) {
    console.log('当前环境:' + "demo");
    console.log('版本发布时间:' + "2018-6-14 16:32:05");
}
// 应用程序启动
startUp();

/***/ })

},["x35b"]);
//# sourceMappingURL=app.af681c732d24b0dcdc80.js.map