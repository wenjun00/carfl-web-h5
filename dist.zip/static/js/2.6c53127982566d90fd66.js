webpackJsonp([2],{

/***/ "Luci":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/vue/dist/vue.esm.js
var vue_esm = __webpack_require__("7+uW");

// EXTERNAL MODULE: ./node_modules/vue-class-component/dist/vue-class-component.common.js
var vue_class_component_common = __webpack_require__("c+8m");
var vue_class_component_common_default = /*#__PURE__*/__webpack_require__.n(vue_class_component_common);

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/object/define-property.js
var define_property = __webpack_require__("C4MV");
var define_property_default = /*#__PURE__*/__webpack_require__.n(define_property);

// EXTERNAL MODULE: ./node_modules/babel-runtime/helpers/typeof.js
var helpers_typeof = __webpack_require__("pFYg");
var typeof_default = /*#__PURE__*/__webpack_require__.n(helpers_typeof);

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/object/get-own-property-descriptor.js
var get_own_property_descriptor = __webpack_require__("K6ED");
var get_own_property_descriptor_default = /*#__PURE__*/__webpack_require__.n(get_own_property_descriptor);

// EXTERNAL MODULE: ./src/config/server/manage-service/index.ts + 9 modules
var manage_service = __webpack_require__("afVn");

// EXTERNAL MODULE: ./src/utils/net.service.ts + 7 modules
var net_service = __webpack_require__("1pVc");

// EXTERNAL MODULE: ./src/core/decorator.ts
var decorator = __webpack_require__("f3r7");

// CONCATENATED MODULE: ./src/services/manage-service/applogin.service.ts



var __decorate = this && this.__decorate || function (decorators, target, key, desc) {
    var c = arguments.length,
        r = c < 3 ? target : desc === null ? desc = get_own_property_descriptor_default()(target, key) : desc,
        d;
    if ((typeof Reflect === "undefined" ? "undefined" : typeof_default()(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
        if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    }return c > 3 && r && define_property_default()(target, key, r), r;
};



var applogin_service_LoginService = /** @class */function () {
    function LoginService() {}
    /**
     * 获取验证码
     */
    LoginService.prototype.getVerifyCode = function (phoneNumber) {
        return this.netService.send({
            server: manage_service["a" /* manageService */].appLoginController.getVerifyCode,
            data: {
                mobileCode: phoneNumber
            }
        });
    };
    /**
     * 通过验证码登录
     */
    LoginService.prototype.verifyCodeLogin = function (data) {
        return this.netService.send({
            server: manage_service["a" /* manageService */].appLoginController.verifyCodeLogin,
            data: {
                mobileMain: data.phoneNumber,
                verificationCode: data.verifyCode
            },
            loading: true
        });
    };
    /**
     *  验证TOKEN
     */
    LoginService.prototype.checkToken = function (token) {
        return this.netService.send({
            server: manage_service["a" /* manageService */].appLoginController.checkToken,
            data: {
                token: token
            }
        });
    };
    /**
     * 注销用户
     */
    LoginService.prototype.logout = function (userId) {
        return this.netService.send({
            server: manage_service["a" /* manageService */].appLoginController.exit,
            data: {
                userId: userId
            }
        });
    };
    __decorate([Object(decorator["c" /* Inject */])(net_service["NetService"])], LoginService.prototype, "netService", void 0);
    __decorate([Object(decorator["a" /* Debounce */])()], LoginService.prototype, "getVerifyCode", null);
    return LoginService;
}();

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("ipus");

// EXTERNAL MODULE: ./src/utils/storage.service.ts
var storage_service = __webpack_require__("3mjx");

// CONCATENATED MODULE: ./node_modules/ts-loader!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/pages/login.vue
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var login___decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var login_Login = /** @class */ (function (_super) {
    __extends(Login, _super);
    function Login() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // 客户手机号码
        _this.phoneNumber = "";
        _this.loginModel = {
            phoneNumber: "",
            verifyCode: "" //验证码
        };
        // 键盘展示flag
        _this.keyboardFlag = {
            phone: false,
            code: false
        };
        // 验证规则
        _this.rules = {
            phoneNumber: {
                validator: _this.$validator.phoneNumber,
                message: "请输入正确的手机号"
            }
        };
        // 验证码获取剩余时间
        _this.leftTime = 0;
        return _this;
    }
    Login.prototype.mounted = function () {
        if (storage_service["a" /* StorageService */].getItem("account") !== null) {
            this.loginModel.phoneNumber =
                storage_service["a" /* StorageService */].getItem("account").phoneNumber || "";
        }
    };
    /**
     * 键盘输入
     * @param val 案件内容
     */
    Login.prototype.onKeyBoardInputPhone = function (val) {
        if (this.loginModel.phoneNumber.length === 11)
            return;
        this.loginModel.phoneNumber += val.toString();
    };
    /**
     * 按钮删除操作
     */
    Login.prototype.onKeyBoardDeletePhone = function () {
        var length = this.loginModel.phoneNumber.length;
        if (length === 0)
            return;
        this.loginModel.phoneNumber = this.loginModel.phoneNumber.substring(0, length - 1);
    };
    /**
     * 输入验证码
     */
    Login.prototype.onKeyBoardInputCode = function (val) {
        if (this.loginModel.phoneNumber.length === 4)
            return;
        this.loginModel.verifyCode += val.toString();
    };
    /**
     * 删除验证码
     */
    Login.prototype.onKeyBoardDeleteCode = function () {
        var length = this.loginModel.verifyCode.length;
        if (length === 0)
            return;
        this.loginModel.verifyCode = this.loginModel.verifyCode.substring(0, length - 1);
    };
    /**
     * 获取验证码
     */
    Login.prototype.onVerifyCodeClick = function (time) {
        var _this = this;
        this.loginService.getVerifyCode(this.loginModel.phoneNumber).subscribe(function (data) {
            // this.loginModel.verifyCode = data
            _this.leftTime = 60;
            var _self = _this;
            var setTime = function () {
                setTimeout(function () {
                    if (_self.leftTime > 0) {
                        _self.leftTime--;
                        setTime();
                    }
                }, 1000);
            };
            setTime();
        }, function (err) { return _this.$toast(err.msg); });
    };
    // 获取当前用户有没有订单
    Login.prototype.getOrderInfo = function () {
    };
    /**
     * 提交操作
     */
    Login.prototype.onSubmit = function () {
        var _this = this;
        this.$validator.validate(this.loginModel, this.rules).then(function (error) {
            if (!error) {
                _this.loginService.verifyCodeLogin(_this.loginModel).subscribe(function (data) {
                    var resultData = {
                        token: data.token,
                        personalId: data.personalId,
                        personalName: data.personalName,
                        userPhone: _this.loginModel.phoneNumber
                    };
                    _this.updateUserLoginData(resultData);
                    _this.$router.push("/Index");
                }, function (err) { return _this.$toast(err.msg); });
            }
            else {
                _this.$toast(error);
            }
        });
    };
    Login.prototype.onPhoneNumberFocus = function (v) {
        document.activeElement.blur();
        this.keyboardFlag.phone = true;
    };
    Login.prototype.onCodeNumberFocus = function () {
        document.activeElement.blur();
        this.keyboardFlag.code = true;
    };
    login___decorate([
        Object(decorator["b" /* Dependencies */])(applogin_service_LoginService)
    ], Login.prototype, "loginService", void 0);
    login___decorate([
        lib["c" /* Mutation */]
    ], Login.prototype, "updateUserPhone", void 0);
    login___decorate([
        lib["a" /* Action */]
    ], Login.prototype, "updateUserLoginData", void 0);
    Login = login___decorate([
        vue_class_component_common_default()({
            components: {}
        })
    ], Login);
    return Login;
}(vue_esm["default"]));
/* harmony default export */ var login = (login_Login);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-0aa636be","hasScoped":true,"optionsId":"0","buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/pages/login.vue
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"page login"},[_c('div',{staticClass:"imgHeaght",class:_vm.keyboardFlag.phone || _vm.keyboardFlag.code ? 'move-top' : ''},[_c('img',{attrs:{"height":"160px","src":"/static/images/common/register_login.png"}})]),_vm._v(" "),_c('van-row',{staticClass:"login-info"},[_c('van-cell-group',[_c('van-field',{attrs:{"maxlength":"11","label":"手机号","placeholder":"请输入您的手机号","icon":"clear"},on:{"click-icon":function($event){_vm.loginModel.phoneNumber = ''},"focus":_vm.onPhoneNumberFocus},model:{value:(_vm.loginModel.phoneNumber),callback:function ($$v) {_vm.$set(_vm.loginModel, "phoneNumber", $$v)},expression:"loginModel.phoneNumber"}}),_vm._v(" "),_c('van-number-keyboard',{attrs:{"show":_vm.keyboardFlag.phone,"title":"洋葱汽车安全键盘","close-button-text":"完成"},on:{"blur":function($event){_vm.keyboardFlag.phone = false},"input":_vm.onKeyBoardInputPhone,"delete":_vm.onKeyBoardDeletePhone}}),_vm._v(" "),_c('van-field',{attrs:{"maxlength":"6","center":"","label":"验证码","placeholder":"请输入短信验证码","icon":"clear"},on:{"click-icon":function($event){_vm.loginModel.verifyCode = ''},"focus":_vm.onCodeNumberFocus},model:{value:(_vm.loginModel.verifyCode),callback:function ($$v) {_vm.$set(_vm.loginModel, "verifyCode", $$v)},expression:"loginModel.verifyCode"}},[_c('van-button',{attrs:{"slot":"button","size":"small","type":"primary","disabled":_vm.leftTime !== 0},on:{"click":_vm.onVerifyCodeClick},slot:"button"},[_vm._v(_vm._s(_vm.leftTime > 0 ? _vm.leftTime + '秒后重发' : '获取验证码'))])],1),_vm._v(" "),_c('van-number-keyboard',{attrs:{"show":_vm.keyboardFlag.code},on:{"blur":function($event){_vm.keyboardFlag.code = false},"input":_vm.onKeyBoardInputCode,"delete":_vm.onKeyBoardDeleteCode}})],1)],1),_vm._v(" "),_c('div',{staticClass:"submit"},[_c('van-button',{staticClass:"full-radius",attrs:{"type":"primary","size":"large"},on:{"click":_vm.onSubmit}},[_vm._v("登录")])],1)],1)}
var staticRenderFns = []

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/component-normalizer.js
var component_normalizer = __webpack_require__("XyMi");

// CONCATENATED MODULE: ./src/pages/login.vue
function injectStyle (context) {
  __webpack_require__("hprl")
}
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-0aa636be"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null

var Component = Object(component_normalizer["a" /* default */])(
  login,
  render,
  staticRenderFns,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var pages_login = __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "ez4c":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("FZ+f")(false);
// imports


// module
exports.push([module.i, ".page.login[data-v-0aa636be]{text-align:center}.page.login .submit[data-v-0aa636be]{margin-top:30px}.page.login .imgHeaght[data-v-0aa636be]{height:320px;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center}.page.login .move-top[data-v-0aa636be]{margin-top:-80px}", ""]);

// exports


/***/ }),

/***/ "hprl":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("ez4c");
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = __webpack_require__("po5z").default
var update = add("fde12200", content, true, {});

/***/ })

});
//# sourceMappingURL=2.6c53127982566d90fd66.js.map