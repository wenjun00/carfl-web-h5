webpackJsonp([3],{

/***/ "V7k7":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataDictService", function() { return DataDictService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_object_define_property__ = __webpack_require__("C4MV");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_object_define_property___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_object_define_property__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof__ = __webpack_require__("pFYg");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_get_own_property_descriptor__ = __webpack_require__("K6ED");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_get_own_property_descriptor___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_get_own_property_descriptor__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__utils_net_service__ = __webpack_require__("1pVc");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__core_decorator__ = __webpack_require__("f3r7");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__config_server_manage_service__ = __webpack_require__("afVn");



var __decorate = this && this.__decorate || function (decorators, target, key, desc) {
    var c = arguments.length,
        r = c < 3 ? target : desc === null ? desc = __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_get_own_property_descriptor___default()(target, key) : desc,
        d;
    if ((typeof Reflect === "undefined" ? "undefined" : __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_typeof___default()(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
        if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    }return c > 3 && r && __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_object_define_property___default()(target, key, r), r;
};



var DataDictService = /** @class */function () {
    function DataDictService() {}
    /**
     * 查询所有数据字典类型
     */
    DataDictService.prototype.getDataDictByTypeCode = function (_a) {
        var typeCode = _a.typeCode;
        return this.netService.send({
            server: __WEBPACK_IMPORTED_MODULE_5__config_server_manage_service__["a" /* manageService */].dataDictController.getDataDictByTypeCode,
            data: {
                typeCode: typeCode
            }
        });
    };
    /**
     * 新增/修改数据字典项
     */
    DataDictService.prototype.createOrModifyDataDict = function (data) {
        return this.netService.send({
            server: __WEBPACK_IMPORTED_MODULE_5__config_server_manage_service__["a" /* manageService */].dataDictController.createOrModifyDataDict,
            data: data
        });
    };
    /**
     * 删除数据字典项
     */
    DataDictService.prototype.deleteDataDict = function (_a) {
        var id = _a.id;
        return this.netService.send({
            server: __WEBPACK_IMPORTED_MODULE_5__config_server_manage_service__["a" /* manageService */].dataDictController.deleteDataDict,
            data: {
                id: id
            }
        });
    };
    /**
     * 根据条件搜索对应的数字字典项
    */
    DataDictService.prototype.getAllDataDict = function (data, page) {
        return this.netService.send({
            server: __WEBPACK_IMPORTED_MODULE_5__config_server_manage_service__["a" /* manageService */].dataDictController.getAllDataDict,
            data: data,
            page: page
        });
    };
    /**
     * 查询所有数据字典项(无typeCode)
    */
    DataDictService.prototype.getAll = function () {
        return this.netService.send({
            server: __WEBPACK_IMPORTED_MODULE_5__config_server_manage_service__["a" /* manageService */].dataDictController.getAll
        });
    };
    DataDictService.prototype.getDictHash = function () {
        return this.netService.send({
            server: __WEBPACK_IMPORTED_MODULE_5__config_server_manage_service__["a" /* manageService */].dataDictController.getDictHash
        });
    };
    /**
    * 获取字典数据
    */
    DataDictService.prototype.getDictData = function () {
        return this.netService.send({
            server: __WEBPACK_IMPORTED_MODULE_5__config_server_manage_service__["a" /* manageService */].dataDictController.getDictData
        });
    };
    /**
    * 分页查询数据字典类型对应的数据字典项
    */
    DataDictService.prototype.getDataDictByTypeCodeWithPage = function (data, page) {
        return this.netService.send({
            server: __WEBPACK_IMPORTED_MODULE_5__config_server_manage_service__["a" /* manageService */].dataDictController.getDataDictByTypeCodeWithPage,
            data: data,
            page: page
        });
    };
    __decorate([Object(__WEBPACK_IMPORTED_MODULE_4__core_decorator__["c" /* Inject */])(__WEBPACK_IMPORTED_MODULE_3__utils_net_service__["NetService"])], DataDictService.prototype, "netService", void 0);
    return DataDictService;
}();


/***/ })

});
//# sourceMappingURL=3.e5d3005b7f3b768d7f4d.js.map